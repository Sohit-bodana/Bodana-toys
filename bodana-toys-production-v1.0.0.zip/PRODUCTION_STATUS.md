# Bodana Toys — Production candidate v1.0.0

This package is cleaned from the latest uploaded project and contains only one
project root (the duplicate `latest-uploaded-bodana/bodana_inspect` copy was removed).

Implemented in source:
- Firebase Authentication is required for real accounts; no mock users.
- Firestore is authoritative for the live product catalog when Firebase is configured.
- Admin access is controlled by `users/{uid}.isAdmin === true`.
- Inventory reservation uses Firestore transactions.
- Checkout State selector has reliable pointer interaction.
- Demo checkout OTP was removed; checkout no longer displays a fake OTP.
- COD orders are written to Firestore.
- Online payment remains server-side Razorpay and is never marked paid without
  server signature verification.
- Failed checkout/payment returns reserved stock and cancels a created order
  on a best-effort basis.
- Razorpay secrets are not included in this ZIP and must be added server-side
  in Vercel.

Required Vercel client variables:
VITE_FIREBASE_API_KEY
VITE_FIREBASE_AUTH_DOMAIN
VITE_FIREBASE_PROJECT_ID
VITE_FIREBASE_STORAGE_BUCKET
VITE_FIREBASE_MESSAGING_SENDER_ID
VITE_FIREBASE_APP_ID

Required Vercel server variables for online payment:
RAZORPAY_KEY_ID
RAZORPAY_KEY_SECRET

The ZIP intentionally contains no passwords, Firebase service-account keys, or
Razorpay secrets.
