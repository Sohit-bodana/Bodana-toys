/**
 * Vercel Serverless Function — POST /api/orders/create-razorpay-order
 *
 * Creates a Razorpay order server-side. The secret key never reaches the
 * browser; only the public key id is returned to the client.
 *
 * Required env vars (server-only, no VITE_ prefix):
 *   RAZORPAY_KEY_ID     — rzp_test_… or rzp_live_…
 *   RAZORPAY_KEY_SECRET — secret key
 *
 * Request body:  { amount: number (paise), currency: string, receipt: string }
 * Response:      { id, amount, currency, keyId }
 */

import { createServer } from 'node:http';

export const config = { runtime: 'nodejs' };

// Accept the Vercel function signature without depending on @vercel/node types.
type Req = Parameters<Parameters<typeof createServer>[0]>[0] & { body?: any };
type Res = Parameters<Parameters<typeof createServer>[0]>[1];

function readBody(req: Req): Promise<any> {
  return new Promise((resolve) => {
    if (req.body !== undefined) { resolve(req.body); return; }
    let raw = '';
    req.on('data', (chunk: Buffer | string) => { raw += chunk.toString(); });
    req.on('end', () => { try { resolve(JSON.parse(raw)); } catch { resolve({}); } });
  });
}

function json(res: Res, status: number, data: unknown) {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  });
  res.end(JSON.stringify(data));
}

export default async function handler(req: Req, res: Res) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST', 'Access-Control-Allow-Headers': 'Content-Type,Authorization' });
    res.end();
    return;
  }

  if (req.method !== 'POST') {
    return json(res, 405, { message: 'Method not allowed' });
  }

  // Require a Bearer token (Firebase Auth ID token) so anonymous callers cannot
  // create Razorpay orders and drain the account.
  const auth = (req.headers as Record<string, string>)['authorization'] || '';
  if (!auth.startsWith('Bearer ')) {
    return json(res, 401, { message: 'Unauthorized. Please sign in before paying online.' });
  }

  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;

  if (!keyId || !keySecret) {
    return json(res, 503, {
      message: 'Razorpay is not configured on this server. Please add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET environment variables.',
    });
  }

  const body = await readBody(req);
  const amount = Number(body?.amount);
  const currency = String(body?.currency || 'INR');
  const receipt = String(body?.receipt || '');

  // Server-side validation
  if (!Number.isFinite(amount) || amount <= 0) {
    return json(res, 400, { message: 'Invalid amount. Must be a positive integer (paise).' });
  }
  if (amount > 50_000_000) {
    // 5 lakh rupees = 50,000,000 paise — hard cap against accidental overcharges
    return json(res, 400, { message: 'Amount exceeds the maximum allowed order value.' });
  }
  if (!/^BT\d+$/.test(receipt)) {
    return json(res, 400, { message: 'Invalid receipt format.' });
  }

  // Call Razorpay REST API directly — no SDK dependency needed.
  const basicAuth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');

  let rzpData: any;
  try {
    const rzpRes = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Basic ${basicAuth}`,
      },
      body: JSON.stringify({ amount: Math.round(amount), currency, receipt }),
    });
    rzpData = await rzpRes.json();
    if (!rzpRes.ok) {
      const message = rzpData?.error?.description || 'Razorpay order creation failed.';
      return json(res, rzpRes.status, { message });
    }
  } catch (err: any) {
    return json(res, 502, { message: `Could not reach Razorpay: ${err?.message || 'Network error'}` });
  }

  return json(res, 200, {
    id: rzpData.id,
    amount: rzpData.amount,
    currency: rzpData.currency,
    keyId, // public key — safe to return to the client
  });
}
