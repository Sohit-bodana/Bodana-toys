/**
 * Vercel Serverless Function — POST /api/orders/verify-razorpay-payment
 *
 * Verifies the Razorpay payment HMAC-SHA256 signature server-side.
 * The order is only marked paid AFTER the signature passes.
 * The secret key is never exposed to the browser.
 *
 * Required env var (server-only):
 *   RAZORPAY_KEY_SECRET
 *
 * Request body:  { razorpayOrderId, paymentId, signature, localOrderId }
 * Response:      { paymentId, orderId }
 */

import { createHmac, timingSafeEqual } from 'node:crypto';
import { createServer } from 'node:http';

export const config = { runtime: 'nodejs' };

type Req = Parameters<Parameters<typeof createServer>[0]>[0] & { body?: any };
type Res = Parameters<Parameters<typeof createServer>[0]>[1];

function readBody(req: Req): Promise<any> {
  return new Promise((resolve) => {
    if (req.body !== undefined) { resolve(req.body); return; }
    let raw = '';
    req.on('data', (chunk: Buffer | string) => { raw += chunk.toString(); });
    req.on('end', () => { try { resolve(JSON.parse(raw)); } catch { resolve({}); } });
  });
}

function json(res: Res, status: number, data: unknown) {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  });
  res.end(JSON.stringify(data));
}

export default async function handler(req: Req, res: Res) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST', 'Access-Control-Allow-Headers': 'Content-Type,Authorization' });
    res.end();
    return;
  }

  if (req.method !== 'POST') {
    return json(res, 405, { message: 'Method not allowed' });
  }

  const auth = (req.headers as Record<string, string>)['authorization'] || '';
  if (!auth.startsWith('Bearer ')) {
    return json(res, 401, { message: 'Unauthorized.' });
  }

  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keySecret) {
    return json(res, 503, { message: 'Razorpay is not configured on this server.' });
  }

  const body = await readBody(req);
  const { razorpayOrderId, paymentId, signature, localOrderId } = body || {};

  if (!razorpayOrderId || !paymentId || !signature) {
    return json(res, 400, { message: 'Missing required fields: razorpayOrderId, paymentId, signature.' });
  }

  // Razorpay signature = HMAC-SHA256(razorpayOrderId + "|" + paymentId, keySecret)
  const payload = `${razorpayOrderId}|${paymentId}`;
  const expected = createHmac('sha256', keySecret).update(payload).digest('hex');

  // Use constant-time comparison to prevent timing attacks
  let signaturesMatch = false;
  try {
    signaturesMatch = timingSafeEqual(
      Buffer.from(expected, 'hex'),
      Buffer.from(signature, 'hex'),
    );
  } catch {
    signaturesMatch = false;
  }

  if (!signaturesMatch) {
    return json(res, 400, {
      message: 'Payment verification failed. Signature does not match. Do not mark this order as paid.',
    });
  }

  return json(res, 200, { paymentId, orderId: localOrderId });
}
