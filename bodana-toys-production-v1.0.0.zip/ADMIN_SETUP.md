# Bodana Toys — Production setup

## Owner admin
The production admin role is controlled by Firebase/Firestore, not by a hardcoded
email, phone number, or client-side password.

1. Sign in to Firebase Authentication with the owner account.
2. Open Firestore → `users` → that user's Firebase UID.
3. Set the boolean field `isAdmin` to `true`.
4. Keep all other users at `isAdmin: false` or without the field.

For this project, the verified owner account used during setup was
`sohitbodana@gmail.com` with Firebase UID
`Fc6GWrxxzJP8s0f4hF5kVJSpypI2`.

## Vercel environment variables
Required client Firebase variables (Production + Preview):
- VITE_FIREBASE_API_KEY
- VITE_FIREBASE_AUTH_DOMAIN
- VITE_FIREBASE_PROJECT_ID
- VITE_FIREBASE_STORAGE_BUCKET
- VITE_FIREBASE_MESSAGING_SENDER_ID
- VITE_FIREBASE_APP_ID

Do not put Razorpay secrets in VITE_ variables.

## Razorpay
Online payments require these server-only Vercel variables:
- RAZORPAY_KEY_ID
- RAZORPAY_KEY_SECRET

Until both are configured, online checkout will return a clear configuration error.
No fake/demo payment success is enabled.

## Products
When Firebase is configured, Firestore is the authoritative product catalog.
Static/demo products are not merged into the live catalog. Add real products from
the Admin Panel.

## Orders and stock
Authenticated orders are written to Firestore. Inventory reservation uses a
Firestore transaction. If checkout/order creation or payment verification fails,
the reserved stock is returned and a created order is marked cancelled.

## Important
The source package intentionally does not contain Firebase service-account keys,
Razorpay secrets, or an admin password. Those must remain in Firebase/Vercel
environment configuration.
