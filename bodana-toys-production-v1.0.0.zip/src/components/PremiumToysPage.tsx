import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, Home, ShieldCheck, Wrench } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { Product } from '../types';
import ProductCard from './ProductCard';

interface PremiumToysPageProps {
  onBuyNow: (product: Product) => void;
  onProductClick: (product: Product) => void;
}

function ServiceItem({
  icon: Icon,
  label,
}: {
  icon: React.ElementType;
  label: string;
}) {
  return (
    <div className="flex items-center gap-1.5">
      <Icon className="w-3.5 h-3.5 text-green-400 shrink-0" />
      <span className="text-white/70 text-[10px] font-bold">{label}</span>
    </div>
  );
}

export default function PremiumToysPage({ onBuyNow, onProductClick }: PremiumToysPageProps) {
  const { products } = useAppContext();

  const premiumProducts = useMemo(
    () => products
      .filter(product => product.isPremiumLargeToy || product.category === 'premium')
      .sort((a, b) => b.reviews - a.reviews),
    [products],
  );

  return (
    <div className="flex flex-col h-full">
      <div className="px-5 pt-2 pb-3">
        <h2 className="text-2xl font-bold text-white">Premium Toys</h2>
        <p className="text-white/40 text-xs mt-0.5">Large toys delivered and supported by Bodana Toys</p>
      </div>

      <div className="flex-1 overflow-y-auto hide-scrollbar px-4 pb-4">
        {premiumProducts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <CrownIcon />
            <p className="text-white/50 font-bold mt-3">Premium toys coming soon</p>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-2 gap-3"
          >
            {premiumProducts.map((product, index) => {
              const homeDelivery = product.homeDeliveryAvailable !== false;
              const hasWarranty = Boolean(product.warranty);
              const hasInstallation = Boolean(product.installationSupport);

              return (
                <div
                  key={product.id}
                  onClick={() => onProductClick(product)}
                  className="cursor-pointer"
                >
                  <ProductCard product={product} index={index} onBuyNow={onBuyNow} />
                  <div className="mt-2 bg-white/5 border border-white/10 rounded-xl p-2.5 space-y-1.5">
                    {homeDelivery && <ServiceItem icon={Home} label="Home Delivery Available" />}
                    {hasWarranty && <ServiceItem icon={ShieldCheck} label={`Warranty: ${product.warranty}`} />}
                    {hasInstallation && (
                      <ServiceItem icon={Wrench} label={`Installation Support: ${product.installationSupport}`} />
                    )}
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}
      </div>
    </div>
  );
}

function CrownIcon() {
  return <CheckCircle2 className="w-12 h-12 text-yellow-400/30" />;
}