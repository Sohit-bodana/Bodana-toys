import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppContext } from '../context/AppContext';
import { Coupon, Product } from '../types';
import { categories } from '../data';
import {
  Plus, Pencil, Trash2, CheckCircle2, XCircle, Package, Users, Gift, Code, X, Save, Image as ImageIcon
} from 'lucide-react';

type Tab = 'products' | 'customers' | 'rewards' | 'custom';

const topCustomers = [
  { id: 1, name: 'Rahul Sharma', phone: '98765xxxxx', totalOrders: 15, totalSpent: 12500 },
  { id: 2, name: 'Priya Singh', phone: '98765xxxxx', totalOrders: 12, totalSpent: 9800 },
  { id: 3, name: 'Amit Kumar', phone: '98765xxxxx', totalOrders: 10, totalSpent: 8500 },
  { id: 4, name: 'Sneha Patel', phone: '98765xxxxx', totalOrders: 8, totalSpent: 7200 },
  { id: 5, name: 'Vikram Reddy', phone: '98765xxxxx', totalOrders: 7, totalSpent: 6500 },
];

const EMPTY_FORM: Omit<Product, 'id'> = {
  name: '', image: '', originalPrice: 0, discountPrice: 0, discountPercent: 0,
  rating: 5.0, reviews: 0, category: 'c1', section: 'trending',
  description: '', brand: '', ageGroup: '', features: [],
  isOutOfStock: false,
};

export default function AdminPanel() {
  const [activeTab, setActiveTab] = useState<Tab>('products');
  const {
    products, updateProduct, addProduct, deleteProduct, spinRewards, updateSpinRewards,
    customCode, setCustomCode, adminSettings, updateAdminSettings,
  } = useAppContext();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [form, setForm] = useState<Omit<Product, 'id'>>(EMPTY_FORM);
  const [featuresText, setFeaturesText] = useState('');
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState('');
  const [couponForm, setCouponForm] = useState<Omit<Coupon, 'id'>>({
    code: '', discountType: 'percent', value: 10, minOrder: 0, active: true, expiryDate: '',
  });

  const rewards = spinRewards || ['10% OFF', 'FREE SHIPPING', 'NO LUCK', '20% OFF', 'FREE GIFT', 'TRY AGAIN'];

  const computeDiscount = (orig: number, disc: number) =>
    orig > 0 ? Math.round(((orig - disc) / orig) * 100) : 0;

  const openAdd = () => {
    setForm(EMPTY_FORM);
    setFeaturesText('');
    setEditingId(null);
    setShowAddModal(true);
  };

  const openEdit = (product: Product) => {
    setForm({ ...product });
    setFeaturesText((product.features || []).join('\n'));
    setEditingId(product.id);
    setShowAddModal(true);
  };

  const handleSave = async () => {
    if (!form.name.trim() || form.discountPrice <= 0) {
      alert('Product name and price are required.');
      return;
    }
    setSaving(true);
    const finalForm = {
      ...form,
      discountPercent: computeDiscount(form.originalPrice, form.discountPrice),
      features: featuresText.split('\n').map(f => f.trim()).filter(Boolean),
    };
    try {
      if (editingId) {
        await updateProduct(editingId, finalForm);
      } else {
        await addProduct(finalForm);
      }
      setSavedMsg(editingId ? 'Product updated!' : 'Product added!');
      setTimeout(() => setSavedMsg(''), 2000);
      setShowAddModal(false);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (product: Product) => {
    if (!window.confirm(`Delete "${product.name}"? This cannot be undone.`)) return;
    await deleteProduct(product.id);
  };

  const handleAddCoupon = async (event: React.FormEvent) => {
    event.preventDefault();
    const code = couponForm.code.trim().toUpperCase();
    if (!code || couponForm.value <= 0) return;
    if (adminSettings.coupons.some(coupon => coupon.code.toUpperCase() === code)) {
      alert('A coupon with this code already exists.');
      return;
    }
    const coupon: Coupon = { ...couponForm, code, id: `coupon_${Date.now()}` };
    await updateAdminSettings({ coupons: [...adminSettings.coupons, coupon] });
    setCouponForm({ code: '', discountType: 'percent', value: 10, minOrder: 0, active: true, expiryDate: '' });
    setSavedMsg('Coupon created!');
    setTimeout(() => setSavedMsg(''), 2000);
  };

  const handleCouponUpdate = async (id: string, updates: Partial<Coupon>) => {
    const coupons = adminSettings.coupons.map(coupon => coupon.id === id ? { ...coupon, ...updates } : coupon);
    await updateAdminSettings({ coupons });
  };

  const field = (label: string, key: keyof Omit<Product, 'id'>, type = 'text') => (
    <div>
      <label className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-1 block">{label}</label>
      <input
        type={type}
        value={(form[key] as string | number) ?? ''}
        onChange={e => {
          const val = type === 'number' ? Number(e.target.value) : e.target.value;
          setForm(prev => ({ ...prev, [key]: val }));
        }}
        className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 transition-colors"
      />
    </div>
  );

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] overflow-hidden">
      {/* Header */}
      <div className="px-5 pt-5 pb-3 shrink-0">
        <h2 className="text-xl font-bold text-white">Admin Dashboard</h2>
        {savedMsg && (
          <div className="flex items-center gap-1.5 mt-1.5 text-green-400 text-xs font-bold">
            <CheckCircle2 className="w-3.5 h-3.5" /> {savedMsg}
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 px-5 mb-3 shrink-0 overflow-x-auto hide-scrollbar">
        {[
          { id: 'products', label: 'Products', icon: Package },
          { id: 'customers', label: 'Customers', icon: Users },
          { id: 'rewards', label: 'Rewards', icon: Gift },
          { id: 'custom', label: 'Custom Code', icon: Code },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as Tab)}
            className={`flex items-center gap-1.5 px-3 py-2 text-[10px] font-bold uppercase rounded-xl transition-colors whitespace-nowrap shrink-0 ${
              activeTab === t.id ? 'bg-red-600 text-white' : 'bg-white/10 text-white/50 hover:bg-white/15'
            }`}
          >
            <t.icon className="w-3.5 h-3.5" /> {t.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-y-auto hide-scrollbar px-5 pb-24">

        {activeTab === 'products' && (
          <div className="space-y-3">
            <button
              onClick={openAdd}
              className="w-full bg-yellow-400 text-black font-bold py-3 rounded-2xl flex items-center justify-center gap-2 shadow-lg hover:bg-yellow-500 transition-colors"
            >
              <Plus className="w-4 h-4" /> Add New Product
            </button>

            {products.map(product => (
              <div key={product.id} className="bg-white/5 border border-white/10 rounded-2xl p-3 flex gap-3 items-center">
                <img src={product.image} alt={product.name} className="w-14 h-14 rounded-xl object-cover shrink-0" />
                <div className="flex-1 min-w-0">
                  <h4 className="text-white font-bold text-xs truncate">{product.name}</h4>
                  <p className="text-red-400 font-bold text-sm">₹{product.discountPrice.toLocaleString()}</p>
                  <div className="flex items-center gap-1 mt-0.5">
                    {product.isOutOfStock
                      ? <span className="text-red-400 text-[9px] font-bold uppercase">Out of Stock</span>
                      : <span className="text-green-400 text-[9px] font-bold uppercase">In Stock</span>
                    }
                    {product.category && (
                      <span className="text-white/30 text-[9px] font-bold">• {categories.find(c => c.id === product.category)?.name}</span>
                    )}
                  </div>
                </div>
                <div className="flex flex-col gap-1.5 shrink-0">
                  <button
                    onClick={() => openEdit(product)}
                    className="bg-white/10 hover:bg-white/20 text-white p-1.5 rounded-lg transition-colors"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => updateProduct(product.id, { isOutOfStock: !product.isOutOfStock })}
                    className={`p-1.5 rounded-lg transition-colors ${product.isOutOfStock ? 'bg-green-600/20 text-green-400' : 'bg-red-600/20 text-red-400'}`}
                  >
                    {product.isOutOfStock ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    onClick={() => handleDelete(product)}
                    className="bg-red-600/20 hover:bg-red-600/40 text-red-400 p-1.5 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'customers' && (
          <div className="space-y-3">
            {topCustomers.map((c, idx) => (
              <div key={c.id} className="bg-white/5 border border-white/10 rounded-2xl p-4 flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                  idx === 0 ? 'bg-yellow-500 text-black' : idx === 1 ? 'bg-zinc-300 text-black' : idx === 2 ? 'bg-orange-400 text-black' : 'bg-white/10 text-white'
                }`}>#{idx + 1}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-bold text-sm">{c.name}</p>
                  <p className="text-white/40 text-xs">{c.phone} · {c.totalOrders} orders</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-red-400 font-bold text-sm">₹{c.totalSpent.toLocaleString()}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'rewards' && (
          <div className="space-y-3">
            <p className="text-white/40 text-xs mb-4">Edit the 6 spin wheel rewards. Keep them short and enticing.</p>
            {rewards.map((reward, idx) => (
              <div key={idx} className="flex gap-2 items-center">
                <span className="bg-white/10 text-white/50 w-7 h-7 flex items-center justify-center rounded-lg text-xs font-bold shrink-0">{idx + 1}</span>
                <input
                  type="text"
                  value={reward}
                  onChange={e => {
                    const next = [...rewards];
                    next[idx] = e.target.value;
                    updateSpinRewards(next);
                  }}
                  className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 transition-colors"
                />
              </div>
            ))}

            <div className="border-t border-white/10 pt-4 mt-5">
              <p className="text-white font-bold text-sm">Coupons</p>
              <p className="text-white/40 text-xs mt-1 mb-3">Create coupons, change their values, toggle availability, and set expiry dates.</p>
              <form onSubmit={handleAddCoupon} className="bg-white/5 border border-white/10 rounded-2xl p-3 space-y-2">
                <input
                  value={couponForm.code}
                  onChange={event => setCouponForm(prev => ({ ...prev, code: event.target.value }))}
                  placeholder="Coupon code"
                  className="w-full bg-black/30 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm placeholder:text-white/30 focus:outline-none focus:border-red-500"
                />
                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={couponForm.discountType}
                    onChange={event => setCouponForm(prev => ({ ...prev, discountType: event.target.value as Coupon['discountType'] }))}
                    className="bg-black/30 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500"
                  >
                    <option value="percent" className="bg-[#111]">Percent off</option>
                    <option value="flat" className="bg-[#111]">Flat ₹ off</option>
                  </select>
                  <input
                    type="number"
                    min="1"
                    value={couponForm.value}
                    onChange={event => setCouponForm(prev => ({ ...prev, value: Number(event.target.value) }))}
                    placeholder="Value"
                    className="bg-black/30 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm placeholder:text-white/30 focus:outline-none focus:border-red-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    min="0"
                    value={couponForm.minOrder}
                    onChange={event => setCouponForm(prev => ({ ...prev, minOrder: Number(event.target.value) }))}
                    placeholder="Minimum order"
                    className="bg-black/30 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm placeholder:text-white/30 focus:outline-none focus:border-red-500"
                  />
                  <input
                    type="date"
                    value={couponForm.expiryDate || ''}
                    onChange={event => setCouponForm(prev => ({ ...prev, expiryDate: event.target.value }))}
                    className="bg-black/30 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500"
                  />
                </div>
                <button type="submit" className="w-full bg-red-600 text-white font-bold py-2.5 rounded-xl flex items-center justify-center gap-2">
                  <Plus className="w-4 h-4" /> Create Coupon
                </button>
              </form>

              <div className="space-y-2 mt-3">
                {adminSettings.coupons.map(coupon => (
                  <div key={coupon.id} className="bg-white/5 border border-white/10 rounded-2xl p-3 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <input
                        value={coupon.code}
                        onChange={event => handleCouponUpdate(coupon.id, { code: event.target.value.toUpperCase() })}
                        className="flex-1 min-w-0 bg-black/30 border border-white/10 rounded-lg px-2.5 py-2 text-white text-xs font-bold focus:outline-none focus:border-red-500"
                      />
                      <button
                        onClick={() => handleCouponUpdate(coupon.id, { active: !coupon.active })}
                        className={`text-[9px] font-black uppercase px-2 py-1.5 rounded-lg ${coupon.active ? 'bg-green-500/20 text-green-400' : 'bg-white/10 text-white/40'}`}
                      >
                        {coupon.active ? 'Enabled' : 'Disabled'}
                      </button>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <select
                        value={coupon.discountType}
                        onChange={event => handleCouponUpdate(coupon.id, { discountType: event.target.value as Coupon['discountType'] })}
                        className="bg-black/30 border border-white/10 rounded-lg px-2 py-2 text-white text-[10px] focus:outline-none focus:border-red-500"
                      >
                        <option value="percent" className="bg-[#111]">% off</option>
                        <option value="flat" className="bg-[#111]">₹ off</option>
                      </select>
                      <input
                        type="number"
                        min="1"
                        value={coupon.value}
                        onChange={event => handleCouponUpdate(coupon.id, { value: Number(event.target.value) })}
                        className="bg-black/30 border border-white/10 rounded-lg px-2 py-2 text-white text-[10px] focus:outline-none focus:border-red-500"
                      />
                      <input
                        type="date"
                        value={coupon.expiryDate || ''}
                        onChange={event => handleCouponUpdate(coupon.id, { expiryDate: event.target.value })}
                        className="bg-black/30 border border-white/10 rounded-lg px-2 py-2 text-white text-[10px] focus:outline-none focus:border-red-500"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'custom' && (
          <div className="space-y-3">
            <p className="text-white/40 text-xs mb-2">Inject custom HTML, CSS, or JS. Rendered inside the app container.</p>
            <textarea
              value={customCode}
              onChange={e => setCustomCode(e.target.value)}
              placeholder="<!-- Enter custom HTML here -->"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-500 font-mono text-sm h-56 resize-none"
            />
          </div>
        )}
      </div>

      {/* ── Add / Edit Product Modal ── */}
      <AnimatePresence>
        {showAddModal && (
          <>
            <motion.div
              key="bg"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm z-[200]"
            />
            <motion.div
              key="modal"
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', stiffness: 380, damping: 38 }}
              className="absolute inset-x-0 bottom-0 z-[201] bg-[#111] border-t border-white/10 rounded-t-[28px] max-h-[92%] flex flex-col overflow-hidden"
            >
              <div className="flex items-center justify-between px-5 pt-4 pb-3 shrink-0 border-b border-white/10">
                <h3 className="text-white font-bold text-base">{editingId ? 'Edit Product' : 'Add New Product'}</h3>
                <button onClick={() => setShowAddModal(false)} className="w-7 h-7 bg-white/10 rounded-full flex items-center justify-center">
                  <X className="w-4 h-4 text-white" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto hide-scrollbar px-5 py-4 space-y-3">
                {field('Product Name *', 'name')}

                {/* Image URL with preview */}
                <div>
                  <label className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-1 block">Image URL *</label>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      value={form.image || ''}
                      onChange={e => setForm(prev => ({ ...prev, image: e.target.value }))}
                      placeholder="https://..."
                      className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 transition-colors"
                    />
                    {form.image && (
                      <img src={form.image} alt="" className="w-10 h-10 rounded-xl object-cover border border-white/10" />
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {field('Original Price (₹) *', 'originalPrice', 'number')}
                  {field('Sale Price (₹) *', 'discountPrice', 'number')}
                </div>

                <div className="bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs text-white/50">
                  Discount: <span className="text-yellow-400 font-bold">{computeDiscount(form.originalPrice, form.discountPrice)}%</span> off (auto-calculated)
                </div>

                {/* Category */}
                <div>
                  <label className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-1 block">Category</label>
                  <select
                    value={form.category || ''}
                    onChange={e => setForm(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 appearance-none"
                  >
                    {categories.filter(c => c.id !== 'all').map(c => (
                      <option key={c.id} value={c.id} className="bg-[#111]">{c.name}</option>
                    ))}
                  </select>
                </div>

                {/* Section */}
                <div>
                  <label className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-1 block">Homepage Section</label>
                  <select
                    value={form.section || ''}
                    onChange={e => setForm(prev => ({ ...prev, section: e.target.value }))}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 appearance-none"
                  >
                    <option value="" className="bg-[#111]">None (Categories only)</option>
                    <option value="trending" className="bg-[#111]">Trending Now</option>
                    <option value="bestSellers" className="bg-[#111]">Best Sellers</option>
                    <option value="newArrivals" className="bg-[#111]">New Arrivals</option>
                    <option value="todayDeals" className="bg-[#111]">Today's Deals</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {field('Brand', 'brand')}
                  {field('Age Group', 'ageGroup')}
                </div>

                {field('Rating (0-5)', 'rating', 'number')}

                <div>
                  <label className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-1 block">Description</label>
                  <textarea
                    value={form.description || ''}
                    onChange={e => setForm(prev => ({ ...prev, description: e.target.value }))}
                    rows={3}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 resize-none"
                  />
                </div>

                <div>
                  <label className="text-white/40 text-[10px] font-bold uppercase tracking-wider mb-1 block">Features (one per line)</label>
                  <textarea
                    value={featuresText}
                    onChange={e => setFeaturesText(e.target.value)}
                    placeholder="500+ bubbles/minute&#10;Non-toxic solution&#10;USB rechargeable"
                    rows={4}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 resize-none placeholder:text-white/20"
                  />
                </div>

                <div className="flex items-center justify-between bg-white/5 border border-white/10 rounded-xl px-4 py-3">
                  <span className="text-white text-sm font-bold">Mark as Out of Stock</span>
                  <button
                    onClick={() => setForm(prev => ({ ...prev, isOutOfStock: !prev.isOutOfStock }))}
                    className={`w-10 h-6 rounded-full transition-colors relative ${form.isOutOfStock ? 'bg-red-600' : 'bg-white/20'}`}
                  >
                    <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${form.isOutOfStock ? 'translate-x-5' : 'translate-x-1'}`} />
                  </button>
                </div>
              </div>

              <div className="px-5 py-4 border-t border-white/10 shrink-0">
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="w-full bg-red-600 disabled:bg-white/10 disabled:text-white/30 text-white font-bold py-3.5 rounded-2xl hover:bg-red-700 transition-colors flex items-center justify-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  {saving ? 'Saving…' : editingId ? 'Save Changes' : 'Add Product'}
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
