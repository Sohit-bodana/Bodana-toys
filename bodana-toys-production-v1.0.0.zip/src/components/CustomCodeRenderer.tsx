import React, { useEffect, useRef } from 'react';

export default function CustomCodeRenderer({ code }: { code: string }) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    
    containerRef.current.innerHTML = '';
    
    const wrapper = document.createElement('div');
    wrapper.innerHTML = code;
    
    Array.from(wrapper.childNodes).forEach(node => {
      containerRef.current?.appendChild(node.cloneNode(true));
    });
    
    // Scripts inserted via innerHTML don't execute; recreate them manually
    const scripts = containerRef.current.querySelectorAll('script');
    scripts.forEach(oldScript => {
      const newScript = document.createElement('script');
      Array.from(oldScript.attributes).forEach((attr: Attr) => {
        newScript.setAttribute(attr.name, attr.value);
      });
      newScript.appendChild(document.createTextNode(oldScript.innerHTML));
      oldScript.parentNode?.replaceChild(newScript, oldScript);
    });
    
  }, [code]);

  return <div ref={containerRef} className="custom-code-container" />;
}
