import React, { useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronRight, MapPin, CreditCard, CheckCircle2, Truck, AlertCircle, Package } from 'lucide-react';
import { CartItem } from '../context/CartContext';
import { useOrders } from '../context/OrderContext';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { CheckoutAddress } from '../types';
import { createRazorpayOrder, openRazorpayCheckout, verifyRazorpayPayment } from '../lib/razorpay';
import { useAppContext } from '../context/AppContext';
import { useRewards } from '../context/RewardsContext';
import { SavedReward } from '../types';

type Step = 'address' | 'payment' | 'processing' | 'success';
type PaymentMethod = 'online' | 'cod';

/** True when RAZORPAY_KEY_ID + RAZORPAY_KEY_SECRET are set in the environment. */
interface CheckoutOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onOrderComplete?: () => void;
}

const INDIAN_STATES = [
  'Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat',
  'Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh',
  'Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab',
  'Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh',
  'Uttarakhand','West Bengal','Delhi','Jammu & Kashmir','Ladakh',
];

const DELIVERY_FEE = 0; // free delivery (customizable)

export default function CheckoutOverlay({ isOpen, onClose, items, onOrderComplete }: CheckoutOverlayProps) {
  const { user } = useAuth();
  const { createOrder, updateOrderStatus, markOrderPaid } = useOrders();
  const { clearCart } = useCart();
  const { reserveStock, releaseStock, getProductStock } = useAppContext();
  const { availableRewards, markRewardUsed } = useRewards();

  const [step, setStep] = useState<Step>('address');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('online');
  const [error, setError] = useState('');
  const [successOrderId, setSuccessOrderId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedRewardId, setSelectedRewardId] = useState('');
  const idempotencyKeyRef = useRef(`checkout_${Date.now()}_${Math.random().toString(36).slice(2)}`);
  const resetIdempotencyKey = () => {
    idempotencyKeyRef.current = `checkout_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  };

  const subtotal = items.reduce((s, i) => s + i.discountPrice * i.quantity, 0);
  const selectedReward = availableRewards.find(reward => reward.id === selectedRewardId);
  const rewardDiscount = selectedReward ? calculateRewardDiscount(selectedReward, subtotal) : 0;
  const total = Math.max(0, subtotal + DELIVERY_FEE - rewardDiscount);
  const hasPremiumLargeToy = items.some(item => item.isPremiumLargeToy || item.category === 'premium');

  const savedAddress = user?.addresses?.[0];
  const [address, setAddress] = useState<CheckoutAddress>({
    fullName: user?.displayName || '',
    phone: user?.phone || '',
    line1: savedAddress?.line1 || '',
    line2: savedAddress?.line2 || '',
    city: savedAddress?.city || '',
    state: savedAddress?.state || '',
    pincode: savedAddress?.pincode || '',
  });

  const field = (
    label: string,
    key: keyof CheckoutAddress,
    type = 'text',
    required = true,
  ) => (
    <div>
      <label className="text-white/50 text-[10px] font-bold uppercase tracking-wider mb-1 block">{label}{required ? ' *' : ''}</label>
      <input
        type={type}
        value={address[key] || ''}
        onChange={e => setAddress(prev => ({ ...prev, [key]: e.target.value }))}
        required={required}
        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-white/20 focus:outline-none focus:border-red-500 text-sm transition-colors"
      />
    </div>
  );

  const validateAddress = () => {
    if (address.fullName.trim().length < 2) return 'Enter the recipient’s full name';
    if (!/^[6-9]\d{9}$/.test(address.phone.replace(/\D/g, ''))) return 'Enter a valid 10-digit Indian phone number';
    if (address.line1.trim().length < 5) return 'Enter a complete address';
    if (!/^[a-zA-Z\s.'-]{2,}$/.test(address.city.trim())) return 'Enter a valid city';
    if (!INDIAN_STATES.includes(address.state)) return 'Select a valid state';
    if (!/^[1-9]\d{5}$/.test(address.pincode.trim())) return 'Enter a valid 6-digit pincode';
    return '';
  };

  const validateStock = () => {
    if (!items.length) return 'Your cart is empty';
    for (const item of items) {
      const available = getProductStock(item.id);
      if (available < item.quantity) {
        return available === 0
          ? `${item.name} is out of stock. Please remove it from your cart.`
          : `Only ${available} unit${available === 1 ? '' : 's'} of ${item.name} ${available === 1 ? 'is' : 'are'} available.`;
      }
    }
    return '';
  };

  const handlePlaceOrder = async () => {
    if (isSubmitting) return;
    setError('');
    const validationError = validateAddress();
    if (validationError) { setError(validationError); return; }
    const stockError = validateStock();
    if (stockError) { setError(stockError); return; }

    setIsSubmitting(true);
    setStep('processing');

    let createdOrderId = '';
    let stockReserved = false;

    try {
      const currentStockError = validateStock();
      if (currentStockError) throw new Error(currentStockError);

      const reservation = await reserveStock(items);
      if (!reservation.success) throw new Error(reservation.message || 'Stock is no longer available.');
      stockReserved = true;

      const localOrderId = `BT${Date.now()}`;

      if (paymentMethod === 'cod') {
        const order = await createOrder(items, total, 'cod', address, undefined, {
          idempotencyKey: idempotencyKeyRef.current,
          orderId: localOrderId,
          paymentStatus: 'pending',
        });
        if (!order) throw new Error('Could not create the order. Please try again.');
        createdOrderId = order.id;
        if (selectedReward) await markRewardUsed(selectedReward.id);
        setSuccessOrderId(order.id);
        onOrderComplete?.();
        clearCart();
        resetIdempotencyKey();
        setStep('success');
        return;
      }

      const order = await createOrder(items, total, 'online', address, undefined, {
        idempotencyKey: idempotencyKeyRef.current,
        orderId: localOrderId,
        paymentStatus: 'pending',
      });
      if (!order) throw new Error('Could not create the order. Please try again.');
      createdOrderId = order.id;

      const razorpayOrder = await createRazorpayOrder(total, order.id);
      const result = await openRazorpayCheckout({
        amount: total,
        orderId: order.id,
        razorpayOrderId: razorpayOrder.id,
        razorpayKeyId: razorpayOrder.keyId,
        address,
        userEmail: user?.email,
      });
      const verification = await verifyRazorpayPayment({
        localOrderId: order.id,
        razorpayOrderId: razorpayOrder.id,
        paymentId: result.paymentId || '',
        signature: result.signature || '',
      });

      await markOrderPaid(order.id, verification.paymentId);
      if (selectedReward) await markRewardUsed(selectedReward.id);
      setSuccessOrderId(order.id);
      onOrderComplete?.();
      clearCart();
      resetIdempotencyKey();
      setStep('success');
    } catch (err: any) {
      // The inventory reservation is only valid for a successful COD order or
      // verified online payment. Return stock when payment/order creation fails.
      if (stockReserved) {
        try { await releaseStock(items); } catch { /* surface the original error */ }
      }
      if (createdOrderId) {
        try { await updateOrderStatus(createdOrderId, 'cancelled'); } catch { /* best effort */ }
      }
      setError(err?.message || 'We could not place the order. Please try again.');
      setStep('payment');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setStep('address');
    setError('');
    setIsSubmitting(false);
    setSelectedRewardId('');
    resetIdempotencyKey();
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            key="bg"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={step !== 'processing' ? handleClose : undefined}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm z-[160]"
          />

          <motion.div
            key="panel"
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 380, damping: 38 }}
            className="absolute inset-x-0 bottom-0 z-[161] bg-[#0d0d0d] rounded-t-[32px] border-t border-white/10 flex flex-col max-h-[95%] overflow-hidden"
          >
            {/* Handle */}
            <div className="flex justify-center pt-3 pb-2 shrink-0">
              <div className="w-10 h-1 bg-white/20 rounded-full" />
            </div>

            {/* Header */}
            {step !== 'success' && step !== 'processing' && (
              <div className="flex items-center justify-between px-5 pb-3 shrink-0">
                <div>
                  <h2 className="text-xl font-bold text-white">Checkout</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <StepDot active={step === 'address'} done={step === 'payment'} label="Address" />
                    <div className="w-6 h-px bg-white/20" />
                    <StepDot active={step === 'payment'} done={false} label="Payment" />
                  </div>
                </div>
                <button onClick={handleClose} className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center">
                  <X className="w-4 h-4 text-white" />
                </button>
              </div>
            )}

            {/* ── STEP: Address ── */}
            {step === 'address' && (
              <div className="flex-1 overflow-y-auto hide-scrollbar px-5 pb-4 space-y-3">
                <div className="flex items-center gap-2 mb-1">
                  <MapPin className="w-4 h-4 text-red-400" />
                  <span className="text-white font-bold text-sm">Delivery Address</span>
                </div>

                {/* Pre-fill from saved address */}
                {user?.addresses && user.addresses.length > 0 && (
                  <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-2">
                    {user.addresses.map(addr => (
                      <button
                        key={addr.id}
                        onClick={() => setAddress({
                          fullName: user.displayName || address.fullName,
                          phone: user.phone || address.phone,
                          line1: addr.line1,
                          line2: addr.line2 || '',
                          city: addr.city,
                          state: addr.state,
                          pincode: addr.pincode,
                        })}
                        className="shrink-0 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-left hover:border-red-500/50 transition-colors"
                      >
                        <div className="text-white text-xs font-bold">{addr.title}</div>
                        <div className="text-white/40 text-[10px]">{addr.city}</div>
                      </button>
                    ))}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">{field('Full Name', 'fullName')}</div>
                  <div className="col-span-2">{field('Phone Number', 'phone', 'tel')}</div>
                  <div className="col-span-2">{field('Address Line 1', 'line1')}</div>
                  <div className="col-span-2">{field('Address Line 2 (optional)', 'line2', 'text', false)}</div>
                  <div>{field('City', 'city')}</div>
                  <div>
                    <label className="text-white/50 text-[10px] font-bold uppercase tracking-wider mb-1 block">State *</label>
                    <select
                      value={address.state}
                      onChange={e => setAddress(prev => ({ ...prev, state: e.target.value }))}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 text-sm transition-colors appearance-none relative z-10 cursor-pointer"
                    >
                      <option value="" className="bg-[#0d0d0d]">Select</option>
                      {INDIAN_STATES.map(s => (
                        <option key={s} value={s} className="bg-[#0d0d0d]">{s}</option>
                      ))}
                    </select>
                  </div>
                  <div className="col-span-2">{field('Pincode', 'pincode', 'number')}</div>
                </div>

                {/* Order summary mini */}
                 <OrderSummary items={items} subtotal={subtotal} delivery={DELIVERY_FEE} discount={rewardDiscount} total={total} />

                {hasPremiumLargeToy && <PremiumDeliveryNote />}

                {error && <ErrorBanner message={error} />}

                <button
                  onClick={() => {
                    const e = validateAddress();
                    if (e) { setError(e); return; }
                    setError('');
                    setStep('payment');
                  }}
                  className="w-full bg-red-600 text-white font-bold py-4 rounded-2xl hover:bg-red-700 transition-colors flex items-center justify-center gap-2 shadow-[0_4px_14px_rgba(220,38,38,0.4)] mt-2"
                >
                  Continue to Payment <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* ── STEP: Payment ── */}
            {step === 'payment' && (
              <div className="flex-1 overflow-y-auto hide-scrollbar px-5 pb-4 space-y-4">
                <div className="flex items-center gap-2 mb-1">
                  <CreditCard className="w-4 h-4 text-red-400" />
                  <span className="text-white font-bold text-sm">Payment Method</span>
                </div>

                {/* Address recap */}
                <div className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-white/40 shrink-0 mt-0.5" />
                  <div>
                    <div className="text-white text-sm font-bold">{address.fullName}</div>
                    <div className="text-white/50 text-xs">{address.line1}, {address.city}, {address.state} — {address.pincode}</div>
                    <button onClick={() => setStep('address')} className="text-red-400 text-[10px] font-bold mt-1">Change</button>
                  </div>
                </div>

                {/* Payment options */}
                <div className="space-y-3">
                  {/* Online (Razorpay) */}
                  <PaymentOption
                    id="online"
                    selected={paymentMethod === 'online'}
                    onSelect={() => setPaymentMethod('online')}
                    icon={<CreditCard className="w-5 h-5 text-blue-400" />}
                    title="Pay Online"
                    subtitle="UPI, Cards, NetBanking via Razorpay"
                    badge="Razorpay"
                  />
                  {/* COD */}
                  <PaymentOption
                    id="cod"
                    selected={paymentMethod === 'cod'}
                    onSelect={() => setPaymentMethod('cod')}
                    icon={<Package className="w-5 h-5 text-yellow-400" />}
                    title="Cash on Delivery"
                    subtitle="Pay when you receive the order"
                  />
                </div>

                 <RewardPicker
                   rewards={availableRewards}
                   selectedRewardId={selectedRewardId}
                   onSelect={setSelectedRewardId}
                   subtotal={subtotal}
                 />
                 <OrderSummary items={items} subtotal={subtotal} delivery={DELIVERY_FEE} discount={rewardDiscount} total={total} />

                {hasPremiumLargeToy && <PremiumDeliveryNote />}

                {error && <ErrorBanner message={error} />}

                <button
                  onClick={handlePlaceOrder}
                  disabled={isSubmitting}
                  className="w-full bg-red-600 text-white font-bold py-4 rounded-2xl hover:bg-red-700 transition-colors flex items-center justify-center gap-2 shadow-[0_4px_14px_rgba(220,38,38,0.4)]"
                >
                  {paymentMethod === 'cod' ? (
                    <><Truck className="w-4 h-4" /> Place Order (COD)</>
                  ) : (
                    <><CreditCard className="w-4 h-4" /> Pay ₹{total.toLocaleString()}</>
                  )}
                </button>
              </div>
            )}

            {/* ── STEP: Processing ── */}
            {step === 'processing' && (
              <div className="flex-1 flex flex-col items-center justify-center px-8 text-center gap-4">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  className="w-12 h-12 border-4 border-red-500 border-t-transparent rounded-full"
                />
                <p className="text-white font-bold text-lg">Processing your order…</p>
                <p className="text-white/40 text-sm">Please wait, don't close this window.</p>
              </div>
            )}

            {/* ── STEP: Success ── */}
            {step === 'success' && (
              <div className="flex-1 flex flex-col items-center justify-center px-8 text-center gap-4 pb-8">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', bounce: 0.5 }}
                >
                  <CheckCircle2 className="w-20 h-20 text-green-500" />
                </motion.div>
                <div>
                  <h2 className="text-2xl font-black text-white mb-2">Order Placed!</h2>
                  <p className="text-white/50 text-sm">Your order has been confirmed and will be delivered soon.</p>
                  {successOrderId && (
                    <p className="text-white/30 text-xs mt-2 font-mono">Order ID: #{successOrderId}</p>
                  )}
                </div>
                <div className="flex flex-col gap-3 w-full mt-4">
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex items-center gap-3">
                    <Truck className="w-5 h-5 text-blue-400 shrink-0" />
                    <div className="text-left">
                      <div className="text-white font-bold text-sm">Estimated Delivery</div>
                      <div className="text-white/50 text-xs">3–7 business days</div>
                    </div>
                  </div>
                  <button
                    onClick={handleClose}
                    className="w-full bg-red-600 text-white font-bold py-3.5 rounded-2xl hover:bg-red-700 transition-colors"
                  >
                    Continue Shopping
                  </button>
                </div>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function StepDot({ active, done, label }: { active: boolean; done: boolean; label: string }) {
  return (
    <div className="flex items-center gap-1">
      <div className={`w-2 h-2 rounded-full ${done ? 'bg-green-500' : active ? 'bg-red-500' : 'bg-white/20'}`} />
      <span className={`text-[10px] font-bold ${active ? 'text-white' : done ? 'text-green-400' : 'text-white/30'}`}>{label}</span>
    </div>
  );
}

function PaymentOption({ id, selected, onSelect, icon, title, subtitle, badge }: {
  id: string; selected: boolean; onSelect: () => void;
  icon: React.ReactNode; title: string; subtitle: string; badge?: string;
}) {
  return (
    <button
      onClick={onSelect}
      className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl border transition-colors text-left ${
        selected ? 'bg-red-600/10 border-red-500/50' : 'bg-white/5 border-white/10'
      }`}
    >
      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
        selected ? 'border-red-500' : 'border-white/30'
      }`}>
        {selected && <div className="w-2.5 h-2.5 bg-red-500 rounded-full" />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-white font-bold text-sm">{title}</span>
          {badge && <span className="text-[9px] bg-yellow-400 text-black font-black px-1.5 py-0.5 rounded uppercase">{badge}</span>}
        </div>
        <div className="text-white/40 text-xs mt-0.5">{subtitle}</div>
      </div>
      {icon}
    </button>
  );
}

function OrderSummary({ items, subtotal, delivery, discount = 0, total }: {
  items: CartItem[]; subtotal: number; delivery: number; discount?: number; total: number;
}) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3">
      <div className="text-white font-bold text-sm mb-2 uppercase tracking-wider">Order Summary</div>
      <div className="space-y-2 max-h-32 overflow-y-auto hide-scrollbar">
        {items.map(item => (
          <div key={item.id} className="flex items-center gap-2">
            <img src={item.image} alt={item.name} className="w-8 h-8 rounded-lg object-cover" />
            <div className="flex-1 min-w-0">
              <div className="text-white text-xs font-bold truncate">{item.name}</div>
              <div className="text-white/40 text-[10px]">Qty: {item.quantity}</div>
            </div>
            <div className="text-white text-xs font-bold">₹{(item.discountPrice * item.quantity).toLocaleString()}</div>
          </div>
        ))}
      </div>
      <div className="border-t border-white/10 pt-2 space-y-1.5">
        <div className="flex justify-between text-sm">
          <span className="text-white/50">Subtotal</span>
          <span className="text-white">₹{subtotal.toLocaleString()}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-white/50">Delivery</span>
          <span className="text-green-400 font-bold">{delivery === 0 ? 'FREE' : `₹${delivery}`}</span>
        </div>
        {discount > 0 && (
          <div className="flex justify-between text-sm">
            <span className="text-white/50">Reward discount</span>
            <span className="text-green-400 font-bold">-₹{discount.toLocaleString()}</span>
          </div>
        )}
        <div className="flex justify-between font-black text-base border-t border-white/10 pt-2 mt-2">
          <span className="text-white">Total</span>
          <span className="text-white">₹{total.toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
}

function calculateRewardDiscount(reward: SavedReward, subtotal: number) {
  if (reward.title.trim().toUpperCase() === 'FREE SHIPPING') return 0;
  if (reward.minOrder && subtotal < reward.minOrder) return 0;
  if (reward.type === 'giftCard') return Math.min(subtotal, reward.balance || 0);
  if (reward.discountType === 'percent') return Math.min(subtotal, Math.round(subtotal * (reward.value || 0) / 100));
  return Math.min(subtotal, reward.value || 0);
}

function canRedeemReward(reward: SavedReward, subtotal: number) {
  if (reward.minOrder && subtotal < reward.minOrder) return false;
  return reward.title.trim().toUpperCase() === 'FREE SHIPPING' ||
    reward.type === 'spin' ||
    reward.type === 'offer' ||
    reward.type === 'giftCard' ||
    Boolean(reward.discountType && reward.value);
}

function RewardPicker({
  rewards,
  selectedRewardId,
  onSelect,
  subtotal,
}: {
  rewards: SavedReward[];
  selectedRewardId: string;
  onSelect: (id: string) => void;
  subtotal: number;
}) {
  if (rewards.length === 0) return null;
  return (
    <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-white font-bold text-sm">Use a reward</span>
        {selectedRewardId && <button onClick={() => onSelect('')} className="text-red-400 text-[10px] font-bold">Remove</button>}
      </div>
      {rewards.map(reward => {
        const discount = calculateRewardDiscount(reward, subtotal);
        const blocked = !canRedeemReward(reward, subtotal);
        return (
          <button
            key={reward.id}
            disabled={blocked}
            onClick={() => onSelect(reward.id)}
            className={`w-full flex items-center justify-between gap-2 rounded-xl border px-3 py-2 text-left transition-colors ${
              selectedRewardId === reward.id ? 'border-green-500/50 bg-green-500/10' : 'border-white/10 bg-black/20'
            } ${blocked ? 'opacity-40 cursor-not-allowed' : 'hover:border-red-500/50'}`}
          >
            <span className="text-white text-xs font-bold truncate">{reward.title}</span>
            <span className="text-green-400 text-[10px] font-bold shrink-0">
              {blocked
                ? `Min ₹${reward.minOrder?.toLocaleString()}`
                : reward.title.trim().toUpperCase() === 'FREE SHIPPING'
                  ? 'Free delivery'
                  : discount > 0
                    ? `Save ₹${discount.toLocaleString()}`
                    : 'Redeem reward'}
            </span>
          </button>
        );
      })}
    </div>
  );
}

function ErrorBanner({ message }: { message: string }) {
  return (
    <div className="flex items-start gap-2 bg-red-500/10 border border-red-500/30 rounded-xl px-3 py-2">
      <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
      <span className="text-red-400 text-xs font-bold">{message}</span>
    </div>
  );
}

function PremiumDeliveryNote() {
  return (
    <div className="bg-white/5 border border-white/10 rounded-2xl p-4">
      <div className="flex items-center gap-2 mb-2">
        <Truck className="w-4 h-4 text-red-400" />
        <span className="text-white font-bold text-sm">Home Delivery by Bodana Toys</span>
      </div>
      <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
        {['Genuine Warranty', 'Installation Support', 'Local Delivery', 'Safe Packaging', 'Heavy Item Delivery'].map(item => (
          <span key={item} className="text-white/60 text-[10px] font-bold">✓ {item}</span>
        ))}
      </div>
    </div>
  );
}
