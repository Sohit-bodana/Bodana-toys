import { Product } from '../types';
import ProductCard from './ProductCard';

interface ProductSectionProps {
  title: string;
  products: Product[];
  viewAll?: boolean;
  onBuyNow?: (product: Product) => void;
  onProductClick?: (product: Product) => void;
}

export default function ProductSection({ title, products, viewAll = true, onBuyNow, onProductClick }: ProductSectionProps) {
  return (
    <div className="mt-8">
      <div className="flex justify-between items-center px-6 mb-4">
        <h3 className="text-white font-bold text-sm uppercase tracking-wide">{title}</h3>
        {viewAll && (
          <div className="flex gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-red-600"></span>
            <span className="w-1.5 h-1.5 rounded-full bg-white/20"></span>
          </div>
        )}
      </div>
      
      <div className="flex overflow-x-auto hide-scrollbar px-6 gap-4 pb-4">
        {products.map((product, index) => (
          <div
            key={product.id}
            className="min-w-[160px] max-w-[160px] cursor-pointer"
            onClick={() => onProductClick?.(product)}
          >
            <ProductCard product={product} index={index} onBuyNow={onBuyNow} />
          </div>
        ))}
      </div>
    </div>
  );
}
