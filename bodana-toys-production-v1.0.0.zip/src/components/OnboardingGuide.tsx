import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, Home, LayoutGrid, Search, Heart, ShoppingBag, CreditCard, Package } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const slides = [
  { icon: Home, title: "Home", desc: "Discover trending toys and exclusive deals directly on the home screen." },
  { icon: LayoutGrid, title: "Categories", desc: "Easily find what you need by browsing our curated toy categories." },
  { icon: Search, title: "Search", desc: "Looking for something specific? Use our powerful search feature." },
  { icon: Heart, title: "Wishlist", desc: "Save your favorite toys and come back to them anytime." },
  { icon: ShoppingBag, title: "Cart", desc: "Review your items and proceed to a secure checkout experience." },
  { icon: CreditCard, title: "Buy Now", desc: "Purchase instantly with our fast and secure buy now option." },
  { icon: Package, title: "Order Tracking", desc: "Track your orders in real-time until they reach your doorstep." }
];

export default function OnboardingGuide() {
  const { hasCompletedOnboarding, completeOnboarding } = useAuth();
  const [currentSlide, setCurrentSlide] = useState(0);

  if (hasCompletedOnboarding) return null;

  const handleNext = () => {
    if (currentSlide === slides.length - 1) {
      completeOnboarding();
    } else {
      setCurrentSlide(prev => prev + 1);
    }
  };

  const SlideIcon = slides[currentSlide].icon;

  return (
    <div className="absolute inset-0 z-[300] bg-black/95 backdrop-blur-xl flex flex-col items-center justify-center p-6 text-center">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 1.1, y: -20 }}
          transition={{ duration: 0.3 }}
          className="flex flex-col items-center max-w-sm"
        >
          <div className="w-24 h-24 rounded-full bg-red-600/20 border border-red-500/30 flex items-center justify-center mb-8 shadow-[0_0_30px_rgba(220,38,38,0.2)]">
            <SlideIcon className="w-10 h-10 text-red-500" />
          </div>
          
          <h2 className="text-3xl font-black text-white mb-4 tracking-tight">
            {slides[currentSlide].title}
          </h2>
          
          <p className="text-white/60 text-base leading-relaxed mb-12">
            {slides[currentSlide].desc}
          </p>
        </motion.div>
      </AnimatePresence>

      <div className="absolute bottom-12 left-0 right-0 px-8 flex flex-col items-center gap-8">
        <div className="flex gap-2">
          {slides.map((_, i) => (
            <div 
              key={i} 
              className={`h-1.5 rounded-full transition-all duration-300 ${i === currentSlide ? 'w-8 bg-red-500' : 'w-2 bg-white/20'}`}
            />
          ))}
        </div>
        
        <button 
          onClick={handleNext}
          className="w-full max-w-[280px] bg-white text-black font-bold py-4 rounded-xl flex items-center justify-center gap-2 hover:bg-neutral-200 transition-colors shadow-[0_0_20px_rgba(255,255,255,0.1)]"
        >
          {currentSlide === slides.length - 1 ? 'Get Started' : 'Next'}
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
