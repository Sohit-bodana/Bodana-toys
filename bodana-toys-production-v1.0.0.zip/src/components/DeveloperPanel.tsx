import React, { useState } from 'react';
import { useDeveloper, DeveloperSettings } from '../context/DeveloperContext';
import { useAuth } from '../context/AuthContext';
import { useAppContext } from '../context/AppContext';
import { useOrders } from '../context/OrderContext';
import { categories } from '../data';
import {
  Shield, Lock, Undo, Clock, Image, Type, Palette, Layout,
  Settings2, Code, Zap, X, Package, Users, Tag, ShoppingBag,
  Edit, Trash, Plus, Save, CheckCircle2
} from 'lucide-react';

type Tab = 'ui' | 'sections' | 'code' | 'history' | 'products' | 'orders' | 'customers' | 'coupons';

export default function DeveloperPanel({ onClose }: { onClose: () => void }) {
  const { user, unlockDeveloper } = useAuth();
  const { settings, updateSettings, backups, restoreBackup, undo } = useDeveloper();
  const { products, addProduct, updateProduct, deleteProduct } = useAppContext();
  const { orders, updateOrderStatus } = useOrders();

  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [pwError, setPwError] = useState('');
  const [activeTab, setActiveTab] = useState<Tab>('ui');
  const [savedMsg, setSavedMsg] = useState('');

  // Developer access is populated by AuthContext after server-side Firebase authorization.
  const isDeveloper = !!user?.isDeveloper;

  if (!isDeveloper) {
    return (
      <div className="absolute inset-0 bg-[#0a0a0a] z-[400] p-6 flex flex-col items-center justify-center text-center">
        <button onClick={onClose} className="absolute top-6 right-6 bg-white/10 text-white p-2 rounded-xl hover:bg-white/20 transition-colors">
          <X className="w-5 h-5" />
        </button>
        <Shield className="w-16 h-16 text-red-500/50 mb-4" />
        <h2 className="text-xl font-bold text-white mb-2">Access Denied</h2>
        <p className="text-white/50 text-sm">You do not have permission to access the Developer Panel.</p>
      </div>
    );
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await unlockDeveloper(password);
      setIsAuthenticated(true);
      setPwError('');
    } catch (error) {
      setPwError((error as { message?: string })?.message || 'Invalid master password');
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="absolute inset-0 bg-[#0a0a0a] z-[400] p-6 flex flex-col items-center justify-center">
        <button onClick={onClose} className="absolute top-6 right-6 bg-white/10 text-white p-2 rounded-xl hover:bg-white/20 transition-colors">
          <X className="w-5 h-5" />
        </button>
        <div className="w-full max-w-sm bg-white/5 border border-red-500/30 rounded-3xl p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/20 rounded-full blur-3xl -z-10" />
          <div className="flex flex-col items-center text-center mb-6">
            <div className="w-16 h-16 bg-red-500/10 rounded-2xl flex items-center justify-center mb-4 border border-red-500/30">
              <Lock className="w-8 h-8 text-red-500" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-1">Developer Mode</h2>
            <p className="text-white/50 text-xs">Enter master password to unlock system settings.</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <input
              type="password"
              placeholder="Master Password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              autoFocus
              className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-500 transition-colors"
            />
            {pwError && <p className="text-red-500 text-xs font-bold text-center">{pwError}</p>}
            <button type="submit" className="w-full bg-red-600 text-white font-bold py-3.5 rounded-xl hover:bg-red-700 transition-colors shadow-lg">
              Unlock Panel
            </button>
          </form>
        </div>
      </div>
    );
  }

  const showSaved = () => {
    setSavedMsg('Saved!');
    setTimeout(() => setSavedMsg(''), 2000);
  };

  const handleSettingChange = <K extends keyof DeveloperSettings>(key: K, value: DeveloperSettings[K]) => {
    updateSettings({ [key]: value });
    showSaved();
  };

  const tabs: { id: Tab; label: string; icon: React.ComponentType<any> }[] = [
    { id: 'ui',        label: 'UI',       icon: Layout },
    { id: 'sections',  label: 'Sections', icon: Settings2 },
    { id: 'code',      label: 'Code',     icon: Code },
    { id: 'history',   label: 'History',  icon: Clock },
    { id: 'products',  label: 'Products', icon: Package },
    { id: 'orders',    label: 'Orders',   icon: ShoppingBag },
    { id: 'customers', label: 'Customers',icon: Users },
    { id: 'coupons',   label: 'Coupons',  icon: Tag },
  ];

  return (
    <div className="absolute inset-0 bg-[#0a0a0a] z-[400] flex flex-col h-full w-full overflow-hidden">
      {/* Header */}
      <div className="flex justify-between items-center px-5 pt-5 pb-3 shrink-0">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-400" /> Developer Panel
          </h2>
          <p className="text-white/40 text-[10px] mt-0.5">
            {user?.displayName || user?.email || user?.phone || 'Developer'} · Super Admin
          </p>
        </div>
        <div className="flex items-center gap-2">
          {savedMsg && (
            <span className="text-green-400 text-xs font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> {savedMsg}
            </span>
          )}
          <button
            onClick={undo}
            disabled={backups.length === 0}
            className="bg-white/10 text-white font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 hover:bg-white/20 disabled:opacity-40 transition-colors text-xs"
          >
            <Undo className="w-3.5 h-3.5" /> Undo
          </button>
          <button onClick={onClose} className="bg-white/10 text-white p-2 rounded-xl hover:bg-white/20 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 px-5 overflow-x-auto hide-scrollbar pb-2 shrink-0">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`flex items-center gap-1.5 px-3 py-2 text-[10px] font-bold uppercase rounded-xl transition-colors whitespace-nowrap shrink-0 ${
              activeTab === t.id ? 'bg-red-600 text-white shadow-lg' : 'bg-white/10 text-white/50 hover:bg-white/15'
            }`}
          >
            <t.icon className="w-3.5 h-3.5" /> {t.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-y-auto hide-scrollbar px-5 pb-24">

        {/* ── UI Settings ── */}
        {activeTab === 'ui' && (
          <div className="space-y-4 mt-2">
            <FieldLabel icon={Type} label="Banner Title">
              <input type="text" value={settings.bannerTitle}
                onChange={e => handleSettingChange('bannerTitle', e.target.value)}
                className={inputCls} />
            </FieldLabel>
            <FieldLabel icon={Image} label="Banner Image URL">
              <div className="flex gap-2">
                <input type="url" value={settings.bannerImage}
                  onChange={e => handleSettingChange('bannerImage', e.target.value)}
                  className={`${inputCls} flex-1`} />
                {settings.bannerImage && (
                  <img src={settings.bannerImage} alt="" className="w-10 h-10 rounded-xl object-cover border border-white/10 shrink-0" />
                )}
              </div>
            </FieldLabel>
            <FieldLabel icon={Type} label="Top Offer Strip Text">
              <input type="text" value={settings.offerText}
                onChange={e => handleSettingChange('offerText', e.target.value)}
                className={inputCls} />
            </FieldLabel>
            <FieldLabel icon={Palette} label="Primary Color">
              <div className="flex gap-3 items-center">
                <input type="color" value={settings.primaryColor}
                  onChange={e => handleSettingChange('primaryColor', e.target.value)}
                  className="w-12 h-10 rounded cursor-pointer bg-black/30 border border-white/10" />
                <input type="text" value={settings.primaryColor}
                  onChange={e => handleSettingChange('primaryColor', e.target.value)}
                  className={`${inputCls} flex-1`} />
              </div>
            </FieldLabel>
            <FieldLabel icon={Type} label="Announcement Banner (empty = off)">
              <input type="text" value={settings.announcement}
                placeholder="e.g. Free shipping today only!"
                onChange={e => handleSettingChange('announcement', e.target.value)}
                className={inputCls} />
            </FieldLabel>
          </div>
        )}

        {/* ── Sections ── */}
        {activeTab === 'sections' && (
          <div className="space-y-4 mt-2">
            <div>
              <label className={labelCls}>Festival Theme</label>
              <div className="flex gap-2">
                {(['none', 'diwali', 'christmas'] as const).map(t => (
                  <button key={t} onClick={() => handleSettingChange('festivalTheme', t)}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-bold uppercase border transition-colors ${
                      settings.festivalTheme === t ? 'bg-red-600 border-red-500 text-white' : 'bg-black/30 border-white/10 text-white/50'
                    }`}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className={labelCls}>Product Card Layout</label>
              <div className="flex gap-2">
                {(['default', 'compact'] as const).map(l => (
                  <button key={l} onClick={() => handleSettingChange('cardLayout', l)}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-bold uppercase border transition-colors ${
                      settings.cardLayout === l ? 'bg-red-600 border-red-500 text-white' : 'bg-black/30 border-white/10 text-white/50'
                    }`}>
                    {l}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── Custom Code ── */}
        {activeTab === 'code' && (
          <div className="space-y-3 mt-2">
            <p className="text-white/40 text-xs">Custom HTML/CSS/JS rendered inside the app. Use responsibly.</p>
            <textarea value={settings.customCode}
              onChange={e => handleSettingChange('customCode', e.target.value)}
              placeholder="<!-- Enter custom HTML/CSS here -->"
              className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-red-500 font-mono text-xs h-64 resize-y"
            />
          </div>
        )}

        {/* ── History ── */}
        {activeTab === 'history' && (
          <div className="space-y-3 mt-2">
            {backups.length === 0 ? (
              <div className="text-center py-12 text-white/30 text-sm">No change history yet.</div>
            ) : (
              backups.map((b, idx) => (
                <div key={b.id} className="bg-white/5 border border-white/10 rounded-xl p-3 flex justify-between items-center">
                  <div>
                    <p className="text-white font-bold text-sm">Version {backups.length - idx}</p>
                    <p className="text-white/40 text-xs">{new Date(b.timestamp).toLocaleString()}</p>
                  </div>
                  <button onClick={() => { restoreBackup(b.id); showSaved(); }}
                    className="bg-white/10 hover:bg-white/20 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-colors">
                    Restore
                  </button>
                </div>
              ))
            )}
          </div>
        )}

        {/* ── Products ── */}
        {activeTab === 'products' && (
          <div className="space-y-3 mt-2">
            <p className="text-white/40 text-xs mb-1">Full product management. Use Admin Panel for detailed add/edit forms.</p>
            {products.map(p => (
              <div key={p.id} className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 overflow-hidden">
                  <img src={p.image} alt={p.name} className="w-10 h-10 rounded-lg object-cover shrink-0" />
                  <div className="min-w-0">
                    <p className="text-white font-bold text-xs truncate">{p.name}</p>
                    <p className="text-white/50 text-[10px]">₹{p.discountPrice} · {p.isOutOfStock
                      ? <span className="text-red-400">Out of Stock</span>
                      : <span className="text-green-400">In Stock</span>}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button onClick={() => updateProduct(p.id, { isOutOfStock: !p.isOutOfStock })}
                    className={`text-[9px] font-bold px-2 py-1 rounded transition-colors ${p.isOutOfStock ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                    {p.isOutOfStock ? 'Mark In' : 'Mark Out'}
                  </button>
                  <button onClick={() => { if (window.confirm(`Delete "${p.name}"?`)) deleteProduct(p.id); }}
                    className="text-red-400/50 hover:text-red-400 p-1 transition-colors">
                    <Trash className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── Orders ── */}
        {activeTab === 'orders' && (
          <div className="space-y-3 mt-2">
            {orders.length === 0 && <div className="text-center py-12 text-white/30 text-sm">No orders yet.</div>}
            {orders.map(order => (
              <div key={order.id} className="bg-white/5 border border-white/10 rounded-xl p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-white font-bold text-sm font-mono">#{order.id}</p>
                    <p className="text-white/40 text-xs">{new Date(order.date).toLocaleString()}</p>
                    {order.address && (
                      <p className="text-white/30 text-[10px] mt-0.5">{order.address.city}, {order.address.state}</p>
                    )}
                  </div>
                  <select value={order.status}
                    onChange={e => updateOrderStatus(order.id, e.target.value as any)}
                    className="bg-white/10 border border-white/20 text-white text-xs font-bold rounded-lg px-2 py-1 focus:outline-none">
                    <option value="pending">Pending</option>
                    <option value="processing">Processing</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
                <div className="text-white/60 text-xs flex gap-3">
                  <span>Items: {order.items.length}</span>
                  <span>Total: <strong className="text-white">₹{order.total}</strong></span>
                  <span>Method: {order.paymentMethod || 'N/A'}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── Customers ── */}
        {activeTab === 'customers' && (
          <div className="mt-2">
            <div className="bg-white/5 border border-white/10 rounded-xl p-6 flex flex-col items-center justify-center text-center">
              <Users className="w-10 h-10 text-white/20 mb-2" />
              <p className="text-white/50 text-sm font-bold">Firebase Required</p>
              <p className="text-white/30 text-xs mt-1">Customer list syncs from Firebase Auth after configuration.</p>
            </div>
          </div>
        )}

        {/* ── Coupons ── */}
        {activeTab === 'coupons' && (
          <div className="mt-2">
            <div className="bg-white/5 border border-white/10 rounded-xl p-6 flex flex-col items-center justify-center text-center">
              <Tag className="w-10 h-10 text-white/20 mb-2" />
              <p className="text-white/50 text-sm font-bold">Coming Soon</p>
              <p className="text-white/30 text-xs mt-1">Coupon engine will be available in the next update.</p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}

// ─── Shared helpers ────────────────────────────────────────────────────────────

const inputCls = 'w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-red-500 transition-colors';
const labelCls = 'text-white/40 text-[10px] font-bold uppercase tracking-wider mb-1.5 block';

function FieldLabel({ icon: Icon, label, children }: {
  icon: React.ComponentType<any>; label: string; children: React.ReactNode;
}) {
  return (
    <div>
      <label className={`${labelCls} flex items-center gap-1.5`}>
        <Icon className="w-3.5 h-3.5" /> {label}
      </label>
      {children}
    </div>
  );
}
