import { motion } from 'framer-motion';

export default function LoadingScreen() {
  return (
    <div className="fixed inset-0 bg-neutral-950 flex flex-col items-center justify-center z-[100]">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="relative"
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
          className="absolute inset-0 bg-gradient-to-tr from-red-600 to-yellow-500 rounded-full blur-xl opacity-30"
        />
        <div className="bg-neutral-900 border border-white/10 p-6 rounded-3xl relative z-10 shadow-2xl backdrop-blur-xl flex items-center justify-center gap-2">
          {/* Bear Icon */}
          <div className="text-red-500 relative">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
              <path d="M7 6C5.34315 6 4 7.34315 4 9C4 9.42939 4.09 9.83777 4.25055 10.205C3.51326 11.2386 3 12.5539 3 14C3 17.866 6.13401 21 10 21H14C17.866 21 21 17.866 21 14C21 12.5539 20.4867 11.2386 19.7495 10.205C19.91 9.83777 20 9.42939 20 9C20 7.34315 18.6569 6 17 6C15.9329 6 14.9961 6.55648 14.4715 7.41165C13.6896 7.14728 12.8617 7 12 7C11.1383 7 10.3104 7.14728 9.52854 7.41165C9.0039 6.55648 8.06714 6 7 6ZM8 14C8 14.5523 7.55228 15 7 15C6.44772 15 6 14.5523 6 14C6 13.4477 6.44772 13 7 13C7.55228 13 8 13.4477 8 14ZM18 14C18 14.5523 17.5523 15 17 15C16.4477 15 16 14.5523 16 14C16 13.4477 16.4477 13 17 13C17.5523 13 18 13.4477 18 14ZM12 17C10.8954 17 10 16.1046 10 15H14C14 16.1046 13.1046 17 12 17Z" />
            </svg>
          </div>
          {/* Toy Blocks */}
          <div className="flex flex-col gap-1 mt-4">
            <div className="w-6 h-6 bg-yellow-400 rounded-md shadow-[inset_0_-2px_4px_rgba(0,0,0,0.3)] border border-yellow-500 flex items-center justify-center transform -rotate-12">
              <span className="text-black font-black text-[10px]">A</span>
            </div>
            <div className="w-6 h-6 bg-red-500 rounded-md shadow-[inset_0_-2px_4px_rgba(0,0,0,0.3)] border border-red-600 flex items-center justify-center transform rotate-6 -ml-2">
              <span className="text-white font-black text-[10px]">B</span>
            </div>
          </div>
        </div>
      </motion.div>
      <motion.h1
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.5 }}
        className="text-2xl font-bold mt-6 tracking-tight text-white"
      >
        Bodana <span className="text-red-500">Toys</span>
      </motion.h1>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
        className="text-neutral-400 mt-2 text-sm"
      >
        Premium Play Experiences
      </motion.p>
    </div>
  );
}
