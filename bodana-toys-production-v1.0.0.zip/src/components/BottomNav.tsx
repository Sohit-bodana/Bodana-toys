import { Home, Crown, Heart, ShoppingBag, User } from 'lucide-react';
import { motion } from 'framer-motion';

interface BottomNavProps {
  activeTab: string;
  onChange: (tab: string) => void;
}

const navItems = [
  { id: 'home', icon: Home, label: 'Home' },
  { id: 'premium', icon: Crown, label: 'Premium Toys' },
  { id: 'cart', icon: ShoppingBag, label: 'Cart', isFab: true },
  { id: 'wishlist', icon: Heart, label: 'Wishlist' },
  { id: 'profile', icon: User, label: 'Profile' },
];

export default function BottomNav({ activeTab, onChange }: BottomNavProps) {
  return (
    <motion.div 
      initial={{ y: 50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="absolute bottom-4 left-4 right-4 h-16 bg-white/10 backdrop-blur-xl rounded-[28px] border border-white/10 flex items-center justify-around px-2 z-50"
    >
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;
        const isFab = item.isFab;
        
        return (
          <button 
            key={item.id}
            onClick={() => onChange(item.id)}
            className={`flex flex-col items-center justify-center gap-1 ${isActive ? 'text-red-500' : 'text-white/50'}`}
          >
            {isFab ? (
              <div className="p-3 bg-red-600 rounded-full -mt-10 shadow-xl border-4 border-[#050505] text-white">
                <Icon className="w-6 h-6" strokeWidth={2.5} />
              </div>
            ) : (
              <Icon 
                className="w-[22px] h-[22px] transition-all duration-300" 
                strokeWidth={2} 
              />
            )}
            <span className="text-[8px] font-bold uppercase tracking-widest">
              {item.label}
            </span>
          </button>
        );
      })}
    </motion.div>
  );
}
