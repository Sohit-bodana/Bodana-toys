import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X, Clock, TrendingUp } from 'lucide-react';
import { categories } from '../data';
import * as Icons from 'lucide-react';
import { useAppContext } from '../context/AppContext';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SearchOverlay({ isOpen, onClose }: SearchOverlayProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const { products } = useAppContext();

  const recentSearches = ['RC Cars', 'Action Figures', 'Lego', 'Barbie'];

  const filteredProducts = searchQuery.trim().length > 0
    ? products.filter(p =>
        p.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];
  
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: '100%' }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: '100%' }}
          transition={{ duration: 0.4, ease: [0.32, 0.72, 0, 1] }}
          className="absolute inset-0 z-[100] bg-black/80 backdrop-blur-2xl flex flex-col pt-12 pb-6 px-6"
        >
          {/* Header & Input */}
          <div className="flex items-center gap-4 mb-8">
            <div className="flex-1 relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-white/50">
                <Search className="w-5 h-5" />
              </div>
              <input
                autoFocus
                type="text"
                placeholder="Search Bodana Na Toys..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-14 bg-white/10 border border-white/20 rounded-2xl pl-12 pr-12 text-white placeholder:text-white/40 focus:outline-none focus:border-red-500 focus:bg-white/15 transition-all text-sm font-medium"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-white/50 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            <button 
              onClick={onClose}
              className="text-white/60 hover:text-white text-xs font-bold uppercase tracking-wider"
            >
              Cancel
            </button>
          </div>

          <div className="flex-1 overflow-y-auto hide-scrollbar space-y-8">
            {/* Recent Searches */}
            {!searchQuery && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <h3 className="text-white/50 text-xs font-bold uppercase tracking-wider mb-4 flex items-center gap-2">
                  <Clock className="w-4 h-4" /> Recent Searches
                </h3>
                <div className="flex flex-wrap gap-2">
                  {recentSearches.map((term, idx) => (
                    <button 
                      key={idx}
                      className="px-4 py-2 bg-white/5 border border-white/10 rounded-full text-white text-xs hover:bg-white/10 transition-colors"
                      onClick={() => setSearchQuery(term)}
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Popular Categories */}
            {!searchQuery && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <h3 className="text-white/50 text-xs font-bold uppercase tracking-wider mb-4 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" /> Popular Categories
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  {categories.slice(0, 6).map((category) => {
                    const IconComponent = Icons[category.icon as keyof typeof Icons] as React.ElementType;
                    return (
                      <button 
                        key={category.id}
                        className="flex items-center gap-3 p-3 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-colors group text-left"
                        onClick={() => setSearchQuery(category.name)}
                      >
                        <div className="w-10 h-10 rounded-xl bg-black/40 flex items-center justify-center border border-white/5">
                           {IconComponent && <IconComponent className="w-5 h-5 text-red-400 group-hover:text-yellow-400 transition-colors" />}
                        </div>
                        <span className="text-white text-sm font-medium">
                          {category.name}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            )}
            
            {/* Search Results */}
            {searchQuery && filteredProducts.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <h3 className="text-white/50 text-xs font-bold uppercase tracking-wider mb-4">
                  {filteredProducts.length} Result{filteredProducts.length !== 1 ? 's' : ''} for "{searchQuery}"
                </h3>
                <div className="space-y-3">
                  {filteredProducts.map(product => (
                    <div key={product.id} className="bg-white/5 border border-white/10 rounded-2xl p-3 flex gap-3 items-center">
                      <img
                        src={product.image}
                        alt={product.name}
                        className={`w-16 h-16 rounded-xl object-cover shrink-0 ${product.isOutOfStock ? 'opacity-50 grayscale' : ''}`}
                        loading="lazy"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-white font-bold text-sm truncate">{product.name}</h4>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-red-500 font-bold text-sm">₹{product.discountPrice.toLocaleString()}</span>
                          <span className="text-white/30 line-through text-[10px]">₹{product.originalPrice.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center gap-1 mt-0.5">
                          <span className="text-yellow-400 text-[10px]">★</span>
                          <span className="text-white/50 text-[10px]">{product.rating} ({product.reviews})</span>
                        </div>
                      </div>
                      {product.isOutOfStock ? (
                        <span className="text-[10px] bg-white/5 text-white/30 font-bold px-3 py-1.5 rounded-xl shrink-0">Out of Stock</span>
                      ) : (
                        <span className="text-[10px] bg-yellow-400 text-black font-bold px-2 py-0.5 rounded italic shrink-0">
                          {product.discountPercent}% OFF
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* No results */}
            {searchQuery && filteredProducts.length === 0 && (
              <div className="flex flex-col items-center justify-center h-40 text-white/50">
                <Search className="w-10 h-10 mb-4 text-white/20" />
                <p className="text-sm">No results for "{searchQuery}"</p>
                <p className="text-xs mt-1 text-white/30">Try a different search term</p>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
