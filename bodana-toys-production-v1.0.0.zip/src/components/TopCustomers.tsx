import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Medal, Star } from 'lucide-react';

const topCustomers = [
  { id: 1, name: "Rahul S.", totalOrders: 15, totalSpent: 12500 },
  { id: 2, name: "Priya S.", totalOrders: 12, totalSpent: 9800 },
  { id: 3, name: "Amit K.", totalOrders: 10, totalSpent: 8500 },
  { id: 4, name: "Sneha P.", totalOrders: 8, totalSpent: 7200 },
  { id: 5, name: "Vikram R.", totalOrders: 7, totalSpent: 6500 },
  { id: 6, name: "Neha G.", totalOrders: 6, totalSpent: 5900 },
  { id: 7, name: "Rohan V.", totalOrders: 5, totalSpent: 4800 },
  { id: 8, name: "Pooja D.", totalOrders: 4, totalSpent: 4100 },
  { id: 9, name: "Karan S.", totalOrders: 4, totalSpent: 3500 },
  { id: 10, name: "Anjali J.", totalOrders: 3, totalSpent: 2900 },
];

export default function TopCustomers() {
  return (
    <div className="mx-4 my-8 relative">
      <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/10 rounded-full blur-3xl -z-10"></div>
      
      <div className="flex items-center justify-between mb-4 px-2">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Top 10 Buyers</h2>
          <p className="text-white/50 text-xs mt-1">Our most loyal customers</p>
        </div>
        <span className="bg-yellow-400/10 text-yellow-400 border border-yellow-400/20 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5">
          <Trophy className="w-3.5 h-3.5" /> Leaderboard
        </span>
      </div>
      
      <div className="bg-white/5 border border-white/10 rounded-[32px] p-2 backdrop-blur-md overflow-hidden relative">
        <div className="space-y-1">
          {topCustomers.map((customer, idx) => {
            const isTop3 = idx < 3;
            
            return (
              <motion.div 
                key={customer.id} 
                whileHover={{ scale: 1.02 }}
                className={`flex items-center p-3 rounded-2xl relative overflow-hidden ${
                  isTop3 ? 'bg-white/10 border border-white/5' : 'hover:bg-white/5 transition-colors'
                }`}
              >
                {idx === 0 && <div className="absolute -right-4 -top-4 w-16 h-16 rounded-full blur-xl bg-yellow-500/20" />}
                {idx === 1 && <div className="absolute -right-4 -top-4 w-16 h-16 rounded-full blur-xl bg-zinc-300/20" />}
                {idx === 2 && <div className="absolute -right-4 -top-4 w-16 h-16 rounded-full blur-xl bg-orange-500/20" />}

                <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm shrink-0 mr-4 shadow-inner border ${
                  idx === 0 ? 'bg-gradient-to-br from-yellow-300 to-yellow-600 text-black border-yellow-400 shadow-yellow-500/50' : 
                  idx === 1 ? 'bg-gradient-to-br from-zinc-200 to-zinc-400 text-black border-zinc-300 shadow-zinc-400/50' : 
                  idx === 2 ? 'bg-gradient-to-br from-orange-300 to-orange-600 text-black border-orange-400 shadow-orange-500/50' : 
                  'bg-black/50 text-white/50 border-white/10'
                }`}>
                  {idx === 0 ? <Trophy className="w-5 h-5 text-black" /> : 
                   idx === 1 ? <Medal className="w-5 h-5 text-black" /> : 
                   idx === 2 ? <Medal className="w-5 h-5 text-black" /> : 
                   `#${idx + 1}`}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className={`font-bold text-sm truncate ${isTop3 ? 'text-white' : 'text-white/80'}`}>
                      {customer.name}
                    </h4>
                    {idx === 0 && <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />}
                  </div>
                  <p className="text-white/40 text-[10px] uppercase tracking-wider mt-0.5">
                    {customer.totalOrders} items bought
                  </p>
                </div>

                <div className="text-right ml-2 shrink-0">
                  <p className={`font-bold text-sm ${idx === 0 ? 'text-yellow-400' : isTop3 ? 'text-white' : 'text-white/60'}`}>
                    ₹{customer.totalSpent.toLocaleString()}
                  </p>
                  <p className="text-white/30 text-[9px] uppercase tracking-wider mt-0.5">Spent</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
