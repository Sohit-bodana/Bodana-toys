import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Package, Truck, MapPin, CheckCircle2, ChevronRight, Download, Ban, RotateCcw, Loader2 } from 'lucide-react';
import { useOrders } from '../context/OrderContext';
import { CartItem } from '../context/CartContext';
import { downloadInvoice } from '../lib/utils';

export default function OrderTracking({ onReview }: { onReview?: (product: CartItem) => void }) {
  const {
    orders,
    requestCancellation,
    requestReturn,
    markInvoiceGenerated,
  } = useOrders();
  const hasOrders = orders.length > 0;
  const order = hasOrders ? orders[0] : null;
  const [showDetails, setShowDetails] = useState(false);
  const [actionError, setActionError] = useState('');
  const [actionMessage, setActionMessage] = useState('');
  const [actionLoading, setActionLoading] = useState('');
  const statusStep: Record<string, number> = { pending: 0, processing: 0, shipped: 1, delivered: 3, cancelled: 0 };
  const currentStep = order ? statusStep[order.status] ?? 0 : 0;
  const orderId = order ? `#BT-${order.id.toUpperCase()}` : '#BT-889021';
  const orderTotal = order ? `₹${order.total.toLocaleString()}` : '₹1,299';
  const orderItemName = order?.items[0]?.name || 'Remote Control Car';
  const orderItemImg = order?.items[0]?.image || 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?auto=format&fit=crop&q=80&w=150';
  const orderQuantity = order?.items.reduce((sum, item) => sum + item.quantity, 0) || 1;
  const orderDate = order ? new Date(order.date).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : 'Sample order';
  const steps = [
    { title: 'Order Placed', description: order?.status === 'cancelled' ? 'This order was cancelled' : 'We have received your order', time: order ? orderDate : 'Awaiting order', icon: Package },
    { title: 'Shipped', description: 'Your item has been shipped', time: currentStep >= 1 ? 'In transit' : 'Pending', icon: Truck },
    { title: 'Out for Delivery', description: 'Arriving soon', time: currentStep >= 2 ? 'On the way' : 'Pending', icon: MapPin },
    { title: 'Delivered', description: 'Item handed to customer', time: currentStep >= 3 ? 'Complete' : 'Pending', icon: CheckCircle2 },
  ];

  const runAction = async (action: string, callback: () => Promise<void>, message: string) => {
    if (!order || actionLoading) return;
    setActionLoading(action);
    setActionError('');
    setActionMessage('');
    try {
      await callback();
      setActionMessage(message);
    } catch (error: any) {
      setActionError(error?.message || 'This request could not be completed. Please try again.');
    } finally {
      setActionLoading('');
    }
  };

  return (
    <div className="mx-4 my-4 bg-white/5 border border-white/10 rounded-[24px] p-5 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/10 rounded-full blur-3xl -z-10" />
      
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-white font-bold text-lg">Order Status</h2>
          <p className="text-white/50 text-xs">Order ID: {orderId}</p>
        </div>
         <button onClick={() => setShowDetails(value => !value)} className="text-xs font-bold bg-white/10 text-white px-3 py-1.5 rounded-full hover:bg-white/20 transition-colors flex items-center gap-1">
           {showDetails ? 'Hide' : 'Details'} <ChevronRight className={`w-3 h-3 transition-transform ${showDetails ? 'rotate-90' : ''}`} />
        </button>
      </div>

         <div className="relative">
        <div className="absolute left-[19px] top-4 bottom-4 w-[2px] bg-white/10" />
        <div 
          className="absolute left-[19px] top-4 w-[2px] bg-green-500 transition-all duration-1000" 
          style={{ height: `${(currentStep / (steps.length - 1)) * 100}%` }}
        />

        <div className="space-y-6">
          {steps.map((step, idx) => {
            const isCompleted = idx <= currentStep;
            const isCurrent = idx === currentStep;
            const Icon = step.icon;

            return (
              <div key={idx} className="flex gap-4 relative z-10">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border-4 border-[#111] transition-colors duration-500 ${
                  isCompleted ? 'bg-green-500 text-black' : 'bg-white/10 text-white/40'
                }`}>
                  <Icon className="w-4 h-4" />
                </div>
                
                <div className="flex-1 pt-1.5 pb-2">
                  <div className="flex justify-between items-start mb-1">
                    <h3 className={`font-bold text-sm ${isCompleted ? 'text-white' : 'text-white/40'}`}>
                      {step.title}
                    </h3>
                   <span className={`text-[10px] font-bold uppercase tracking-wider ${isCurrent ? 'text-green-400' : 'text-white/30'}`}>
                      {step.time}
                    </span>
                  </div>
                  <p className={`text-xs ${isCurrent ? 'text-white/80' : 'text-white/30'}`}>
                    {step.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {showDetails && order && (
        <div className="mt-4 pt-4 border-t border-white/10 space-y-1.5 text-xs">
          <div className="flex justify-between"><span className="text-white/40">Payment</span><span className="text-white capitalize">{order.paymentMethod || 'mock'}</span></div>
          {order.address && <div className="flex justify-between gap-4"><span className="text-white/40">Delivering to</span><span className="text-white text-right">{order.address.city}, {order.address.state} {order.address.pincode}</span></div>}
          <div className="flex flex-wrap gap-2 pt-3">
            <button
              onClick={() => {
                downloadInvoice(order);
                void markInvoiceGenerated(order.id);
                setActionMessage('Invoice downloaded.');
                setActionError('');
              }}
              className="text-[10px] font-bold text-white border border-white/15 rounded-full px-3 py-1.5 flex items-center gap-1 hover:bg-white/10"
            >
              <Download className="w-3 h-3" /> Invoice
            </button>
            {['pending', 'processing'].includes(order.status) && (
              <button
                disabled={!!order.cancellationRequestedAt || !!actionLoading}
                onClick={() => void runAction(
                  'cancel',
                  () => requestCancellation(order.id),
                  'Cancellation request submitted.',
                )}
                className="text-[10px] font-bold text-red-400 border border-red-400/30 rounded-full px-3 py-1.5 flex items-center gap-1 disabled:opacity-40"
              >
                {actionLoading === 'cancel' ? <Loader2 className="w-3 h-3 animate-spin" /> : <Ban className="w-3 h-3" />}
                {order.cancellationRequestedAt ? 'Cancellation Requested' : 'Request Cancellation'}
              </button>
            )}
            {order.status === 'delivered' && (
              <button
                disabled={!!order.returnRequestedAt || !!actionLoading}
                onClick={() => void runAction(
                  'return',
                  () => requestReturn(order.id),
                  'Return request submitted.',
                )}
                className="text-[10px] font-bold text-yellow-400 border border-yellow-400/30 rounded-full px-3 py-1.5 flex items-center gap-1 disabled:opacity-40"
              >
                {actionLoading === 'return' ? <Loader2 className="w-3 h-3 animate-spin" /> : <RotateCcw className="w-3 h-3" />}
                {order.returnRequestedAt ? 'Return Requested' : 'Request Return'}
              </button>
            )}
          </div>
          {actionError && <p className="text-red-400 text-[10px] font-bold pt-2">{actionError}</p>}
          {actionMessage && <p className="text-green-400 text-[10px] font-bold pt-2">{actionMessage}</p>}
        </div>
      )}
      
      <div className="mt-6 pt-4 border-t border-white/10 flex items-center gap-3">
        <img 
          src={orderItemImg} 
          alt="Product" 
          className="w-12 h-12 rounded-xl object-cover"
        />
        <div className="flex-1 min-w-0">
          <h4 className="text-white font-bold text-sm truncate">{orderItemName}</h4>
          <p className="text-white/50 text-xs">Qty: {orderQuantity} • {orderTotal}</p>
        </div>
        {order?.status === 'delivered' && onReview && order.items[0] && (
          <button
            onClick={() => onReview(order.items[0])}
            className="text-[10px] font-bold text-yellow-400 border border-yellow-400/30 rounded-full px-3 py-1.5"
          >
            Review
          </button>
        )}
      </div>
    </div>
  );
}
