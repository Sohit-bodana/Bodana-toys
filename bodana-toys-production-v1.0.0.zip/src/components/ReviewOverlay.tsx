import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, CheckCircle2, X } from 'lucide-react';

interface ReviewOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  productName?: string;
}

export default function ReviewOverlay({ isOpen, onClose, productName = 'your recent purchase' }: ReviewOverlayProps) {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [reviewText, setReviewText] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating > 0) {
      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setRating(0);
        setReviewText('');
        onClose();
      }, 2000);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="absolute inset-0 z-[200] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-sm bg-[#111] border border-white/10 rounded-[32px] p-6 overflow-hidden"
          >
            {submitted ? (
              <div className="flex flex-col items-center justify-center py-8 text-center space-y-4">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", bounce: 0.5 }}
                >
                  <CheckCircle2 className="w-16 h-16 text-green-500" />
                </motion.div>
                <h3 className="text-xl font-bold text-white">Thank You!</h3>
                <p className="text-white/50 text-sm">Your review helps us improve.</p>
              </div>
            ) : (
              <>
                <button 
                  onClick={onClose}
                  className="absolute right-4 top-4 text-white/40 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="text-center mb-6 mt-2">
                  <h2 className="text-xl font-bold text-white mb-2">How was it?</h2>
                  <p className="text-white/50 text-sm">Please rate {productName}</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="flex justify-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                        className="p-1 transition-transform hover:scale-110"
                      >
                        <Star 
                          className={`w-8 h-8 ${
                            star <= (hoverRating || rating) 
                              ? 'text-yellow-400 fill-yellow-400' 
                              : 'text-white/20'
                          } transition-colors`} 
                        />
                      </button>
                    ))}
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-white/50 uppercase tracking-wider">
                      Leave a comment (Optional)
                    </label>
                    <textarea
                      value={reviewText}
                      onChange={(e) => setReviewText(e.target.value)}
                      placeholder="What did you like or dislike?"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-yellow-500 focus:bg-white/10 transition-colors resize-none h-24 text-sm"
                    />
                  </div>
                  
                  <button 
                    type="submit"
                    disabled={rating === 0}
                    className="w-full bg-yellow-400 disabled:bg-neutral-800 disabled:text-white/30 text-black font-bold py-3.5 rounded-xl hover:bg-yellow-500 transition-colors shadow-[0_0_15px_rgba(250,204,21,0.2)]"
                  >
                    Submit Review
                  </button>
                </form>
              </>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
