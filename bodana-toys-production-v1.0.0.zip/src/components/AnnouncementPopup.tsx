import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDeveloper } from '../context/DeveloperContext';
import { X, Sparkles } from 'lucide-react';

export default function AnnouncementPopup() {
  const { settings } = useDeveloper();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (settings.announcement && settings.announcement.trim() !== '') {
      setIsVisible(true);
      const timer = setTimeout(() => {
        setIsVisible(false);
      }, 5000);
      return () => clearTimeout(timer);
    } else {
      setIsVisible(false);
      return undefined;
    }
  }, [settings.announcement]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -50 }}
          className="absolute top-20 left-4 right-4 z-[200]"
        >
          <div className="bg-gradient-to-r from-red-600 to-red-800 rounded-2xl p-4 shadow-[0_10px_40px_rgba(220,38,38,0.3)] border border-red-500/50 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <p className="text-white font-bold text-sm leading-tight">{settings.announcement}</p>
            </div>
            <button 
              onClick={() => setIsVisible(false)}
              className="text-white/70 hover:text-white shrink-0 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
