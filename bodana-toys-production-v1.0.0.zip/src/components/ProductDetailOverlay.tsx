import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Heart, Star, ShoppingCart, Zap, Share2, Shield, Truck, RotateCcw, CheckCircle2, ChevronLeft, ChevronRight } from 'lucide-react';
import { Product } from '../types';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { useAppContext } from '../context/AppContext';

interface ProductDetailOverlayProps {
  product: Product | null;
  onClose: () => void;
  onBuyNow: (product: Product, quantity: number) => void;
  onProductClick?: (product: Product) => void;
}

function getRelatedProducts(current: Product, allProducts: Product[]): Product[] {
  const others = allProducts.filter(p => p.id !== current.id && !p.isOutOfStock);

  const priceLow = current.discountPrice * 0.5;
  const priceHigh = current.discountPrice * 2.0;

  const scored = others.map(p => {
    let score = 0;
    if (p.category && current.category && p.category === current.category) score += 10;
    if (p.discountPrice >= priceLow && p.discountPrice <= priceHigh) score += 5;
    if (current.features && p.features) {
      const currentKeywords = current.features.join(' ').toLowerCase().split(/\W+/);
      const pKeywords = p.features.join(' ').toLowerCase().split(/\W+/);
      const shared = currentKeywords.filter(k => k.length > 3 && pKeywords.includes(k));
      score += Math.min(shared.length, 4);
    }
    if (p.ageGroup && current.ageGroup && p.ageGroup === current.ageGroup) score += 2;
    return { product: p, score };
  });

  const related = scored
    .filter(s => s.score >= 5)
    .sort((a, b) => b.score - a.score)
    .slice(0, 10)
    .map(s => s.product);

  if (related.length >= 3) return related;

  // Fallback: popular products sorted by reviews
  return others.sort((a, b) => b.reviews - a.reviews).slice(0, 10);
}

function getFrequentlyBoughtTogether(current: Product, allProducts: Product[]): Product[] {
  const candidates = allProducts
    .filter(product => product.id !== current.id && !product.isOutOfStock)
    .map(product => {
      let score = product.reviews / 1000;
      if (product.category && current.category && product.category !== current.category) score += 4;
      if (product.ageGroup && current.ageGroup && product.ageGroup === current.ageGroup) score += 2;
      if (product.section === 'bestSellers') score += 3;
      return { product, score };
    })
    .sort((a, b) => b.score - a.score);

  const chosen: Product[] = [];
  const categories = new Set<string>();
  for (const candidate of candidates) {
    if (chosen.length >= 3) break;
    if (candidate.product.category && categories.has(candidate.product.category)) continue;
    chosen.push(candidate.product);
    if (candidate.product.category) categories.add(candidate.product.category);
  }
  return chosen;
}

export default function ProductDetailOverlay({ product, onClose, onBuyNow, onProductClick }: ProductDetailOverlayProps) {
  const { isInWishlist, addToWishlist, removeFromWishlist } = useWishlist();
  const { addToCart } = useCart();
  const { products: allProducts } = useAppContext();
  const [imgIdx, setImgIdx] = useState(0);
  const [addedToCart, setAddedToCart] = useState(false);
  const [quantity, setQuantity] = useState(1);

  const wishlisted = product ? isInWishlist(product.id) : false;
  const isPremiumLargeToy = product?.isPremiumLargeToy || product?.category === 'premium';

  const images = product?.images?.length ? product.images : product ? [product.image] : [];
  const relatedProducts = product ? getRelatedProducts(product, allProducts) : [];
  const frequentlyBoughtTogether = product ? getFrequentlyBoughtTogether(product, allProducts) : [];

  React.useEffect(() => {
    setImgIdx(0);
    setQuantity(1);
  }, [product?.id]);

  const handleAddToCart = () => {
    if (!product || product.isOutOfStock) return;
    addToCart(product);
    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  const handleWishlist = () => {
    if (!product) return;
    wishlisted ? removeFromWishlist(product.id) : addToWishlist(product);
  };

  return (
    <AnimatePresence>
      {product && (
        <>
          {/* Backdrop */}
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/70 backdrop-blur-sm z-[150]"
          />

          {/* Sheet — slides up from bottom */}
          <motion.div
            key="sheet"
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', stiffness: 380, damping: 38 }}
            className="absolute inset-x-0 bottom-0 z-[151] bg-[#0d0d0d] rounded-t-[32px] border-t border-white/10 flex flex-col max-h-[92%] overflow-hidden"
          >
            {/* Drag handle */}
            <div className="flex justify-center pt-3 pb-1 shrink-0">
              <div className="w-10 h-1 bg-white/20 rounded-full" />
            </div>

            {/* Scrollable body */}
            <div className="flex-1 overflow-y-auto hide-scrollbar">
              {/* Image carousel */}
              <div className="relative mx-4 mt-2 mb-4 aspect-square rounded-3xl overflow-hidden bg-white/5">
                <AnimatePresence mode="wait">
                  <motion.img
                    key={imgIdx}
                    src={images[imgIdx]}
                    alt={product.name}
                    initial={{ opacity: 0, scale: 1.05 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className={`w-full h-full object-cover ${product.isOutOfStock ? 'grayscale opacity-50' : ''}`}
                  />
                </AnimatePresence>

                {product.isOutOfStock && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="bg-red-600 text-white font-bold px-4 py-2 rounded-full text-sm uppercase tracking-widest">
                      Out of Stock
                    </span>
                  </div>
                )}
                {!product.isOutOfStock && product.stock !== undefined && product.stock <= (product.lowStockThreshold ?? 3) && (
                  <div className="absolute bottom-3 left-3 bg-yellow-400 text-black text-[10px] font-black px-2 py-1 rounded-full">
                    Only {product.stock} left
                  </div>
                )}

                {/* Carousel nav */}
                {images.length > 1 && (
                  <>
                    <button
                      onClick={() => setImgIdx(i => Math.max(0, i - 1))}
                      className="absolute left-3 top-1/2 -translate-y-1/2 bg-black/50 backdrop-blur-sm w-8 h-8 rounded-full flex items-center justify-center"
                    >
                      <ChevronLeft className="w-4 h-4 text-white" />
                    </button>
                    <button
                      onClick={() => setImgIdx(i => Math.min(images.length - 1, i + 1))}
                      className="absolute right-3 top-1/2 -translate-y-1/2 bg-black/50 backdrop-blur-sm w-8 h-8 rounded-full flex items-center justify-center"
                    >
                      <ChevronRight className="w-4 h-4 text-white" />
                    </button>
                    <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5">
                      {images.map((_, i) => (
                        <button
                          key={i}
                          onClick={() => setImgIdx(i)}
                          className={`h-1.5 rounded-full transition-all ${i === imgIdx ? 'w-5 bg-white' : 'w-1.5 bg-white/40'}`}
                        />
                      ))}
                    </div>
                  </>
                )}

                {/* Discount badge */}
                {product.discountPercent > 0 && !product.isOutOfStock && (
                  <div className="absolute top-3 left-3 bg-yellow-400 text-black text-[10px] font-black px-2 py-1 rounded-lg italic shadow">
                    {product.discountPercent}% OFF
                  </div>
                )}

                {/* Wishlist + Share */}
                <div className="absolute top-3 right-3 flex flex-col gap-2">
                  <button
                    onClick={handleWishlist}
                    className="w-9 h-9 bg-black/60 backdrop-blur-sm rounded-full flex items-center justify-center"
                  >
                    <Heart
                      className={`w-4 h-4 transition-colors ${wishlisted ? 'fill-red-500 text-red-500' : 'text-white'}`}
                    />
                  </button>
                  <button
                    onClick={() => navigator.share?.({ title: product.name, url: window.location.href })}
                    className="w-9 h-9 bg-black/60 backdrop-blur-sm rounded-full flex items-center justify-center"
                  >
                    <Share2 className="w-4 h-4 text-white" />
                  </button>
                </div>
              </div>

              {/* Product info */}
              <div className="px-5 pb-32">
                {/* Brand & Age */}
                <div className="flex items-center gap-2 mb-2">
                  {product.brand && (
                    <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">{product.brand}</span>
                  )}
                  {product.ageGroup && (
                    <>
                      <span className="text-white/20">•</span>
                      <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">{product.ageGroup}</span>
                    </>
                  )}
                </div>

                {/* Name */}
                <h2 className="text-xl font-black text-white leading-tight mb-3">{product.name}</h2>

                {/* Rating */}
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center gap-1 bg-yellow-400/10 border border-yellow-400/30 rounded-full px-2.5 py-1">
                    <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                    <span className="text-yellow-400 font-bold text-xs">{product.rating}</span>
                  </div>
                  <span className="text-white/40 text-xs">{product.reviews.toLocaleString()} reviews</span>
                </div>

                {/* Price block */}
                <div className="bg-white/5 border border-white/10 rounded-2xl p-4 mb-4 flex items-center justify-between">
                  <div>
                    <div className="text-2xl font-black text-white">₹{product.discountPrice.toLocaleString()}</div>
                    {product.originalPrice !== product.discountPrice && (
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-white/40 line-through text-sm">₹{product.originalPrice.toLocaleString()}</span>
                        <span className="text-green-400 text-xs font-bold">
                          Save ₹{(product.originalPrice - product.discountPrice).toLocaleString()}
                        </span>
                      </div>
                    )}
                  </div>
                  {product.discountPercent > 0 && (
                    <div className="bg-green-500/20 border border-green-500/30 rounded-xl px-3 py-2 text-center">
                      <div className="text-green-400 font-black text-lg leading-none">{product.discountPercent}%</div>
                      <div className="text-green-400/60 text-[9px] font-bold uppercase">off</div>
                    </div>
                  )}
                </div>

                {/* Trust badges */}
                {isPremiumLargeToy ? (
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-4 mb-5">
                    <div className="flex items-center gap-2 mb-3">
                      <Truck className="w-4 h-4 text-red-400" />
                      <span className="text-white font-bold text-sm">Home Delivery by Bodana Toys</span>
                    </div>
                    <div className="grid grid-cols-2 gap-x-3 gap-y-2">
                      {[
                        'Genuine Warranty',
                        'Installation Support',
                        'Local Delivery',
                        'Safe Packaging',
                        'Heavy Item Delivery',
                      ].map(benefit => (
                        <div key={benefit} className="flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-400 shrink-0" />
                          <span className="text-white/70 text-[10px] font-bold">{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-3 gap-2 mb-5">
                    {[
                      { icon: Truck, label: 'Free Delivery', sub: 'On ₹999+' },
                      { icon: Shield, label: 'Safe & Secure', sub: 'Verified' },
                      { icon: RotateCcw, label: 'Easy Returns', sub: '7 Days' },
                    ].map(b => (
                      <div key={b.label} className="bg-white/5 border border-white/10 rounded-xl p-2 text-center">
                        <b.icon className="w-4 h-4 text-red-400 mx-auto mb-1" />
                        <div className="text-white text-[9px] font-bold leading-tight">{b.label}</div>
                        <div className="text-white/40 text-[8px]">{b.sub}</div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Quantity */}
                <div className="flex items-center justify-between bg-white/5 border border-white/10 rounded-2xl p-3 mb-5">
                  <span className="text-white font-bold text-sm">Quantity</span>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setQuantity(value => Math.max(1, value - 1))}
                      className="w-8 h-8 rounded-full bg-white/10 text-white font-bold"
                      aria-label="Decrease quantity"
                    >−</button>
                    <span className="text-white font-black w-5 text-center">{quantity}</span>
                    <button
                      onClick={() => setQuantity(value => value + 1)}
                      className="w-8 h-8 rounded-full bg-white/10 text-white font-bold"
                      aria-label="Increase quantity"
                    >+</button>
                  </div>
                </div>

                {/* Description */}
                {product.description && (
                  <div className="mb-5">
                    <h3 className="text-white font-bold text-sm mb-2 uppercase tracking-wider">About</h3>
                    <p className="text-white/60 text-sm leading-relaxed">{product.description}</p>
                  </div>
                )}

                {/* Features */}
                {product.features && product.features.length > 0 && (
                  <div className="mb-5">
                    <h3 className="text-white font-bold text-sm mb-2 uppercase tracking-wider">Key Features</h3>
                    <div className="space-y-2">
                      {product.features.map((f, i) => (
                        <div key={i} className="flex items-start gap-2">
                          <div className="w-1.5 h-1.5 bg-red-500 rounded-full mt-1.5 shrink-0" />
                          <span className="text-white/70 text-sm">{f}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* ─── Related Products ─────────────────────────────────── */}
                {relatedProducts.length > 0 && (
                  <div className="mb-2">
                    <h3 className="text-white font-bold text-sm mb-3 uppercase tracking-wider">You May Also Like</h3>
                    <div className="grid grid-cols-2 gap-3">
                      {relatedProducts.slice(0, 10).map(related => (
                        <button
                          key={related.id}
                          onClick={() => onProductClick?.(related)}
                          className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden text-left active:scale-95 transition-transform"
                        >
                          <div className="relative aspect-square">
                            <img
                              src={related.image}
                              alt={related.name}
                              loading="lazy"
                              className="w-full h-full object-cover"
                            />
                            {related.discountPercent > 0 && (
                              <div className="absolute top-1.5 left-1.5 bg-yellow-400 text-black text-[9px] font-black px-1.5 py-0.5 rounded-md italic">
                                {related.discountPercent}% OFF
                              </div>
                            )}
                          </div>
                          <div className="p-2.5">
                            <p className="text-white text-[11px] font-bold leading-tight line-clamp-2 mb-1.5">{related.name}</p>
                            <div className="flex items-center gap-1 mb-1">
                              <Star className="w-2.5 h-2.5 text-yellow-400 fill-yellow-400 shrink-0" />
                              <span className="text-yellow-400 text-[10px] font-bold">{related.rating}</span>
                              <span className="text-white/30 text-[9px]">({related.reviews.toLocaleString()})</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-white font-black text-xs">₹{related.discountPrice.toLocaleString()}</span>
                              {related.originalPrice !== related.discountPrice && (
                                <span className="text-white/30 line-through text-[9px]">₹{related.originalPrice.toLocaleString()}</span>
                              )}
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {frequentlyBoughtTogether.length > 0 && (
                  <div className="mt-5 mb-2">
                    <h3 className="text-white font-bold text-sm mb-3 uppercase tracking-wider">Frequently Bought Together</h3>
                    <div className="grid grid-cols-3 gap-2">
                      {frequentlyBoughtTogether.map(companion => (
                        <button
                          key={companion.id}
                          onClick={() => onProductClick?.(companion)}
                          className="bg-white/5 border border-white/10 rounded-xl overflow-hidden text-left active:scale-95 transition-transform"
                        >
                          <div className="aspect-square bg-white/10">
                            <img src={companion.image} alt={companion.name} loading="lazy" className="w-full h-full object-cover" />
                          </div>
                          <div className="p-2">
                            <p className="text-white text-[9px] font-bold leading-tight line-clamp-2">{companion.name}</p>
                            <p className="text-red-400 text-[10px] font-black mt-1">₹{companion.discountPrice.toLocaleString()}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Sticky action buttons */}
            <div className="absolute bottom-0 inset-x-0 bg-[#0d0d0d] border-t border-white/10 px-4 pb-6 pt-3 flex gap-3">
              <button
                onClick={handleAddToCart}
                disabled={product.isOutOfStock}
                className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl font-bold text-sm border transition-colors ${
                  product.isOutOfStock
                    ? 'bg-white/5 border-white/10 text-white/20 cursor-not-allowed'
                    : addedToCart
                    ? 'bg-green-600 border-green-500 text-white'
                    : 'bg-white/10 border-white/10 text-white hover:bg-white/15'
                }`}
              >
                <ShoppingCart className="w-4 h-4" />
                {addedToCart ? 'Added!' : 'Add to Cart'}
              </button>
              <button
                onClick={() => !product.isOutOfStock && onBuyNow(product, quantity)}
                disabled={product.isOutOfStock}
                className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl font-bold text-sm transition-colors ${
                  product.isOutOfStock
                    ? 'bg-white/5 text-white/20 cursor-not-allowed'
                    : 'bg-red-600 text-white hover:bg-red-700 shadow-[0_4px_14px_rgba(220,38,38,0.4)]'
                }`}
              >
                <Zap className="w-4 h-4" />
                {product.isOutOfStock ? 'Out of Stock' : 'Buy Now'}
              </button>
            </div>

            {/* Close button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 w-8 h-8 bg-white/10 rounded-full flex items-center justify-center"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
