import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Gift } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { useRewards } from '../context/RewardsContext';

interface SpinWheelProps {
  available: boolean;
  onSpinEnd: () => void;
}

export default function SpinWheel({ available, onSpinEnd }: SpinWheelProps) {
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const savedResultRef = useRef<string | null>(null);
  
  const { spinRewards: ctxRewards } = useAppContext();
  const { saveSpinReward } = useRewards();
  const rewards = ctxRewards || ["10% OFF", "FREE SHIPPING", "NO LUCK", "20% OFF", "FREE GIFT", "TRY AGAIN"];

  useEffect(() => {
    if (result && savedResultRef.current !== result) {
      savedResultRef.current = result;
      void saveSpinReward(result);
    }
  }, [result]);

  const spin = () => {
    if (spinning || !available) return;
    setSpinning(true);
    setResult(null);
    
    const randomSlice = Math.floor(Math.random() * rewards.length);
    const sliceAngle = 360 / rewards.length;
    const baseRotations = 360 * (5 + Math.floor(Math.random() * 5));
    
    const finalRotation = rotation + baseRotations + (randomSlice * sliceAngle) + (sliceAngle / 2);
    
    setRotation(finalRotation);
    
    setTimeout(() => {
      setSpinning(false);
      const normalizedRotation = finalRotation % 360;
      const winningIndex = Math.floor(((360 - normalizedRotation) % 360) / sliceAngle);
      setResult(rewards[winningIndex]);
      onSpinEnd();
    }, 4000);
  };

  return (
    <div className="mx-6 my-8 bg-white/5 border border-white/10 rounded-[32px] p-6 backdrop-blur-md relative overflow-hidden flex flex-col items-center shadow-xl">
      <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-32 h-32 bg-red-600/10 rounded-full blur-3xl"></div>
      
      <div className="flex items-center gap-2 mb-6 z-10">
        <Gift className="text-yellow-400 w-5 h-5" />
        <h3 className="text-white font-black uppercase tracking-widest text-sm">Lucky Spin</h3>
      </div>
      
      <div className="relative w-48 h-48 z-10">
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[20px] border-t-yellow-400 z-20 filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]"></div>
        
        <motion.div 
          className="w-full h-full rounded-full border-[6px] border-[#1a1a1a] shadow-[0_0_20px_rgba(220,38,38,0.3)] relative overflow-hidden"
          animate={{ rotate: rotation }}
          transition={{ duration: 4, ease: [0.2, 0.8, 0.2, 1] }}
          style={{
            background: `conic-gradient(
              #dc2626 0deg 60deg,
              #262626 60deg 120deg,
              #eab308 120deg 180deg,
              #b91c1c 180deg 240deg,
              #171717 240deg 300deg,
              #facc15 300deg 360deg
            )`
          }}
        >
          {rewards.map((reward, i) => {
            const angle = (360 / rewards.length) * i;
            return (
              <div 
                key={i}
                className="absolute w-full h-full origin-center"
                style={{
                  transform: `rotate(${angle + 30}deg)`,
                }}
              >
                <div className="absolute top-2 left-1/2 -translate-x-1/2 w-8 h-1/2 flex justify-center text-[10px] font-black uppercase text-white drop-shadow-md">
                  <span className="origin-top" style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}>
                    {reward}
                  </span>
                </div>
              </div>
            );
          })}
          
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-[#1a1a1a] rounded-full border-2 border-yellow-400 z-10 shadow-inner flex items-center justify-center"> 
             <div className="w-3 h-3 bg-red-600 rounded-full"></div>
          </div>
        </motion.div>
      </div>
      
      <div className="mt-6 z-10 w-full flex flex-col items-center">
        {result ? (
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="text-center"
          >
            <p className="text-yellow-400 font-bold text-lg">{result}</p>
            <p className="text-white/60 text-[10px] mt-1">Reward unlocked!</p>
          </motion.div>
        ) : (
          <motion.button 
            whileHover={{ scale: available ? 1.05 : 1 }}
            whileTap={{ scale: available ? 0.95 : 1 }}
            onClick={spin}
            disabled={spinning || !available}
            className="bg-red-600 text-white font-bold text-xs px-8 py-3 rounded-full uppercase tracking-widest shadow-[0_4px_14px_rgba(220,38,38,0.5)] disabled:opacity-50 disabled:cursor-not-allowed w-full max-w-[200px]"
          >
            {spinning ? 'Spinning...' : available ? 'Spin to Win' : 'Need more purchases'}
          </motion.button>
        )}
      </div>
    </div>
  );
}
