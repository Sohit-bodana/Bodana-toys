import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import * as Icons from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { Product } from '../types';
import ProductCard from './ProductCard';

interface CategoriesPageProps {
  onBuyNow: (product: Product) => void;
  onProductClick: (product: Product) => void;
  initialCategory?: string;
}

export default function CategoriesPage({ onBuyNow, onProductClick, initialCategory = 'all' }: CategoriesPageProps) {
  const { products, categories } = useAppContext();
  const [activeCategory, setActiveCategory] = useState(initialCategory);
  const [sortBy, setSortBy] = useState<'popular' | 'priceLow' | 'priceHigh' | 'discount'>('popular');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = useMemo(() => {
    let list = activeCategory === 'all'
      ? products
      : products.filter(p => p.category === activeCategory);

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(p => p.name.toLowerCase().includes(q));
    }

    switch (sortBy) {
      case 'priceLow':  return [...list].sort((a, b) => a.discountPrice - b.discountPrice);
      case 'priceHigh': return [...list].sort((a, b) => b.discountPrice - a.discountPrice);
      case 'discount':  return [...list].sort((a, b) => b.discountPercent - a.discountPercent);
      default:          return [...list].sort((a, b) => b.reviews - a.reviews);
    }
  }, [products, activeCategory, sortBy, searchQuery]);

  const getIcon = (iconName: string) => {
    const Icon = (Icons as any)[iconName];
    return Icon ? <Icon className="w-5 h-5" /> : <Icons.Package className="w-5 h-5" />;
  };

  return (
    <div className="flex flex-col h-full">
      {/* Page header */}
      <div className="px-5 pt-2 pb-3">
        <h2 className="text-2xl font-bold text-white">Shop</h2>
        <p className="text-white/40 text-xs mt-0.5">{filteredProducts.length} products</p>
      </div>

      {/* Search bar */}
      <div className="px-4 mb-3">
        <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-2xl px-4 py-2.5">
          <Icons.Search className="w-4 h-4 text-white/30 shrink-0" />
          <input
            type="text"
            placeholder="Search in category…"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="flex-1 bg-transparent text-white placeholder:text-white/30 text-sm focus:outline-none"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')}>
              <Icons.X className="w-4 h-4 text-white/40" />
            </button>
          )}
        </div>
      </div>

      {/* Category tabs — horizontal scroll */}
      <div className="flex gap-2 px-4 overflow-x-auto hide-scrollbar pb-2 shrink-0">
        {categories.map(cat => {
          const active = cat.id === activeCategory;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              style={active ? { backgroundColor: cat.color || '#dc2626', borderColor: cat.color || '#dc2626' } : {}}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap border transition-all duration-200 shrink-0 ${
                active
                  ? 'text-white shadow-lg scale-105'
                  : 'bg-white/5 border-white/10 text-white/60 hover:bg-white/10'
              }`}
            >
              <span>{getIcon(cat.icon)}</span>
              {cat.name}
            </button>
          );
        })}
      </div>

      {/* Sort row */}
      <div className="flex gap-2 px-4 mt-2 mb-3 overflow-x-auto hide-scrollbar shrink-0">
        {([
          { id: 'popular',   label: 'Popular' },
          { id: 'priceLow',  label: 'Price ↑' },
          { id: 'priceHigh', label: 'Price ↓' },
          { id: 'discount',  label: 'Discount' },
        ] as const).map(s => (
          <button
            key={s.id}
            onClick={() => setSortBy(s.id)}
            className={`px-3 py-1 rounded-full text-[10px] font-bold whitespace-nowrap transition-colors shrink-0 ${
              sortBy === s.id
                ? 'bg-red-600 text-white'
                : 'bg-white/5 border border-white/10 text-white/50'
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>

      {/* Products grid */}
      <div className="flex-1 overflow-y-auto hide-scrollbar px-4 pb-4">
        <AnimatePresence mode="wait">
          {filteredProducts.length === 0 ? (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-20 text-center"
            >
              <Icons.PackageOpen className="w-12 h-12 text-white/20 mb-3" />
              <p className="text-white/50 font-bold">No products found</p>
              <p className="text-white/30 text-xs mt-1">Try a different category or search term</p>
            </motion.div>
          ) : (
            <motion.div
              key={activeCategory + sortBy + searchQuery}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="grid grid-cols-2 gap-3"
            >
              {filteredProducts.map((product, idx) => (
                <div key={product.id} onClick={() => onProductClick(product)} className="cursor-pointer">
                  <ProductCard
                    product={product}
                    index={idx}
                    onBuyNow={onBuyNow}
                  />
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
