import { Product } from '../types';
import { Heart } from 'lucide-react';
import { motion } from 'framer-motion';
import { useDeveloper } from '../context/DeveloperContext';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';

interface ProductCardProps {
  product: Product;
  index: number;
  onBuyNow?: (product: Product) => void;
}

export default function ProductCard({ product, index, onBuyNow }: ProductCardProps) {
  const { settings } = useDeveloper();
  const { isInWishlist, addToWishlist, removeFromWishlist } = useWishlist();
  const { addToCart } = useCart();
  const isCompact = settings.cardLayout === 'compact';
  const wishlisted = isInWishlist(product.id);

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (wishlisted) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!product.isOutOfStock) {
      addToCart(product);
    }
  };

  if (isCompact) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true, margin: "50px" }}
        transition={{ delay: index * 0.05, duration: 0.4 }}
        className="bg-white/5 border border-white/10 rounded-2xl p-2 flex gap-3 backdrop-blur-sm relative group active:scale-95 transition-transform"
      >
        <div className="w-20 h-20 bg-white/10 rounded-xl overflow-hidden relative shrink-0">
          <img 
            src={product.image} 
            alt={product.name} 
            className={`w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 ${product.isOutOfStock ? 'opacity-50 grayscale' : 'opacity-90 group-hover:opacity-100'}`}
            loading="lazy"
          />
          {product.isOutOfStock && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-[2px]">
              <span className="bg-red-600 text-white text-[8px] font-bold px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                Out
              </span>
            </div>
          )}
          {!product.isOutOfStock && <ProductBadges product={product} compact />}
        </div>
        <div className="flex-1 min-w-0 flex flex-col justify-center">
          <h4 className={`font-bold text-xs truncate ${product.isOutOfStock ? 'text-white/50' : 'text-white'}`}>
            {product.name}
          </h4>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-red-500 font-bold text-sm">₹{product.discountPrice.toLocaleString()}</span>
            <span className="text-white/30 line-through text-[10px]">₹{product.originalPrice.toLocaleString()}</span>
          </div>
          <button 
            disabled={product.isOutOfStock}
            onClick={() => !product.isOutOfStock && onBuyNow?.(product)}
            className={`mt-2 w-full text-[10px] font-bold uppercase py-1.5 rounded-lg transition-colors shadow-lg ${product.isOutOfStock ? 'bg-white/5 text-white/30' : 'bg-red-600 text-white hover:bg-red-700'}`}
          >
            {product.isOutOfStock ? 'Out of Stock' : 'Buy Now'}
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, margin: "50px" }}
      transition={{ delay: index * 0.05, duration: 0.4 }}
      className="bg-white/5 border border-white/10 rounded-[24px] p-3 backdrop-blur-sm relative group active:scale-95 transition-transform"
    >
      <div className="absolute top-4 right-4 z-10 cursor-pointer" onClick={handleWishlistToggle}>
        <Heart 
          className={`w-4 h-4 transition-colors ${wishlisted ? 'fill-red-500 text-red-500' : 'text-white/40 group-hover:text-white'}`} 
          strokeWidth={2}
        />
      </div>
      
      <div className="w-full aspect-square bg-white/10 rounded-2xl mb-3 overflow-hidden relative">
        <img 
          src={product.image} 
          alt={product.name} 
          className={`w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 ${product.isOutOfStock ? 'opacity-50 grayscale' : 'opacity-90 group-hover:opacity-100'}`}
          loading="lazy"
        />
        {product.isOutOfStock && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-[2px]">
            <span className="bg-red-600 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              Out of Stock
            </span>
          </div>
        )}
        {!product.isOutOfStock && product.stock !== undefined && product.stock <= (product.lowStockThreshold ?? 3) && (
          <div className="absolute bottom-2 left-2 bg-yellow-400 text-black text-[9px] font-black px-2 py-1 rounded-full">
            Only {product.stock} left
          </div>
        )}
        {!product.isOutOfStock && <ProductBadges product={product} />}
      </div>
      
      <h4 className={`font-bold text-xs truncate ${product.isOutOfStock ? 'text-white/50' : 'text-white'}`}>
        {product.name}
      </h4>
      
      <div className="flex items-center gap-1 my-1">
        <span className="text-yellow-400 text-[10px]">★</span>
        <span className="text-white/60 text-[10px]">{product.rating} ({product.reviews})</span>
      </div>
      
      <div className="flex items-center gap-2">
        <span className="text-red-500 font-bold text-sm">₹{product.discountPrice.toLocaleString()}</span>
        <span className="text-white/30 line-through text-[10px]">₹{product.originalPrice.toLocaleString()}</span>
      </div>
      
      {product.discountPercent > 0 && (
        <div className="mt-2 bg-yellow-400 text-black text-[8px] font-black w-fit px-2 py-0.5 rounded italic">
          {product.discountPercent}% OFF
        </div>
      )}

      <div className="mt-3 flex flex-col gap-1.5">
        <motion.button 
          onClick={() => onBuyNow && !product.isOutOfStock && onBuyNow(product)}
          whileTap={{ scale: product.isOutOfStock ? 1 : 0.95 }}
          disabled={product.isOutOfStock}
          className={`w-full text-white text-xs font-bold py-2 rounded-xl transition-colors ${
            product.isOutOfStock 
              ? 'bg-neutral-800 text-white/30 cursor-not-allowed' 
              : 'bg-red-600 hover:bg-red-700 shadow-[0_4px_10px_rgba(220,38,38,0.4)]'
          }`}
        >
          {product.isOutOfStock ? 'Sold Out' : 'Buy Now'}
        </motion.button>
        <motion.button 
          whileTap={{ scale: product.isOutOfStock ? 1 : 0.95 }}
          disabled={product.isOutOfStock}
          onClick={handleAddToCart}
          className={`w-full text-[10px] font-semibold py-1.5 rounded-xl border transition-colors ${
            product.isOutOfStock
              ? 'bg-transparent border-white/5 text-white/20 cursor-not-allowed'
              : 'bg-white/10 hover:bg-white/20 text-white border-white/5'
          }`}
        >
          Add to Cart
        </motion.button>
      </div>
    </motion.div>
  );
}

function ProductBadges({ product, compact = false }: { product: Product; compact?: boolean }) {
  const badges = [
    product.stock !== undefined && product.stock <= (product.lowStockThreshold ?? 3)
      ? { label: 'Low Stock', className: 'bg-yellow-400 text-black' }
      : null,
    product.section === 'bestSellers'
      ? { label: 'Bestseller', className: 'bg-red-600 text-white' }
      : null,
    product.section === 'newArrivals'
      ? { label: 'New Arrival', className: 'bg-blue-500 text-white' }
      : null,
  ].filter(Boolean) as { label: string; className: string }[];

  if (badges.length === 0) return null;

  return (
    <div className={`absolute ${compact ? 'top-1.5 left-1.5' : 'top-2 left-2'} flex flex-col items-start gap-1`}>
      {badges.map(badge => (
        <span
          key={badge.label}
          className={`${badge.className} ${compact ? 'text-[7px] px-1 py-0.5 rounded' : 'text-[8px] px-1.5 py-0.5 rounded-md'} font-black uppercase tracking-wide shadow`}
        >
          {badge.label}
        </span>
      ))}
    </div>
  );
}
