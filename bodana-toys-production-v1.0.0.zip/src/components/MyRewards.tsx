import React, { useState } from 'react';
import { CheckCircle2, Gift, Plus, ShieldCheck, Tag, Ticket, Trophy } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { useRewards } from '../context/RewardsContext';

export default function MyRewards() {
  const { adminSettings } = useAppContext();
  const { user } = useAuth();
  const { rewards, availableRewards, saveCouponReward, saveOfferReward, saveGiftCardReward } = useRewards();
  const [showGiftCardForm, setShowGiftCardForm] = useState(false);
  const [giftCardCode, setGiftCardCode] = useState('');
  const [giftCardBalance, setGiftCardBalance] = useState('');
  const [message, setMessage] = useState('');

  const saveCoupon = async (coupon: typeof adminSettings.coupons[number]) => {
    await saveCouponReward(coupon);
    setMessage(`${coupon.code} saved to My Rewards`);
    setTimeout(() => setMessage(''), 2200);
  };

  const saveOffer = async (offer: typeof adminSettings.offers[number]) => {
    await saveOfferReward(offer);
    setMessage(`${offer.title} saved to My Rewards`);
    setTimeout(() => setMessage(''), 2200);
  };

  const addGiftCard = async (event: React.FormEvent) => {
    event.preventDefault();
    const balance = Number(giftCardBalance);
    if (!giftCardCode.trim() || !Number.isFinite(balance) || balance <= 0) return;
    await saveGiftCardReward(giftCardCode, balance);
    setGiftCardCode('');
    setGiftCardBalance('');
    setShowGiftCardForm(false);
    setMessage('Gift card saved to My Rewards');
    setTimeout(() => setMessage(''), 2200);
  };

  const activeAdminCoupons = adminSettings.coupons.filter(coupon =>
    coupon.active && (!coupon.expiryDate || new Date(`${coupon.expiryDate}T23:59:59`).getTime() >= Date.now()),
  );
  const activeAdminOffers = adminSettings.offers.filter(offer =>
    offer.active && (!offer.expiryDate || new Date(`${offer.expiryDate}T23:59:59`).getTime() >= Date.now()),
  );

  return (
    <div className="px-6 mt-8 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Gift className="w-5 h-5 text-yellow-400" />
          <h3 className="font-bold text-white text-sm">My Rewards</h3>
        </div>
        <span className="text-white/40 text-[10px] font-bold">{availableRewards.length} available</span>
      </div>

      {message && <p className="text-green-400 text-[10px] font-bold">{message}</p>}

      {user?.founderBadge && (
        <div className="bg-gradient-to-r from-yellow-500/15 to-red-500/10 border border-yellow-500/30 rounded-2xl p-3 flex items-center gap-3">
          <Trophy className="w-6 h-6 text-yellow-400" />
          <div>
            <p className="text-yellow-400 text-[10px] font-black uppercase tracking-widest">Founder Badge</p>
            <p className="text-white font-black"># {user.founderBadge}</p>
          </div>
          <CheckCircle2 className="w-4 h-4 text-green-400 ml-auto" />
        </div>
      )}

      {rewards.map(reward => (
        <div key={reward.id} className={`bg-white/5 border border-white/10 rounded-2xl p-3 flex items-center gap-3 ${reward.usedAt ? 'opacity-40' : ''}`}>
          {reward.type === 'coupon' ? <Tag className="w-5 h-5 text-red-400" /> : reward.type === 'giftCard' ? <Ticket className="w-5 h-5 text-blue-400" /> : <Gift className="w-5 h-5 text-yellow-400" />}
          <div className="flex-1 min-w-0">
            <p className="text-white font-bold text-xs truncate">{reward.title}</p>
            <p className="text-white/40 text-[10px] truncate">{reward.description || 'Saved reward'}</p>
            {reward.expiresAt && <p className="text-white/30 text-[9px]">Expires {reward.expiresAt}</p>}
          </div>
          <span className="text-[9px] font-bold uppercase text-white/40">{reward.usedAt ? 'Used' : 'Saved'}</span>
        </div>
      ))}

      {activeAdminCoupons.length > 0 && (
        <div className="space-y-2 pt-1">
          <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider">Available Coupons</p>
          {activeAdminCoupons.map(coupon => (
            <div key={coupon.id} className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center gap-3">
              <Tag className="w-4 h-4 text-red-400" />
              <div className="flex-1">
                <p className="text-white text-xs font-bold">{coupon.code}</p>
                <p className="text-white/40 text-[10px]">{coupon.discountType === 'percent' ? `${coupon.value}% off` : `₹${coupon.value} off`}</p>
              </div>
              <button onClick={() => saveCoupon(coupon)} className="bg-red-600 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg">Save</button>
            </div>
          ))}
        </div>
      )}

      {activeAdminOffers.length > 0 && (
        <div className="space-y-2 pt-1">
          <p className="text-white/40 text-[10px] font-bold uppercase tracking-wider">Special Offers</p>
          {activeAdminOffers.map(offer => (
            <div key={offer.id} className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center gap-3">
              <Gift className="w-4 h-4 text-yellow-400" />
              <div className="flex-1">
                <p className="text-white text-xs font-bold">{offer.title}</p>
                <p className="text-white/40 text-[10px] truncate">{offer.discount} · {offer.description}</p>
              </div>
              <button onClick={() => saveOffer(offer)} className="bg-red-600 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg">Save</button>
            </div>
          ))}
        </div>
      )}

      {showGiftCardForm ? (
        <form onSubmit={addGiftCard} className="bg-white/5 border border-white/10 rounded-xl p-3 space-y-2">
          <input value={giftCardCode} onChange={event => setGiftCardCode(event.target.value)} placeholder="Gift card code" className="w-full bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-white text-xs placeholder:text-white/30 focus:outline-none focus:border-red-500" />
          <input value={giftCardBalance} onChange={event => setGiftCardBalance(event.target.value)} type="number" min="1" placeholder="Balance (₹)" className="w-full bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-white text-xs placeholder:text-white/30 focus:outline-none focus:border-red-500" />
          <button className="w-full bg-red-600 text-white text-xs font-bold py-2 rounded-xl">Save Gift Card</button>
        </form>
      ) : (
        <button onClick={() => setShowGiftCardForm(true)} className="w-full flex items-center justify-center gap-2 bg-white/5 border border-white/10 rounded-xl p-3 text-white/60 text-xs font-bold">
          <Plus className="w-4 h-4" /> Save Gift Card
        </button>
      )}
    </div>
  );
}