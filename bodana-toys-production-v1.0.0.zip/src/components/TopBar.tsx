import { Search, ShoppingCart } from 'lucide-react';
import { motion } from 'framer-motion';
import { useDeveloper } from '../context/DeveloperContext';
import { useCart } from '../context/CartContext';

interface TopBarProps {
  onSearchClick: () => void;
  onCartClick?: () => void;
}

export default function TopBar({ onSearchClick, onCartClick }: TopBarProps) {
  const { settings } = useDeveloper();
  const { cart } = useCart();
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <>
      {settings.offerText && (
        <div className="absolute top-0 left-0 right-0 h-6 bg-red-600 z-[60] flex items-center justify-center overflow-hidden">
          <motion.div 
            animate={{ x: [300, -300] }}
            transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
            className="whitespace-nowrap text-[10px] font-bold text-white uppercase tracking-widest"
          >
            {settings.offerText}
          </motion.div>
        </div>
      )}
      <motion.div 
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className={`absolute ${settings.offerText ? 'top-6' : 'top-0'} left-0 right-0 bg-black/60 backdrop-blur-md z-50 px-6 py-4 flex items-center justify-between border-b border-white/5 transition-all`}
      >
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 relative flex items-center justify-center">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" className="text-red-500 absolute top-1 left-0" xmlns="http://www.w3.org/2000/svg">
            <path d="M7 6C5.34315 6 4 7.34315 4 9C4 9.42939 4.09 9.83777 4.25055 10.205C3.51326 11.2386 3 12.5539 3 14C3 17.866 6.13401 21 10 21H14C17.866 21 21 17.866 21 14C21 12.5539 20.4867 11.2386 19.7495 10.205C19.91 9.83777 20 9.42939 20 9C20 7.34315 18.6569 6 17 6C15.9329 6 14.9961 6.55648 14.4715 7.41165C13.6896 7.14728 12.8617 7 12 7C11.1383 7 10.3104 7.14728 9.52854 7.41165C9.0039 6.55648 8.06714 6 7 6ZM8 14C8 14.5523 7.55228 15 7 15C6.44772 15 6 14.5523 6 14C6 13.4477 6.44772 13 7 13C7.55228 13 8 13.4477 8 14ZM18 14C18 14.5523 17.5523 15 17 15C16.4477 15 16 14.5523 16 14C16 13.4477 16.4477 13 17 13C17.5523 13 18 13.4477 18 14ZM12 17C10.8954 17 10 16.1046 10 15H14C14 16.1046 13.1046 17 12 17Z" />
          </svg>
          <div className="w-3.5 h-3.5 bg-yellow-400 rounded-[3px] shadow-[inset_0_-1px_2px_rgba(0,0,0,0.3)] absolute bottom-0 right-0 border-[0.5px] border-yellow-500 flex items-center justify-center transform rotate-6">
            <span className="text-black font-black text-[7px]">B</span>
          </div>
        </div>
        <div className="flex flex-col ml-1">
          <span className="text-[10px] text-yellow-400 font-bold tracking-widest uppercase">Bodana Na</span>
          <h1 className="text-white font-black text-lg -mt-1">TOYS</h1>
        </div>
      </div>
      
      <div className="flex gap-4">
        <div 
          onClick={onSearchClick}
          className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white cursor-pointer hover:bg-white/20 transition-colors"
        >
          <Search className="w-[18px] h-[18px]" strokeWidth={2} />
        </div>
        <div 
          onClick={onCartClick}
          className="relative w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white cursor-pointer hover:bg-white/20 transition-colors"
        >
          <ShoppingCart className="w-[18px] h-[18px]" strokeWidth={2} />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 text-[10px] flex items-center justify-center rounded-full font-bold">
              {cartCount > 9 ? '9+' : cartCount}
            </span>
          )}
        </div>
      </div>
    </motion.div>
    </>
  );
}
