import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, X, CheckCircle, AlertCircle } from 'lucide-react';
import { mapAuthError, useAuth } from '../context/AuthContext';

interface CustomerLoginProps {
  isOpen: boolean;
}

type View = 'options' | 'login' | 'signup' | 'forgot' | 'verify';

export default function CustomerLogin({ isOpen }: CustomerLoginProps) {
  const {
    user,
    isFirebaseEnabled,
    loginWithGoogle,
    loginWithEmail,
    sendPhoneOtp,
    verifyPhoneOtp,
    signupWithEmail,
    resetPassword,
  } = useAuth();

  const [view, setView] = useState<View>('options');
  const [method, setMethod] = useState<'email' | 'phone'>('phone');

  const [name, setName] = useState('');
  const [inputValue, setInputValue] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [phoneOtp, setPhoneOtp] = useState('');
  const [phoneOtpSent, setPhoneOtpSent] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  useEffect(() => {
    if (!isOpen) {
      setError('');
      setSuccessMsg('');
      setIsSubmitting(false);
    setPhoneOtp('');
    setPhoneOtpSent(false);
    }
  }, [isOpen]);

  const clearMessages = () => { setError(''); setSuccessMsg(''); };

  const handleError = (err: unknown) => {
    const code = (err as { code?: string })?.code || '';
    setError(code ? mapAuthError(code) : 'Something went wrong. Please try again.');
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    clearMessages();

    const isEmailSignup = view === 'signup' && method === 'email';
    const isPhoneAuth = method === 'phone' && (view === 'login' || view === 'signup');

    if (isEmailSignup) {
      if (!name.trim()) { setError('Please enter your full name.'); return; }
      if (password.length < 8) { setError('Password must be at least 8 characters.'); return; }
      if (password !== confirmPassword) { setError('Passwords do not match.'); return; }
    }
    if (view === 'forgot' && !inputValue.includes('@')) {
      setError('Please enter a valid email address.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (view === 'forgot') {
        await resetPassword(inputValue.trim());
        setSuccessMsg(`Reset link sent to ${inputValue.trim()}. Check your inbox.`);
        return;
      }

      if (isPhoneAuth) {
        if (!inputValue.trim()) {
          setError('Please enter your phone number with country code.');
          return;
        }
        if (phoneOtpSent) {
          if (!/^\d{6}$/.test(phoneOtp.trim())) {
            setError('Please enter the 6-digit OTP.');
            return;
          }
          await verifyPhoneOtp(phoneOtp);
          setPhoneOtpSent(false);
          setPhoneOtp('');
          return;
        }
        await sendPhoneOtp(inputValue.trim(), view === 'signup' ? name.trim() : undefined);
        setPhoneOtpSent(true);
        setSuccessMsg('OTP sent to your phone. Enter it below to continue.');
        return;
      }

      if (view === 'login') {
        await loginWithEmail(inputValue.trim(), password, rememberMe);
      }

      if (view === 'signup') {
        await signupWithEmail(inputValue.trim(), password, name.trim());
      }
    } catch (err) {
      handleError(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleSignIn = async () => {
    clearMessages();
    setIsSubmitting(true);
    try {
      await loginWithGoogle();
    } catch (err) {
      handleError(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const goTo = (v: View) => {
    clearMessages();
    setView(v);
    if (v === 'login' || v === 'signup') setMethod('phone');
    setPhoneOtp('');
    setPhoneOtpSent(false);
  };

  const title = {
    options: 'Welcome to Bodana Toys',
    login: 'Welcome Back',
    signup: 'Create Account',
    forgot: 'Reset Password',
      verify: 'Verify Your Phone',
  }[view];

  const subtitle = {
    options: 'Sign in to start shopping and get exclusive deals!',
    login: 'Sign in to start shopping and get exclusive deals!',
    signup: 'Sign in to start shopping and get exclusive deals!',
    forgot: 'Enter your email to receive a reset link.',
      verify: 'Enter the verification code sent to your phone.',
  }[view];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="absolute inset-0 z-[200] flex items-end justify-center sm:items-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />

          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.95 }}
            className="relative w-full max-w-sm bg-[#111] border border-white/10 rounded-[32px] p-6 overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 rounded-full blur-3xl -z-10" />

            {!isFirebaseEnabled && (
              <div className="mb-4 bg-yellow-500/10 border border-yellow-500/30 rounded-xl px-3 py-2 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-yellow-400 shrink-0" />
                <p className="text-yellow-400 text-[10px] font-bold">
                  Dev mode — Firebase not configured. Auth is simulated.
                </p>
              </div>
            )}

            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-white/5 rounded-2xl mx-auto flex items-center justify-center mb-4 border border-white/10 shadow-[inset_0_2px_10px_rgba(255,255,255,0.05)]">
                {view === 'verify' ? (
                  <Mail className="w-7 h-7 text-red-400" />
                ) : (
                  <span className="text-2xl font-black text-white">BT</span>
                )}
              </div>
              <h2 className="text-2xl font-bold text-white mb-1">{title}</h2>
              <p className="text-white/50 text-sm">{subtitle}</p>
            </div>

            {view === 'options' && (
              <div className="space-y-3">
                <button
                  onClick={() => goTo('signup')}
                  className="w-full flex items-center justify-center gap-3 bg-red-600 text-white font-bold py-3.5 rounded-xl hover:bg-red-700 transition-colors"
                >
                  Create New Account
                </button>
                <div className="flex items-center gap-4 py-2">
                  <div className="flex-1 h-px bg-white/10" />
                  <span className="text-white/30 text-xs font-bold uppercase">or</span>
                  <div className="flex-1 h-px bg-white/10" />
                </div>
                <button
                  onClick={() => goTo('login')}
                  className="w-full flex items-center justify-center gap-3 bg-white/10 text-white font-bold py-3.5 rounded-xl hover:bg-white/15 transition-colors border border-white/5"
                >
                  Login to Existing Account
                </button>
                <button
                  onClick={handleGoogleSignIn}
                  disabled={isSubmitting}
                  className="w-full flex items-center justify-center gap-3 bg-white text-black font-bold py-3.5 rounded-xl hover:bg-neutral-200 transition-colors disabled:opacity-60"
                >
                  {isSubmitting ? 'Signing in...' : (
                    <>
                      <svg className="w-5 h-5" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                      </svg>
                      Continue with Google
                    </>
                  )}
                </button>
              </div>
            )}

            {(view === 'login' || view === 'signup' || view === 'forgot') && (
              <form onSubmit={handleSubmit} noValidate className="space-y-4">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <button type="button" onClick={() => goTo('options')} className="text-white/50 hover:text-white">
                      <X className="w-5 h-5" />
                    </button>
                    <span className="text-white font-bold">
                      {view === 'login' ? 'Login' : view === 'signup' ? 'Sign Up' : 'Reset'}
                    </span>
                  </div>

                  {view !== 'forgot' && (
                    <div className="flex bg-white/5 p-1 rounded-lg">
                      <button
                        type="button"
                        onClick={() => setMethod('email')}
                        className={`px-3 py-1 rounded-md text-xs font-bold transition-colors ${method === 'email' ? 'bg-white/10 text-white' : 'text-white/40'}`}
                      >
                        Email
                      </button>
                      <button
                        type="button"
                        onClick={() => setMethod('phone')}
                        className={`px-3 py-1 rounded-md text-xs font-bold transition-colors ${method === 'phone' ? 'bg-white/10 text-white' : 'text-white/40'}`}
                      >
                        Phone
                      </button>
                    </div>
                  )}
                </div>

                {method === 'phone' && view !== 'forgot' && (
                  <div className="bg-white/5 border border-white/10 rounded-xl px-3 py-3 text-center">
                    <p className="text-white/50 text-xs">
                      We'll send a one-time password to your phone.
                    </p>
                  </div>
                )}

                {view === 'signup' && method === 'email' && (
                  <input
                    type="text"
                    placeholder="Full name"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    required
                    autoComplete="name"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder:text-white/30 focus:outline-none focus:border-red-500 focus:bg-white/10 transition-colors"
                  />
                )}

                {method === 'phone' && (
                  <input
                    autoFocus
                    type="tel"
                    placeholder="+91 9876543210"
                    value={inputValue}
                    onChange={e => setInputValue(e.target.value)}
                    required
                    autoComplete="tel"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder:text-white/30 focus:outline-none focus:border-red-500 focus:bg-white/10 transition-colors"
                  />
                )}

                {method === 'phone' && phoneOtpSent && (
                  <input
                    type="text"
                    inputMode="numeric"
                    placeholder="6-digit OTP"
                    value={phoneOtp}
                    onChange={e => setPhoneOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    autoComplete="one-time-code"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder:text-white/30 focus:outline-none focus:border-red-500 focus:bg-white/10 transition-colors"
                  />
                )}

                {method !== 'phone' && (
                  <input
                    autoFocus={view !== 'signup'}
                    type="email"
                    placeholder="name@gmail.com"
                    value={inputValue}
                    onChange={e => setInputValue(e.target.value)}
                    required
                    autoComplete="email"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder:text-white/30 focus:outline-none focus:border-red-500 focus:bg-white/10 transition-colors"
                  />
                )}

                {view !== 'forgot' && method === 'email' && (
                  <input
                    type="password"
                    placeholder={view === 'signup' ? 'Password (min. 8 characters)' : 'Password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    required
                    autoComplete={view === 'signup' ? 'new-password' : 'current-password'}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder:text-white/30 focus:outline-none focus:border-red-500 focus:bg-white/10 transition-colors"
                  />
                )}

                {view === 'signup' && method === 'email' && (
                  <input
                    type="password"
                    placeholder="Confirm password"
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    required
                    autoComplete="new-password"
                    className={`w-full bg-white/5 border rounded-xl px-4 py-3.5 text-white placeholder:text-white/30 focus:outline-none focus:bg-white/10 transition-colors ${
                      confirmPassword && password !== confirmPassword
                        ? 'border-red-500'
                        : 'border-white/10 focus:border-red-500'
                    }`}
                  />
                )}

                {view === 'login' && method === 'email' && (
                  <div className="flex items-center justify-between text-xs">
                    <label className="flex items-center gap-2 text-white/50 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={rememberMe}
                        onChange={e => setRememberMe(e.target.checked)}
                        className="rounded border-white/20 bg-white/5 text-red-500 focus:ring-red-500/20"
                      />
                      Remember me
                    </label>
                    <button
                      type="button"
                      onClick={() => goTo('forgot')}
                      className="text-red-400 hover:text-red-300 font-bold"
                    >
                      Forgot Password?
                    </button>
                  </div>
                )}

                {error && (
                  <p className="text-red-500 text-xs font-bold flex items-start gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" /> {error}
                  </p>
                )}
                {successMsg && (
                  <p className="text-green-400 text-xs font-bold flex items-start gap-1">
                    <CheckCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" /> {successMsg}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={isSubmitting || !inputValue.trim() || (method === 'phone' && phoneOtpSent && !phoneOtp.trim()) || (method === 'email' && view !== 'forgot' && !password.trim())}
                  className="w-full bg-red-600 disabled:bg-neutral-800 disabled:text-white/30 text-white font-bold py-3.5 rounded-xl hover:bg-red-700 transition-colors"
                >
                  {isSubmitting
                    ? (view === 'forgot' ? 'Sending...' : method === 'phone' ? (phoneOtpSent ? 'Verifying...' : 'Sending OTP...') : view === 'login' ? 'Signing in...' : 'Creating account...')
                    : (view === 'forgot' ? 'Send Reset Link' : method === 'phone' ? (phoneOtpSent ? 'Verify OTP' : 'Send OTP') : view === 'login' ? 'Login' : 'Create Account')}
                </button>

                {view === 'login' && (
                  <p className="text-center text-xs text-white/50 mt-4">
                    Don't have an account?{' '}
                    <button type="button" onClick={() => goTo('signup')} className="text-white font-bold hover:underline">
                      Sign up
                    </button>
                  </p>
                )}
                {view === 'signup' && (
                  <p className="text-center text-xs text-white/50 mt-4">
                    Already have an account?{' '}
                    <button type="button" onClick={() => goTo('login')} className="text-white font-bold hover:underline">
                      Login
                    </button>
                  </p>
                )}
                {view === 'forgot' && (
                  <p className="text-center text-xs text-white/50 mt-4">
                    Remember it?{' '}
                    <button type="button" onClick={() => goTo('login')} className="text-white font-bold hover:underline">
                      Back to Login
                    </button>
                  </p>
                )}
              </form>
            )}

            <p className="text-center text-white/30 text-[10px] mt-6">
              By continuing, you agree to our Terms of Service and Privacy Policy.
            </p>
            <div id="recaptcha-container" />
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
