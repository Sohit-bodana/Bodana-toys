import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { banners } from '../data';
import { useDeveloper } from '../context/DeveloperContext';

interface HeroBannerProps {
  onShopNow?: () => void;
  onExplorePremium?: () => void;
}

export default function HeroBanner({ onShopNow, onExplorePremium }: HeroBannerProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const { settings } = useDeveloper();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % banners.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  const displayBanners = settings.bannerTitle !== "Experience the Joy of Premium Toys" ? 
    [{ title: settings.bannerTitle, subtitle: "Exclusive Offer", image: settings.bannerImage }] : banners;

  const currentBannerIndex = currentIndex % displayBanners.length;

  return (
    <div className="px-4 py-2">
      <div className="relative h-44 w-full rounded-3xl bg-gradient-to-br from-red-600 via-red-800 to-black overflow-hidden shadow-lg border border-white/5">
        <AnimatePresence initial={false} mode="wait">
          <motion.div
            key={currentBannerIndex}
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="absolute inset-0"
          >
            <div className="absolute inset-0">
              <img 
                src={displayBanners[currentBannerIndex].image} 
                alt={displayBanners[currentBannerIndex].title}
                className="w-full h-full object-cover mix-blend-overlay opacity-60"
              />
            </div>
            <div className="absolute inset-0 bg-black/20" />
            
            <div className="relative z-10 p-6 flex flex-col justify-center h-full">
              <motion.span 
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-yellow-400 font-bold text-xs uppercase tracking-widest mb-1"
              >
                Discover Premium Toys That Kids Truly Love.
              </motion.span>
              <motion.h2 
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="text-white text-3xl font-black leading-tight mb-2 uppercase"
              >
                Bring Home More Smiles.
              </motion.h2>
              <div className="flex items-center gap-2">
                <motion.button 
                  initial={{ y: 10, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  onClick={onShopNow}
                  className="bg-yellow-400 text-black text-[10px] font-bold px-4 py-2 rounded-full w-fit uppercase tracking-tighter shadow-lg"
                >
                  🛒 Shop Now
                </motion.button>
                <motion.button 
                  initial={{ y: 10, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  onClick={onExplorePremium}
                  className="bg-white/10 border border-white/10 text-white text-[10px] font-bold px-4 py-2 rounded-full w-fit uppercase tracking-tighter shadow-lg"
                >
                  ⭐ Explore Premium Toys
                </motion.button>
              </div>
            </div>
            <div className="absolute right-[-10px] bottom-[-20px] w-40 h-40 bg-white/10 rounded-full blur-3xl pointer-events-none" />
          </motion.div>
        </AnimatePresence>
        
        {/* Pagination Dots */}
        <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5 z-20">
          {banners.map((_, idx) => (
            <div 
              key={idx} 
              className={`h-1.5 rounded-full transition-all duration-300 ${idx === currentIndex ? 'w-6 bg-white' : 'w-1.5 bg-white/40'}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
