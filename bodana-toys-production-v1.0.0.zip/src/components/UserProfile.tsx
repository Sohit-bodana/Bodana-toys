import React, { useState } from 'react';
import { Award, Package, CreditCard, ChevronRight, LogOut, ShieldAlert, Settings, Palette, MapPin, Plus, Trash2, X } from 'lucide-react';
import { useAppContext, AppTheme } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { useOrders } from '../context/OrderContext';
import MyRewards from './MyRewards';

interface UserProfileProps {
  onAdminClick: () => void;
  onOrderHistoryClick?: () => void;
}

export default function UserProfile({ onAdminClick, onOrderHistoryClick }: UserProfileProps) {
  const { theme, setTheme } = useAppContext();
  const { logout, user, addAddress, removeAddress } = useAuth();
  const { orders } = useOrders();
  const [showAddresses, setShowAddresses] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [addingAddress, setAddingAddress] = useState(false);
  const [addrForm, setAddrForm] = useState({ title: '', line1: '', line2: '', city: '', state: '', pincode: '' });

  const totalOrders = orders.length;
  const totalSpent = orders.reduce((sum, o) => sum + o.total, 0);

  const handleAddAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addrForm.title || !addrForm.line1 || !addrForm.city || !addrForm.state || !addrForm.pincode) return;
    await addAddress(addrForm);
    setAddrForm({ title: '', line1: '', line2: '', city: '', state: '', pincode: '' });
    setAddingAddress(false);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] overflow-y-auto hide-scrollbar pb-24">
      <div className="px-6 pt-6 pb-8 bg-gradient-to-b from-red-900/20 to-transparent relative">
        <div className="flex justify-between items-start mb-6">
          <h2 className="text-2xl font-bold text-white">Profile</h2>
          <button
            onClick={() => setShowSettings(s => !s)}
            className="text-white/50 hover:text-white transition-colors"
          >
            <Settings className="w-6 h-6" />
          </button>
        </div>

        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-red-500 to-yellow-500 p-[2px]">
            <div className="w-full h-full bg-[#111] rounded-full flex items-center justify-center">
              <span className="text-2xl font-bold text-white">{user?.displayName?.charAt(0) || user?.email?.charAt(0) || user?.phone?.charAt(0) || 'U'}</span>
            </div>
          </div>
          <div>
            <p className="text-yellow-400 text-[10px] font-bold uppercase tracking-widest mb-1">Bodana Na Toys</p>
            <h3 className="text-xl font-bold text-white">{user?.displayName || 'Customer'}</h3>
            <p className="text-white/50 text-sm">{user?.email || user?.phone || `ID: #${user?.id}`}</p>
          </div>
        </div>
      </div>

      {showSettings && (
        <div className="mx-6 mb-4 bg-white/5 border border-white/10 rounded-2xl p-4">
          <h4 className="text-white font-bold text-sm mb-3">Account Info</h4>
          <div className="space-y-2 text-xs text-white/60">
            {user?.displayName && <p>Name: <span className="text-white">{user.displayName}</span></p>}
            {user?.email && <p>Email: <span className="text-white">{user.email}</span></p>}
            {user?.phone && <p>Phone: <span className="text-white">{user.phone}</span></p>}
            <p>User ID: <span className="text-white/40 font-mono text-[10px]">#{user?.id}</span></p>
          </div>
        </div>
      )}

      <div className="px-6 -mt-4">
        <div className="bg-gradient-to-r from-yellow-500/10 to-yellow-500/5 border border-yellow-500/20 rounded-2xl p-4 backdrop-blur-md relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-yellow-500/20 rounded-full blur-xl -z-10" />
          
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-yellow-400" />
              <span className="font-bold text-yellow-400">Gold Level</span>
            </div>
            <span className="text-xs font-bold text-white/50">850 / 1000 pts to Platinum</span>
          </div>
          
          <div className="w-full h-1.5 bg-black/50 rounded-full overflow-hidden">
            <div className="w-[85%] h-full bg-gradient-to-r from-yellow-500 to-yellow-300" />
          </div>
        </div>
      </div>

      {user?.founderBadge && (
        <div className="px-6 mt-4">
          <div className="bg-gradient-to-r from-yellow-500/15 to-red-500/10 border border-yellow-500/30 rounded-2xl p-4 flex items-center gap-3">
            <Award className="w-7 h-7 text-yellow-400 shrink-0" />
            <div>
              <p className="text-yellow-400 text-[10px] font-black uppercase tracking-widest">Founder Customer</p>
              <p className="text-white font-black text-lg">Badge #{user.founderBadge}</p>
              <p className="text-white/40 text-[10px]">Permanent founder status</p>
            </div>
          </div>
        </div>
      )}

      <MyRewards />

      <div className="px-6 mt-6 grid grid-cols-2 gap-4">
        <div className="bg-white/5 border border-white/10 rounded-2xl p-4">
          <Package className="w-6 h-6 text-white/50 mb-2" />
          <p className="text-2xl font-bold text-white">{totalOrders}</p>
          <p className="text-xs text-white/50 font-medium">Total Orders</p>
        </div>
        <div className="bg-white/5 border border-white/10 rounded-2xl p-4">
          <CreditCard className="w-6 h-6 text-white/50 mb-2" />
          <p className="text-2xl font-bold text-white">₹{totalSpent.toLocaleString()}</p>
          <p className="text-xs text-white/50 font-medium">Total Spent</p>
        </div>
      </div>

      <div className="px-6 mt-8 space-y-4">
        <div className="flex items-center gap-2">
          <Palette className="w-5 h-5 text-white/50" />
          <h3 className="font-bold text-white text-sm">App Theme</h3>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setTheme('black')}
            className={`flex-1 py-3 rounded-xl border ${theme === 'black' ? 'border-red-500 bg-red-500/10' : 'border-white/10 bg-white/5'} transition-colors`}
          >
            <div className="w-6 h-6 rounded-full bg-[#0a0a0a] border border-white/20 mx-auto mb-2" />
            <span className="text-[10px] font-bold text-white uppercase tracking-wider">Black</span>
          </button>
          <button 
            onClick={() => setTheme('white')}
            className={`flex-1 py-3 rounded-xl border ${theme === 'white' ? 'border-red-500 bg-red-500/10' : 'border-white/10 bg-white/5'} transition-colors`}
          >
            <div className="w-6 h-6 rounded-full bg-white border border-black/20 mx-auto mb-2" />
            <span className="text-[10px] font-bold text-white uppercase tracking-wider">White</span>
          </button>
          <button 
            onClick={() => setTheme('gold')}
            className={`flex-1 py-3 rounded-xl border ${theme === 'gold' ? 'border-red-500 bg-red-500/10' : 'border-white/10 bg-white/5'} transition-colors`}
          >
            <div className="w-6 h-6 rounded-full bg-[#d4af37] border border-black/20 mx-auto mb-2" />
            <span className="text-[10px] font-bold text-white uppercase tracking-wider">Gold</span>
          </button>
        </div>
      </div>

      <div className="px-6 mt-6 space-y-2 flex-1">
        <button
          onClick={onOrderHistoryClick}
          className="w-full flex items-center justify-between bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl p-4 transition-colors"
        >
          <div className="flex items-center gap-3">
            <Package className="w-5 h-5 text-white/50" />
            <span className="font-bold text-white text-sm">Order History</span>
          </div>
          <div className="flex items-center gap-2">
            {totalOrders > 0 && (
              <span className="text-[10px] bg-red-600 text-white font-bold px-2 py-0.5 rounded-full">{totalOrders}</span>
            )}
            <ChevronRight className="w-4 h-4 text-white/30" />
          </div>
        </button>

        <button
          onClick={() => setShowAddresses(s => !s)}
          className="w-full flex items-center justify-between bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl p-4 transition-colors"
        >
          <div className="flex items-center gap-3">
            <CreditCard className="w-5 h-5 text-white/50" />
            <span className="font-bold text-white text-sm">Saved Addresses</span>
          </div>
          <div className="flex items-center gap-2">
            {(user?.addresses?.length ?? 0) > 0 && (
              <span className="text-[10px] bg-white/10 text-white/50 font-bold px-2 py-0.5 rounded-full">{user?.addresses?.length}</span>
            )}
            <ChevronRight className={`w-4 h-4 text-white/30 transition-transform ${showAddresses ? 'rotate-90' : ''}`} />
          </div>
        </button>

        {showAddresses && (
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 space-y-3">
            {(user?.addresses ?? []).length === 0 && !addingAddress && (
              <p className="text-white/40 text-xs text-center py-2">No saved addresses yet</p>
            )}
            {(user?.addresses ?? []).map(addr => (
              <div key={addr.id} className="flex items-start justify-between gap-3 bg-white/5 border border-white/10 rounded-xl p-3">
                <div className="flex items-start gap-2 flex-1 min-w-0">
                  <MapPin className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <div className="min-w-0">
                    <p className="text-white font-bold text-xs">{addr.title}</p>
                    <p className="text-white/50 text-[10px] mt-0.5">{addr.line1}{addr.line2 ? `, ${addr.line2}` : ''}</p>
                    <p className="text-white/50 text-[10px]">{addr.city}, {addr.state} — {addr.pincode}</p>
                  </div>
                </div>
                <button onClick={() => removeAddress(addr.id)} className="text-red-400/50 hover:text-red-400 transition-colors shrink-0">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
            {addingAddress ? (
              <form onSubmit={handleAddAddress} className="space-y-2">
                {[
                  { key: 'title', placeholder: 'Label (e.g. Home, Office)' },
                  { key: 'line1', placeholder: 'Address Line 1' },
                  { key: 'line2', placeholder: 'Address Line 2 (optional)' },
                  { key: 'city', placeholder: 'City' },
                  { key: 'state', placeholder: 'State' },
                  { key: 'pincode', placeholder: 'Pincode' },
                ].map(f => (
                  <input
                    key={f.key}
                    type="text"
                    placeholder={f.placeholder}
                    value={(addrForm as any)[f.key]}
                    onChange={e => setAddrForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                    className="w-full bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-white placeholder:text-white/30 focus:outline-none focus:border-red-500 text-xs"
                  />
                ))}
                <div className="flex gap-2">
                  <button type="submit" className="flex-1 bg-red-600 text-white text-xs font-bold py-2 rounded-xl hover:bg-red-700 transition-colors">
                    Save Address
                  </button>
                  <button type="button" onClick={() => setAddingAddress(false)} className="bg-white/10 text-white text-xs font-bold p-2 rounded-xl hover:bg-white/20 transition-colors">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </form>
            ) : (
              <button
                onClick={() => setAddingAddress(true)}
                className="w-full flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 border-dashed rounded-xl p-3 text-white/50 hover:text-white text-xs font-bold transition-colors"
              >
                <Plus className="w-4 h-4" /> Add New Address
              </button>
            )}
          </div>
        )}

        <button
          onClick={() => setShowSettings(s => !s)}
          className="w-full flex items-center justify-between bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl p-4 transition-colors"
        >
          <div className="flex items-center gap-3">
            <Settings className="w-5 h-5 text-white/50" />
            <span className="font-bold text-white text-sm">Account Settings</span>
          </div>
          <ChevronRight className={`w-4 h-4 text-white/30 transition-transform ${showSettings ? 'rotate-90' : ''}`} />
        </button>
        
        <button onClick={logout} className="w-full flex items-center justify-between bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl p-4 transition-colors">
          <div className="flex items-center gap-3">
            <LogOut className="w-5 h-5 text-red-400" />
            <span className="font-bold text-red-400 text-sm">Sign Out</span>
          </div>
        </button>

        {user?.isAdmin && (
          <button onClick={onAdminClick} className="w-full flex items-center justify-between bg-white/5 hover:bg-white/10 border border-red-500/30 rounded-xl p-4 transition-colors mt-4">
            <div className="flex items-center gap-3">
              <ShieldAlert className="w-5 h-5 text-yellow-400" />
              <span className="font-bold text-white text-sm">Admin Dashboard</span>
            </div>
            <ChevronRight className="w-4 h-4 text-white/30" />
          </button>
        )}

        {user?.isDeveloper && (
          <button onClick={() => document.dispatchEvent(new CustomEvent('open-developer-panel'))} className="w-full flex items-center justify-between bg-red-600/10 hover:bg-red-600/20 border border-red-500/50 rounded-xl p-4 transition-colors mt-4 shadow-[0_0_15px_rgba(220,38,38,0.15)]">
            <div className="flex items-center gap-3">
              <Settings className="w-5 h-5 text-red-400" />
              <span className="font-bold text-red-400 text-sm">Developer Panel</span>
            </div>
            <ChevronRight className="w-4 h-4 text-red-400/50" />
          </button>
        )}
      </div>
    </div>
  );
}
