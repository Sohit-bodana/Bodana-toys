import * as Icons from 'lucide-react';
import { motion } from 'framer-motion';
import React from 'react';
import { useAppContext } from '../context/AppContext';

interface CategoryListProps {
  onViewAll?: () => void;
  onCategoryClick?: (categoryId: string) => void;
}

export default function CategoryList({ onViewAll, onCategoryClick }: CategoryListProps) {
  const { categories } = useAppContext();
  return (
    <div className="mt-4">
      <div className="flex justify-between items-center px-6 mb-4">
        <h3 className="text-white font-bold text-sm uppercase tracking-wide">Categories</h3>
        <span
          onClick={onViewAll}
          className="text-red-500 text-xs font-semibold cursor-pointer hover:text-red-400 transition-colors"
        >
          View All
        </span>
      </div>
      <div className="flex overflow-x-auto hide-scrollbar px-6 gap-4 pb-2">
        {categories.map((category, index) => {
          const IconComponent = Icons[category.icon as keyof typeof Icons] as React.ElementType;
          
          return (
            <motion.button
              key={category.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => onCategoryClick?.(category.id)}
              className="flex flex-col items-center gap-2 flex-shrink-0"
            >
              <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center shadow-inner active:scale-95 transition-transform relative overflow-hidden group">
                <div className="absolute inset-0 bg-white/0 group-hover:bg-white/5 transition-colors" />
                {IconComponent && <IconComponent className="w-6 h-6 text-white/80 group-hover:text-red-400 transition-colors" strokeWidth={1.5} />}
              </div>
              <span className="text-[10px] text-white/60 font-medium text-center leading-tight">
                {category.name}
              </span>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
