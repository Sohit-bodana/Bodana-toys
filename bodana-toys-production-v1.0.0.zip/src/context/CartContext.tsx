import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product } from '../types';
import { useAuth } from './AuthContext';
import { firestoreWrapper } from '../lib/firestoreService';

export interface CartItem extends Product {
  quantity: number;
}

interface CartContextType {
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [cart, setCart] = useState<CartItem[]>([]);

  useEffect(() => {
    let active = true;

    const loadCart = async () => {
      if (user) {
        try {
          // Try to load from Firestore first
          const cloudCart = await firestoreWrapper.get('carts', user.id);
          if (!active) return;
          if (cloudCart && Array.isArray(cloudCart.items)) {
            setCart(cloudCart.items);
            localStorage.setItem(`bt_cart_${user.id}`, JSON.stringify(cloudCart.items));
          } else {
            // Fallback to local storage
            const storedCart = localStorage.getItem(`bt_cart_${user.id}`);
            const localCart = storedCart ? JSON.parse(storedCart) : [];
            if (active) setCart(Array.isArray(localCart) ? localCart : []);
            if (Array.isArray(localCart) && localCart.length > 0) {
              try {
                await firestoreWrapper.set('carts', user.id, { items: localCart });
              } catch (error) {
                console.warn('[Firebase] Could not sync the local cart.', error);
              }
            }
          }
        } catch (error) {
          // Preserve the local cart if Firestore is offline or rules reject a read.
          console.warn('[Firebase] Could not load the cloud cart.', error);
          const storedCart = localStorage.getItem(`bt_cart_${user.id}`);
          try {
            const localCart = storedCart ? JSON.parse(storedCart) : [];
            if (active) setCart(Array.isArray(localCart) ? localCart : []);
          } catch {
            if (active) setCart([]);
          }
        }
      } else {
        setCart([]);
      }
    };
    loadCart();
    return () => { active = false; };
  }, [user]);

  const saveCart = async (newCart: CartItem[]) => {
    setCart(newCart);
    if (user) {
      localStorage.setItem(`bt_cart_${user.id}`, JSON.stringify(newCart));
      try {
        await firestoreWrapper.set('carts', user.id, { items: newCart });
      } catch (error) {
        // Local state remains usable when Firestore is unavailable.
        console.warn('[Firebase] Could not save the cart.', error);
      }
    }
  };

  const addToCart = (product: Product, quantity = 1) => {
    const existing = cart.find(item => item.id === product.id);
    if (existing) {
      saveCart(cart.map(item => item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item));
    } else {
      saveCart([...cart, { ...product, quantity }]);
    }
  };

  const removeFromCart = (productId: string) => {
    saveCart(cart.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    saveCart(cart.map(item => item.id === productId ? { ...item, quantity } : item));
  };

  const clearCart = () => {
    saveCart([]);
  };

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, updateQuantity, clearCart }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
