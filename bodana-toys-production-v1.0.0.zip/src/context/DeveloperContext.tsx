import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { firestoreWrapper } from '../lib/firestoreService';

export interface DeveloperSettings {
  bannerTitle: string;
  bannerImage: string;
  offerText: string;
  primaryColor: string;
  sections: string[];
  cardLayout: 'default' | 'compact';
  announcement: string;
  festivalTheme: 'none' | 'diwali' | 'christmas';
  customCode: string;
}

export interface Backup {
  id: string;
  timestamp: string;
  settings: DeveloperSettings;
}

const defaultSettings: DeveloperSettings = {
  bannerTitle: "Experience the Joy of Premium Toys",
  bannerImage: "https://images.unsplash.com/photo-1558060370-d644479cb6f7?auto=format&fit=crop&q=80&w=1200",
  offerText: "FREE SHIPPING ON ORDERS OVER ₹999 • USE CODE BODANA10",
  primaryColor: "#dc2626",
  sections: ['trending', 'categories', 'banner', 'bestSellers', 'newArrivals', 'todayDeals'],
  cardLayout: 'default',
  announcement: "",
  festivalTheme: 'none',
  customCode: "",
};

interface DeveloperContextType {
  settings: DeveloperSettings;
  updateSettings: (newSettings: Partial<DeveloperSettings>) => void;
  backups: Backup[];
  restoreBackup: (backupId: string) => void;
  undo: () => void;
}

const DeveloperContext = createContext<DeveloperContextType | undefined>(undefined);

export function DeveloperProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [settings, setSettings] = useState<DeveloperSettings>(defaultSettings);
  const [backups, setBackups] = useState<Backup[]>([]);

  useEffect(() => {
    const loadSettings = async () => {
      let loadedSettings = null;
      let loadedBackups = null;

      // Only attempt to load from cloud if user is admin
      if (user?.isAdmin) {
        loadedSettings = await firestoreWrapper.get('admin', 'settings');
        loadedBackups = await firestoreWrapper.get('admin', 'backups');
      }

      if (loadedSettings) {
        setSettings(loadedSettings as DeveloperSettings);
        localStorage.setItem('bt_dev_settings', JSON.stringify(loadedSettings));
      } else {
        const stored = localStorage.getItem('bt_dev_settings');
        if (stored) setSettings(JSON.parse(stored));
      }

      if (loadedBackups && loadedBackups.items) {
        setBackups(loadedBackups.items);
        localStorage.setItem('bt_dev_backups', JSON.stringify(loadedBackups.items));
      } else {
        const storedBackups = localStorage.getItem('bt_dev_backups');
        if (storedBackups) setBackups(JSON.parse(storedBackups));
      }
    };
    
    loadSettings();
  }, [user]);

  const saveSettings = async (newSettings: DeveloperSettings, skipBackup = false) => {
    let newBackups = [...backups];
    if (!skipBackup) {
      const newBackup: Backup = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        settings: { ...settings }
      };
      newBackups = [newBackup, ...backups].slice(0, 50); // Keep last 50
      setBackups(newBackups);
      localStorage.setItem('bt_dev_backups', JSON.stringify(newBackups));
      
      if (user?.isAdmin) {
        await firestoreWrapper.set('admin', 'backups', { items: newBackups });
      }
    }
    
    setSettings(newSettings);
    localStorage.setItem('bt_dev_settings', JSON.stringify(newSettings));
    
    if (user?.isAdmin) {
      await firestoreWrapper.set('admin', 'settings', newSettings);
    }
  };

  const updateSettings = (updates: Partial<DeveloperSettings>) => {
    saveSettings({ ...settings, ...updates });
  };

  const restoreBackup = (backupId: string) => {
    const backup = backups.find(b => b.id === backupId);
    if (backup) {
      const preRestoreBackup: Backup = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        settings: { ...settings }
      };
      const newBackups = [preRestoreBackup, ...backups].slice(0, 50);
      setBackups(newBackups);
      localStorage.setItem('bt_dev_backups', JSON.stringify(newBackups));
      
      if (user?.isAdmin) {
        firestoreWrapper.set('admin', 'backups', { items: newBackups });
      }
      
      setSettings(backup.settings);
      localStorage.setItem('bt_dev_settings', JSON.stringify(backup.settings));
      if (user?.isAdmin) {
        firestoreWrapper.set('admin', 'settings', backup.settings);
      }
    }
  };

  const undo = () => {
    if (backups.length > 0) {
      const latestBackup = backups[0];
      const newBackups = backups.slice(1);
      setBackups(newBackups);
      localStorage.setItem('bt_dev_backups', JSON.stringify(newBackups));
      if (user?.isAdmin) {
        firestoreWrapper.set('admin', 'backups', { items: newBackups });
      }
      
      setSettings(latestBackup.settings);
      localStorage.setItem('bt_dev_settings', JSON.stringify(latestBackup.settings));
      if (user?.isAdmin) {
        firestoreWrapper.set('admin', 'settings', latestBackup.settings);
      }
    }
  };

  return (
    <DeveloperContext.Provider value={{ settings, updateSettings, backups, restoreBackup, undo }}>
      {children}
    </DeveloperContext.Provider>
  );
}

export function useDeveloper() {
  const context = useContext(DeveloperContext);
  if (context === undefined) {
    throw new Error('useDeveloper must be used within a DeveloperProvider');
  }
  return context;
}
