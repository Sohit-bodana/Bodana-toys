import React, { createContext, useContext, useState, useEffect } from 'react';
import { AdminSettings, Category, Coupon, Offer, Product, ProductReview } from '../types';
import { CartItem } from './CartContext';
import { allStaticProducts, categories as staticCategories } from '../data';
import { firestoreWrapper } from '../lib/firestoreService';
import { db, isFirebaseConfigured } from '../lib/firebaseConfig';
import { doc, runTransaction } from 'firebase/firestore';

export type AppTheme = 'dark' | 'light' | 'system' | 'black' | 'white' | 'gold';

interface AppContextType {
  spinRewards: string[];
  updateSpinRewards: (rewards: string[]) => Promise<void>;
  customCode: string;
  setCustomCode: (code: string) => void;
  products: Product[];
  categories: Category[];
  adminSettings: AdminSettings;
  reviews: ProductReview[];
  theme: AppTheme;
  setTheme: (theme: AppTheme) => void;
  getProductsBySection: (section: string) => Product[];
  getProductsByCategory: (categoryId: string) => Product[];
  addProduct: (product: Omit<Product, 'id'>) => Promise<void>;
  updateProduct: (id: string, product: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  addCategory: (category: Omit<Category, 'id'>) => Promise<void>;
  updateCategory: (id: string, updates: Partial<Category>) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;
  updateAdminSettings: (updates: Partial<AdminSettings>) => Promise<void>;
  submitReview: (review: Omit<ProductReview, 'id' | 'date' | 'status'>) => Promise<void>;
  updateReviewStatus: (id: string, status: ProductReview['status']) => Promise<void>;
  getProductStock: (productId: string) => number;
  reserveStock: (items: CartItem[]) => Promise<{ success: boolean; message?: string }>;
  releaseStock: (items: CartItem[]) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const DEFAULT_STOCK = 10;
const DEFAULT_LOW_STOCK_THRESHOLD = 3;

const DEFAULT_ADMIN_SETTINGS: AdminSettings = {
  coupons: [
    { id: 'coupon-bodana10', code: 'BODANA10', discountType: 'percent', value: 10, minOrder: 999, active: true },
  ],
  offers: [
    { id: 'offer-welcome', title: 'Welcome Offer', description: 'Save on your first toy order', discount: '10% OFF', active: true },
  ],
  deliveryCharges: { standard: 0, premium: 0, freeAbove: 999 },
  notifications: [],
};

function normalizeProduct(product: Product): Product {
  const stock = product.isOutOfStock ? 0 : Math.max(0, product.stock ?? DEFAULT_STOCK);
  return {
    ...product,
    stock,
    isOutOfStock: stock <= 0,
    lowStockThreshold: product.lowStockThreshold ?? DEFAULT_LOW_STOCK_THRESHOLD,
  };
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>(staticCategories);
  const [adminSettings, setAdminSettings] = useState<AdminSettings>(DEFAULT_ADMIN_SETTINGS);
  const [reviews, setReviews] = useState<ProductReview[]>([]);
  const [theme, setTheme] = useState<AppTheme>('dark');
  const [spinRewards, setSpinRewards] = useState<string[]>([
    '10% OFF', 'FREE SHIPPING', 'NO LUCK', '20% OFF', 'FREE GIFT', 'TRY AGAIN',
  ]);
  const [customCode, setCustomCode] = useState<string>('');

  useEffect(() => {
    const loadData = async () => {
      const cloudProducts = await firestoreWrapper.getCollection('products');
      if (cloudProducts && cloudProducts.length > 0) {
        const parsedProducts = (cloudProducts as Product[]).map(normalizeProduct);
        // In production, Firestore is the authoritative catalog. Never merge
        // demo/static products into a configured live catalog.
        setProducts(parsedProducts);
      } else if (isFirebaseConfigured) {
        setProducts([]);
      } else {
        const storedProducts = localStorage.getItem('bt_products');
        if (storedProducts) {
          try {
            const parsedProducts = (JSON.parse(storedProducts) as Product[]).map(normalizeProduct);
            const existingIds = new Set(parsedProducts.map(product => product.id));
            setProducts([
              ...parsedProducts,
              ...allStaticProducts.filter(product => !existingIds.has(product.id)).map(normalizeProduct),
            ]);
          } catch { setProducts(allStaticProducts.map(normalizeProduct)); }
        } else {
          setProducts(allStaticProducts.map(normalizeProduct));
        }
      }

      const storedTheme = localStorage.getItem('bt_theme') as AppTheme;
      if (storedTheme) setTheme(storedTheme);

      const storedCategories = localStorage.getItem('bt_categories');
      if (storedCategories) {
        try { setCategories(JSON.parse(storedCategories)); } catch { setCategories(staticCategories); }
      }

      const storedAdminSettings = localStorage.getItem('bt_admin_settings');
      if (storedAdminSettings) {
        try {
          const parsed = JSON.parse(storedAdminSettings) as Partial<AdminSettings>;
          setAdminSettings({
            ...DEFAULT_ADMIN_SETTINGS,
            ...parsed,
            deliveryCharges: { ...DEFAULT_ADMIN_SETTINGS.deliveryCharges, ...parsed.deliveryCharges },
          });
        } catch { setAdminSettings(DEFAULT_ADMIN_SETTINGS); }
      }

      const cloudAdminSettings = await firestoreWrapper.get('admin', 'commerce');
      if (cloudAdminSettings) {
        setAdminSettings(current => ({
          ...current,
          ...(cloudAdminSettings as Partial<AdminSettings>),
          deliveryCharges: {
            ...current.deliveryCharges,
            ...((cloudAdminSettings as Partial<AdminSettings>).deliveryCharges || {}),
          },
        }));
      }

      const cloudRewardSettings = await firestoreWrapper.get('admin', 'rewards');
      if (cloudRewardSettings && Array.isArray((cloudRewardSettings as any).spinRewards)) {
        setSpinRewards((cloudRewardSettings as any).spinRewards);
      } else {
        const storedSpinRewards = localStorage.getItem('bt_spin_rewards');
        if (storedSpinRewards) {
          try { setSpinRewards(JSON.parse(storedSpinRewards)); } catch { /* keep defaults */ }
        }
      }

      const storedReviews = localStorage.getItem('bt_reviews');
      if (storedReviews) {
        try { setReviews(JSON.parse(storedReviews)); } catch { setReviews([]); }
      }
    };
    loadData().catch(error => {
      // Keep the static catalog available even if a future startup read is
      // added outside the guarded Firestore wrapper.
      console.warn('[Firebase] App data bootstrap failed; using local defaults.', {
        code: (error as { code?: string })?.code,
        message: (error as { message?: string })?.message,
      });
      setProducts(previous => previous.length > 0
        ? previous
        : allStaticProducts.map(normalizeProduct));
    });
  }, []);

  const handleSetTheme = (newTheme: AppTheme) => {
    setTheme(newTheme);
    localStorage.setItem('bt_theme', newTheme);
  };

  const updateSpinRewards = async (rewards: string[]) => {
    setSpinRewards(rewards);
    localStorage.setItem('bt_spin_rewards', JSON.stringify(rewards));
    await firestoreWrapper.set('admin', 'rewards', { spinRewards: rewards });
  };

  /** Returns products belonging to a home-page section. */
  const getProductsBySection = (section: string) => {
    // Prefer explicit section field, fall back to index slices for products without it
    const bySection = products.filter(p => p.section === section);
    if (bySection.length > 0) return bySection;

    // Legacy index-based fallback (keeps backward compat with manually added products)
    if (section === 'trending')    return products.slice(0, 4);
    if (section === 'bestSellers') return products.slice(4, 8);
    if (section === 'newArrivals') return products.slice(8, 12);
    if (section === 'todayDeals')  return products.slice(12, 16);
    return products.slice(0, 4);
  };

  const getProductsByCategory = (categoryId: string) => {
    if (!categoryId || categoryId === 'all') return products;
    return products.filter(p => p.category === categoryId);
  };

  const persistCategories = async (next: Category[]) => {
    setCategories(next);
    localStorage.setItem('bt_categories', JSON.stringify(next));
    await firestoreWrapper.set('admin', 'categories', { items: next });
  };

  const addCategory = async (categoryData: Omit<Category, 'id'>) => {
    const category: Category = {
      ...categoryData,
      id: `category_${Date.now()}`,
    };
    await persistCategories([...categories, category]);
  };

  const updateCategory = async (id: string, updates: Partial<Category>) => {
    await persistCategories(categories.map(category => category.id === id ? { ...category, ...updates } : category));
  };

  const deleteCategory = async (id: string) => {
    if (id === 'all') return;
    await persistCategories(categories.filter(category => category.id !== id));
  };

  const updateAdminSettings = async (updates: Partial<AdminSettings>) => {
    const next: AdminSettings = {
      ...adminSettings,
      ...updates,
      deliveryCharges: { ...adminSettings.deliveryCharges, ...updates.deliveryCharges },
    };
    setAdminSettings(next);
    localStorage.setItem('bt_admin_settings', JSON.stringify(next));
    await firestoreWrapper.set('admin', 'commerce', next);
  };

  const submitReview = async (review: Omit<ProductReview, 'id' | 'date' | 'status'>) => {
    const nextReview: ProductReview = {
      ...review,
      id: `review_${Date.now()}`,
      date: new Date().toISOString(),
      status: 'pending',
    };
    const next = [nextReview, ...reviews];
    setReviews(next);
    localStorage.setItem('bt_reviews', JSON.stringify(next));
    await firestoreWrapper.add('reviews', nextReview, nextReview.id);
  };

  const updateReviewStatus = async (id: string, status: ProductReview['status']) => {
    const next = reviews.map(review => review.id === id ? { ...review, status } : review);
    setReviews(next);
    localStorage.setItem('bt_reviews', JSON.stringify(next));
    await firestoreWrapper.update('reviews', id, { status });
  };

  const getProductStock = (productId: string) => {
    const product = products.find(item => item.id === productId);
    if (!product || product.isOutOfStock) return 0;
    return Math.max(0, product.stock ?? DEFAULT_STOCK);
  };

  const reserveStock = async (items: CartItem[]) => {
    const latestProducts = products;
    for (const item of items) {
      const product = latestProducts.find(candidate => candidate.id === item.id);
      const available = product && !product.isOutOfStock
        ? Math.max(0, product.stock ?? DEFAULT_STOCK)
        : 0;
      if (available < item.quantity) {
        return {
          success: false,
          message: available === 0
            ? `${item.name} is out of stock. Please remove it from your cart.`
            : `Only ${available} unit${available === 1 ? '' : 's'} of ${item.name} ${available === 1 ? 'is' : 'are'} available.`,
        };
      }
    }

    const reductions = new Map(items.map(item => [item.id, item.quantity]));
    const nextProducts = latestProducts.map(product => {
      const quantity = reductions.get(product.id);
      if (!quantity) return product;
      const nextStock = Math.max(0, (product.stock ?? DEFAULT_STOCK) - quantity);
      return { ...product, stock: nextStock, isOutOfStock: nextStock === 0 };
    });

    try {
      if (isFirebaseConfigured && db) {
        await runTransaction(db, async transaction => {
          const snapshots = await Promise.all(items.map(item => transaction.get(doc(db, 'products', item.id))));
          snapshots.forEach((snapshot, index) => {
            if (!snapshot.exists()) throw new Error(`${items[index].name} is no longer available.`);
            const current = snapshot.data() as Product;
            const available = current.isOutOfStock ? 0 : Math.max(0, current.stock ?? DEFAULT_STOCK);
            const quantity = items[index].quantity;
            if (available < quantity) throw new Error(`Only ${available} unit${available === 1 ? '' : 's'} of ${items[index].name} ${available === 1 ? 'is' : 'are'} available.`);
            const nextStock = available - quantity;
            transaction.update(snapshot.ref, { stock: nextStock, isOutOfStock: nextStock === 0 });
          });
        });
      } else {
        await Promise.all(items.map(async item => {
          const product = latestProducts.find(candidate => candidate.id === item.id);
          if (!product) return;
          const nextStock = Math.max(0, (product.stock ?? DEFAULT_STOCK) - item.quantity);
          await firestoreWrapper.update('products', product.id, { stock: nextStock, isOutOfStock: nextStock === 0 });
        }));
      }
      setProducts(nextProducts);
      if (!isFirebaseConfigured) localStorage.setItem('bt_products', JSON.stringify(nextProducts));
      return { success: true };
    } catch (error) {
      return { success: false, message: error instanceof Error ? error.message : 'Inventory could not be updated. Please try again.' };
    }
  };

  const releaseStock = async (items: CartItem[]) => {
    if (!isFirebaseConfigured || !db) throw new Error('Firebase inventory is not configured.');

    await runTransaction(db, async transaction => {
      const snapshots = await Promise.all(items.map(item =>
        transaction.get(doc(db, 'products', item.id))
      ));
      snapshots.forEach((snapshot, index) => {
        if (!snapshot.exists()) return;
        const current = snapshot.data() as Product;
        const restored = Math.max(0, (current.stock ?? DEFAULT_STOCK) + items[index].quantity);
        transaction.update(snapshot.ref, { stock: restored, isOutOfStock: false });
      });
    });

    setProducts(previous => previous.map(product => {
      const item = items.find(candidate => candidate.id === product.id);
      if (!item) return product;
      const restored = Math.max(0, (product.stock ?? DEFAULT_STOCK) + item.quantity);
      return { ...product, stock: restored, isOutOfStock: false };
    }));
  };

  const addProduct = async (productData: Omit<Product, 'id'>) => {
    const newProduct: Product = normalizeProduct({
      ...productData,
      id: `p_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    });
    const docId = await firestoreWrapper.add('products', newProduct, newProduct.id);
    if (docId) newProduct.id = docId;
    setProducts(prev => {
      const next = [newProduct, ...prev];
      if (!isFirebaseConfigured) localStorage.setItem('bt_products', JSON.stringify(next));
      return next;
    });
  };

  const updateProduct = async (id: string, updates: Partial<Product>) => {
    await firestoreWrapper.update('products', id, updates);
    setProducts(prev => {
      const next = prev.map(p => p.id === id ? { ...p, ...updates } : p);
      if (!isFirebaseConfigured) localStorage.setItem('bt_products', JSON.stringify(next));
      return next;
    });
  };

  const deleteProduct = async (id: string) => {
    await firestoreWrapper.delete('products', id);
    setProducts(prev => {
      const next = prev.filter(p => p.id !== id);
      if (!isFirebaseConfigured) localStorage.setItem('bt_products', JSON.stringify(next));
      return next;
    });
  };

  return (
    <AppContext.Provider value={{
      products,
      categories,
      adminSettings,
      reviews,
      theme,
      setTheme: handleSetTheme,
      getProductsBySection,
      getProductsByCategory,
      addProduct,
      updateProduct,
      deleteProduct,
      addCategory,
      updateCategory,
      deleteCategory,
      updateAdminSettings,
      submitReview,
      updateReviewStatus,
      getProductStock,
      reserveStock,
      spinRewards,
       updateSpinRewards,
      customCode,
      setCustomCode,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}
