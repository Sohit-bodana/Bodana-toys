import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  auth,
  db,
  googleProvider,
  isFirebaseConfigured,
} from '../lib/firebaseConfig';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  updateProfile,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  ConfirmationResult,
  type User as FirebaseUser,
  browserLocalPersistence,
  browserSessionPersistence,
  setPersistence,
} from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp, runTransaction } from 'firebase/firestore';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface Address {
  id: string;
  title: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
}

export interface User {
  id: string;
  email?: string;
  phone?: string;
  displayName?: string;
  isAdmin?: boolean;
  isDeveloper?: boolean;
  founderBadge?: number;
  /** Mirrors Firebase Auth emailVerified. undefined for mock/dev users. */
  emailVerified?: boolean;
  addresses?: Address[];
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  /** True when Firebase credentials are present in env vars */
  isFirebaseEnabled: boolean;
  loginWithEmail: (email: string, password: string, rememberMe?: boolean) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  loginWithPhone: (phone: string) => Promise<void>;
  sendPhoneOtp: (phone: string, displayName?: string) => Promise<void>;
  verifyPhoneOtp: (code: string) => Promise<void>;
  signupWithEmail: (email: string, password: string, displayName?: string) => Promise<void>;
  signupWithPhone: (phone: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  hasCompletedOnboarding: boolean;
  completeOnboarding: () => void;
  addAddress: (address: Omit<Address, 'id'>) => Promise<void>;
  removeAddress: (addressId: string) => Promise<void>;
  claimFounderBadge: () => Promise<number | null>;
  unlockDeveloper: (password: string) => Promise<void>;
}

// ─── Error mapping ─────────────────────────────────────────────────────────────

export function mapAuthError(code: string): string {
  switch (code) {
    case 'auth/user-not-found':
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'Incorrect email or password.';
    case 'auth/email-already-in-use':
      return 'An account with this email already exists. Try logging in.';
    case 'auth/weak-password':
      return 'Password must be at least 6 characters.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    case 'auth/invalid-phone-number':
      return 'Enter a valid 10-digit Indian mobile number, such as 9876543210.';
    case 'auth/too-many-requests':
      return 'Too many failed attempts. Try again later or reset your password.';
    case 'auth/network-request-failed':
      return 'Network error. Check your connection and try again.';
    case 'auth/popup-closed-by-user':
    case 'auth/cancelled-popup-request':
      return 'Sign-in was cancelled.';
    case 'auth/requires-recent-login':
      return 'Please sign in again to continue.';
    case 'auth/operation-not-allowed':
      return 'This sign-in method is not enabled. Contact support.';
    case 'auth/user-disabled':
      return 'This account has been disabled. Contact support.';
    case 'auth/missing-email':
      return 'Please enter your email address.';
    case 'auth/missing-password':
      return 'Please enter your password.';
    case 'auth/internal-error':
      return 'Firebase could not complete the request. Please try again.';
    case 'auth/invalid-api-key':
      return 'Firebase authentication is not configured correctly.';
    case 'auth/app-not-authorized':
    case 'auth/unauthorized-domain':
      return 'This app domain is not authorized for Firebase authentication.';
    default:
      return 'Something went wrong. Please try again.';
  }
}

/**
 * Normalizes the Indian phone numbers accepted by the customer form into the
 * E.164 format required by Firebase Phone Auth.
 *
 * Numbers that already start with "+" are intentionally left unchanged so
 * international numbers are not rewritten by the India-specific shortcut.
 */
export function normalizeIndianPhoneNumber(value: string): string {
  const compact = value.replace(/[\s-]/g, '');

  if (compact.startsWith('+')) {
    return compact;
  }

  const withoutLeadingZero = compact.replace(/^0+/, '');
  if (!/^\d{10}$/.test(withoutLeadingZero)) {
    throw Object.assign(
      new Error('Enter a valid 10-digit Indian mobile number, such as 9876543210.'),
      { code: 'auth/invalid-phone-number' },
    );
  }

  return `+91${withoutLeadingZero}`;
}

// ─── Context ───────────────────────────────────────────────────────────────────

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasCompletedOnboarding, setHasCompletedOnboarding] = useState(false);
  const phoneConfirmation = React.useRef<ConfirmationResult | null>(null);
  const phoneVerifier = React.useRef<RecaptchaVerifier | null>(null);
  const pendingPhoneDisplayName = React.useRef('');

  // ─── Bootstrap ──────────────────────────────────────────────────────────────
  useEffect(() => {
    let active = true;
    const startupTimeout = window.setTimeout(() => {
      if (active) {
        console.warn('[Firebase] Auth startup timed out; continuing with the app available.');
        setIsLoading(false);
      }
    }, 8000);

    const onboarding = localStorage.getItem('bt_onboarding');
    if (onboarding) setHasCompletedOnboarding(true);

    if (isFirebaseConfigured && auth) {
      // Make persistence explicit so auth survives a full browser refresh.
      void setPersistence(auth, browserLocalPersistence).catch(error => {
        console.warn('[Firebase Auth] Could not enable browser persistence.', {
          code: (error as { code?: string })?.code,
          message: (error as { message?: string })?.message,
        });
      });

      // Firebase path: real auth state listener
      const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
        if (!active) return;
        if (fbUser) {
          // Build base user object from the Firebase Auth token
          let userData: User = {
            id: fbUser.uid,
            email: fbUser.email || undefined,
            displayName: fbUser.displayName || undefined,
            emailVerified: fbUser.emailVerified,
            isAdmin: false,
            isDeveloper: false,
            addresses: [],
          };

          // Do not make the app shell wait on a profile read. Auth is already
          // established, so the UI can render while Firestore data hydrates.
          setUser(userData);
          setIsLoading(false);

          // Augment with Firestore fields (isAdmin, addresses, displayName override).
          // Admin access is determined only by the authenticated user's Firestore profile.

          if (db) {
            try {
              const profileRead = getDoc(doc(db, 'users', fbUser.uid)).catch(error => {
                console.error(error);
                console.error((error as { code?: string })?.code);
                console.error((error as { message?: string })?.message);
                console.warn('[Firebase Firestore] Could not read the user profile document.', {
                  code: (error as { code?: string })?.code,
                  message: (error as { message?: string })?.message,
                });
                return null;
              });
              const snap = await Promise.race([
                profileRead,
                new Promise<null>(resolve => window.setTimeout(() => resolve(null), 5000)),
              ]);
              if (!active || !snap) return;
              if (snap.exists()) {
                const data = snap.data();
                userData = {
                  ...userData,
                  // Never read emailVerified from Firestore — always use Auth token
                  // isAdmin is intentionally read from the protected Firestore user
                  // profile so the first admin can be bootstrapped safely from the
                  // Firebase console without exposing an admin secret in the client.
                  isAdmin: data.isAdmin === true,
                  displayName: data.displayName || userData.displayName,
                  addresses: data.addresses || [],
                  founderBadge: typeof data.founderBadge === 'number' ? data.founderBadge : undefined,
                };
              } else {
                // First sign-in (e.g. Google OAuth): create the user document
                  await setDoc(doc(db, 'users', fbUser.uid), {
                    email: fbUser.email,
                    displayName: fbUser.displayName || null,
                    isAdmin: false,
                    createdAt: serverTimestamp(),
                  }, { merge: true });
              }
              } catch (error) {
                console.error(error);
                console.error((error as { code?: string })?.code);
                console.error((error as { message?: string })?.message);
              // Firestore unavailable (offline or rules error) — use basic user data
            }
          }

          if (active) setUser(userData);
        } else {
          setUser(null);
          setIsLoading(false);
        }
      });

      return () => {
        active = false;
        window.clearTimeout(startupTimeout);
        unsubscribe();
      };
    } else {
      // Never impersonate a user when Firebase is unavailable.
      setUser(null);
      setIsLoading(false);
      window.clearTimeout(startupTimeout);
      return () => { active = false; };
    }
  }, []);

  // ─── Auth methods ────────────────────────────────────────────────────────────

  const loginWithEmail = async (email: string, password: string, _rememberMe = true) => {
    if (isFirebaseConfigured && auth) {
      await setPersistence(auth, _rememberMe ? browserLocalPersistence : browserSessionPersistence);
      await signInWithEmailAndPassword(auth, email, password);
    } else {
      throw new Error('Firebase Authentication is not configured.');
    }
  };

  const loginWithGoogle = async () => {
    if (isFirebaseConfigured && auth) {
      await signInWithPopup(auth, googleProvider);
    }
    else throw new Error('Firebase Authentication is not configured.');
  };

  const getPhoneVerifier = () => {
    if (!auth) return null;
    if (phoneVerifier.current) return phoneVerifier.current;
    phoneVerifier.current = new RecaptchaVerifier(auth, 'recaptcha-container', {
      size: 'invisible',
      callback: () => undefined,
      'expired-callback': () => {
        phoneVerifier.current?.clear();
        phoneVerifier.current = null;
      },
    });
    return phoneVerifier.current;
  };

  const sendPhoneOtp = async (phone: string, displayName?: string) => {
    const normalizedPhone = normalizeIndianPhoneNumber(phone);

    if (!isFirebaseConfigured || !auth) {
      throw new Error('Firebase Phone Authentication is not configured.');
    }

    const verifier = getPhoneVerifier();
    if (!verifier) throw new Error('Firebase Phone Auth is not configured.');
    pendingPhoneDisplayName.current = displayName?.trim() || '';
    phoneConfirmation.current = await signInWithPhoneNumber(auth, normalizedPhone, verifier);
  };

  const verifyPhoneOtp = async (code: string) => {
    if (!phoneConfirmation.current) {
      throw Object.assign(new Error('Request a phone verification code first.'), {
        code: 'auth/missing-verification-code',
      });
    }

    const result = await phoneConfirmation.current.confirm(code.trim());
    phoneConfirmation.current = null;
    const displayName = pendingPhoneDisplayName.current;
    pendingPhoneDisplayName.current = '';

    if (displayName) {
      try {
        await updateProfile(result.user, { displayName });
      } catch (error) {
        console.warn('[Firebase Auth] Phone account created, but profile name could not be saved.', {
          code: (error as { code?: string })?.code,
          message: (error as { message?: string })?.message,
        });
      }
    }
  };

  const loginWithPhone = async (phone: string) => {
    await sendPhoneOtp(phone);
  };

  const signupWithEmail = async (email: string, password: string, displayName?: string) => {
    if (isFirebaseConfigured && auth) {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      const trimmedDisplayName = displayName?.trim() || '';

      // Auth account creation is the source of truth for signup. Profile
      // enrichment must not turn a successful registration into a generic
      // failure when Firebase is temporarily offline.
      if (trimmedDisplayName) {
        try {
          await updateProfile(cred.user, { displayName: trimmedDisplayName });
        } catch (error) {
          console.error(error);
          console.error((error as { code?: string })?.code);
          console.error((error as { message?: string })?.message);
          console.warn('[Firebase Auth] Account created, but profile name could not be saved.', {
            code: (error as { code?: string })?.code,
            message: (error as { message?: string })?.message,
          });
        }
      }

      // Make the newly-created account available immediately even if the auth
      // state listener is delayed by a slow/offline Firebase client.
      setUser({
        id: cred.user.uid,
        email: cred.user.email || undefined,
        displayName: trimmedDisplayName || cred.user.displayName || undefined,
        emailVerified: cred.user.emailVerified,
        isAdmin: false,
        addresses: [],
      });

      // Write user doc to Firestore (isAdmin defaults to false — must be set manually)
      if (db) {
        try {
          await setDoc(doc(db, 'users', cred.user.uid), {
            email: cred.user.email,
            displayName: trimmedDisplayName || null,
            isAdmin: false,
            createdAt: serverTimestamp(),
          }, { merge: true });
        } catch (error) {
          console.error(error);
          console.error((error as { code?: string })?.code);
          console.error((error as { message?: string })?.message);
          console.warn('[Firebase Firestore] Could not create the user profile document.', {
            code: (error as { code?: string })?.code,
            message: (error as { message?: string })?.message,
          });
        }
      }
    } else {
      throw new Error('Firebase Authentication is not configured.');
    }
  };

  const signupWithPhone = async (_phone: string) => {
    await sendPhoneOtp(_phone);
  };

  const unlockDeveloper = async (password: string) => {
    if (!auth?.currentUser) {
      throw new Error('Please sign in before unlocking developer access.');
    }
    const idToken = await auth.currentUser.getIdToken();
    const response = await fetch('/api/developer/unlock', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${idToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ password }),
    });
    const result = await response.json().catch(() => null) as { message?: string } | null;
    if (!response.ok) {
      throw new Error(result?.message || 'Developer access denied.');
    }
  };

  const resetPassword = async (email: string) => {
    if (isFirebaseConfigured && auth) {
      await sendPasswordResetEmail(auth, email);
    } else {
      throw new Error('Firebase Authentication is not configured.');
    }
  };

  const logout = async () => {
    if (isFirebaseConfigured && auth) {
      phoneConfirmation.current = null;
      phoneVerifier.current?.clear();
      phoneVerifier.current = null;
      await signOut(auth);
      return;
    }
    setUser(null);
  };

  // ─── Onboarding ─────────────────────────────────────────────────────────────

  const completeOnboarding = () => {
    setHasCompletedOnboarding(true);
    localStorage.setItem('bt_onboarding', 'true');
  };

  // ─── Address management ──────────────────────────────────────────────────────

  const addAddress = async (address: Omit<Address, 'id'>) => {
    if (!user) return;
    const newAddr: Address = { ...address, id: Math.random().toString(36).substring(7) };
    const updated = [...(user.addresses || []), newAddr];
    setUser(prev => prev ? { ...prev, addresses: updated } : null);
    if (isFirebaseConfigured && db) {
      await setDoc(doc(db, 'users', user.id), { addresses: updated }, { merge: true });
    }
  };

  const removeAddress = async (addressId: string) => {
    if (!user) return;
    const updated = (user.addresses || []).filter(a => a.id !== addressId);
    setUser(prev => prev ? { ...prev, addresses: updated } : null);
    if (isFirebaseConfigured && db) {
      await setDoc(doc(db, 'users', user.id), { addresses: updated }, { merge: true });
    }
  };

  const claimFounderBadge = async (): Promise<number | null> => {
    if (!user) return null;
    if (user.founderBadge) return user.founderBadge;

    if (isFirebaseConfigured && db) {
      const firestore = db;
      const badgeNumber = await runTransaction(firestore, async transaction => {
        const registryRef = doc(firestore, 'settings', 'founderCustomers');
        const userRef = doc(firestore, 'users', user.id);
        const registrySnapshot = await transaction.get(registryRef);
        const registry = registrySnapshot.exists() ? registrySnapshot.data() : {};
        const assigned = (registry.assigned || {}) as Record<string, number>;
        const existing = assigned[user.id];
        if (typeof existing === 'number') return existing;

        const usedNumbers = new Set(
          Object.values(assigned).filter(value => Number.isInteger(value) && value >= 1 && value <= 10),
        );
        const nextNumber = Array.from({ length: 10 }, (_, index) => index + 1)
          .find(number => !usedNumbers.has(number));
        if (!nextNumber) return null;

        transaction.set(
          registryRef,
          { assigned: { ...assigned, [user.id]: nextNumber }, updatedAt: serverTimestamp() },
          { merge: true },
        );
        transaction.set(userRef, { founderBadge: nextNumber }, { merge: true });
        return nextNumber;
      });

      if (badgeNumber) {
        setUser(prev => prev ? { ...prev, founderBadge: badgeNumber } : null);
      }
      return badgeNumber;
    }

    const ownBadgeKey = `bt_founder_badge_${user.id}`;
    const storedBadge = Number(localStorage.getItem(ownBadgeKey));
    if (Number.isInteger(storedBadge) && storedBadge >= 1 && storedBadge <= 10) {
      setUser(prev => prev ? { ...prev, founderBadge: storedBadge } : null);
      return storedBadge;
    }

    let assigned: Record<string, number> = {};
    try {
      assigned = JSON.parse(localStorage.getItem('bt_founder_customers') || '{}');
    } catch (error) {
      console.error(error);
      console.error((error as { code?: string })?.code);
      console.error((error as { message?: string })?.message);
      assigned = {};
    }
    const usedNumbers = new Set(Object.values(assigned));
    const nextNumber = Array.from({ length: 10 }, (_, index) => index + 1)
      .find(number => !usedNumbers.has(number));
    if (!nextNumber) return null;

    assigned[user.id] = nextNumber;
    localStorage.setItem('bt_founder_customers', JSON.stringify(assigned));
    localStorage.setItem(ownBadgeKey, String(nextNumber));
    const updatedUser = { ...user, founderBadge: nextNumber };
    setUser(updatedUser);
    localStorage.setItem('bt_dev_user', JSON.stringify(updatedUser));
    return nextNumber;
  };

  // ─── Provider ───────────────────────────────────────────────────────────────

  return (
    <AuthContext.Provider value={{
      user,
      isLoading,
      isFirebaseEnabled: isFirebaseConfigured,
      loginWithEmail,
      loginWithGoogle,
      loginWithPhone,
      sendPhoneOtp,
      verifyPhoneOtp,
      signupWithEmail,
      signupWithPhone,
      resetPassword,
      logout,
      hasCompletedOnboarding,
      completeOnboarding,
      addAddress,
      removeAddress,
      claimFounderBadge,
      unlockDeveloper,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
