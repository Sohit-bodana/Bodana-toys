import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product } from '../types';
import { useAuth } from './AuthContext';
import { firestoreWrapper } from '../lib/firestoreService';

interface WishlistContextType {
  wishlist: Product[];
  addToWishlist: (product: Product) => void;
  removeFromWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

export function WishlistProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [wishlist, setWishlist] = useState<Product[]>([]);

  useEffect(() => {
    let active = true;

    const loadWishlist = async () => {
      if (user) {
        try {
          const cloudData = await firestoreWrapper.get('wishlists', user.id);
          if (!active) return;
          if (cloudData && Array.isArray(cloudData.items)) {
            setWishlist(cloudData.items);
            localStorage.setItem(`bt_wishlist_${user.id}`, JSON.stringify(cloudData.items));
          } else {
            const stored = localStorage.getItem(`bt_wishlist_${user.id}`);
            const localWishlist = stored ? JSON.parse(stored) : [];
            if (active) setWishlist(Array.isArray(localWishlist) ? localWishlist : []);
            if (Array.isArray(localWishlist) && localWishlist.length > 0) {
              try {
                await firestoreWrapper.set('wishlists', user.id, { items: localWishlist });
              } catch (error) {
                console.warn('[Firebase] Could not sync the local wishlist.', error);
              }
            }
          }
        } catch (error) {
          console.warn('[Firebase] Could not load the cloud wishlist.', error);
          const stored = localStorage.getItem(`bt_wishlist_${user.id}`);
          try {
            const localWishlist = stored ? JSON.parse(stored) : [];
            if (active) setWishlist(Array.isArray(localWishlist) ? localWishlist : []);
          } catch {
            if (active) setWishlist([]);
          }
        }
      } else {
        setWishlist([]);
      }
    };
    loadWishlist();
    return () => { active = false; };
  }, [user]);

  const saveWishlist = async (newWishlist: Product[]) => {
    setWishlist(newWishlist);
    if (user) {
      localStorage.setItem(`bt_wishlist_${user.id}`, JSON.stringify(newWishlist));
      try {
        await firestoreWrapper.set('wishlists', user.id, { items: newWishlist });
      } catch (error) {
        console.warn('[Firebase] Could not save the wishlist.', error);
      }
    }
  };

  const addToWishlist = (product: Product) => {
    if (!wishlist.find(item => item.id === product.id)) {
      saveWishlist([...wishlist, product]);
    }
  };

  const removeFromWishlist = (productId: string) => {
    saveWishlist(wishlist.filter(item => item.id !== productId));
  };

  const isInWishlist = (productId: string) => {
    return !!wishlist.find(item => item.id === productId);
  };

  return (
    <WishlistContext.Provider value={{ wishlist, addToWishlist, removeFromWishlist, isInWishlist }}>
      {children}
    </WishlistContext.Provider>
  );
}

export function useWishlist() {
  const context = useContext(WishlistContext);
  if (context === undefined) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
}
