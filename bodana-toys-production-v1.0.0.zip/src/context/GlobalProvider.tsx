import React from 'react';
import { AppProvider } from './AppContext';
import { CartProvider } from './CartContext';
import { WishlistProvider } from './WishlistContext';
import { OrderProvider } from './OrderContext';
import { DeveloperProvider } from './DeveloperContext';
import { RewardsProvider } from './RewardsContext';

export function GlobalProvider({ children }: { children: React.ReactNode }) {
  return (
    <AppProvider>
      <RewardsProvider>
        <DeveloperProvider>
          <CartProvider>
            <WishlistProvider>
              <OrderProvider>
                {children}
              </OrderProvider>
            </WishlistProvider>
          </CartProvider>
        </DeveloperProvider>
      </RewardsProvider>
    </AppProvider>
  );
}
