import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useAuth } from './AuthContext';
import { SavedReward, RewardType } from '../types';
import { firestoreWrapper } from '../lib/firestoreService';

interface RewardInput {
  type: RewardType;
  title: string;
  description?: string;
  code?: string;
  discountType?: 'percent' | 'flat';
  value?: number;
  minOrder?: number;
  balance?: number;
  sourceId?: string;
  expiresAt?: string;
}

interface RewardsContextType {
  rewards: SavedReward[];
  availableRewards: SavedReward[];
  saveReward: (reward: RewardInput) => Promise<SavedReward | null>;
  saveSpinReward: (title: string) => Promise<SavedReward | null>;
  saveCouponReward: (coupon: {
    id: string;
    code: string;
    discountType: 'percent' | 'flat';
    value: number;
    minOrder: number;
    expiryDate?: string;
  }) => Promise<SavedReward | null>;
  saveOfferReward: (offer: {
    id: string;
    title: string;
    description: string;
    discount: string;
    expiryDate?: string;
  }) => Promise<SavedReward | null>;
  saveGiftCardReward: (code: string, balance: number) => Promise<SavedReward | null>;
  markRewardUsed: (rewardId: string) => Promise<void>;
}

const RewardsContext = createContext<RewardsContextType | undefined>(undefined);

function rewardStorageKey(userId: string) {
  return `bt_rewards_${userId}`;
}

function isExpired(expiresAt?: string) {
  if (!expiresAt) return false;
  return new Date(`${expiresAt}T23:59:59`).getTime() < Date.now();
}

function parseSpinReward(title: string): Pick<RewardInput, 'discountType' | 'value'> {
  const percent = title.match(/^(\d+)%\s*OFF$/i);
  if (percent) return { discountType: 'percent', value: Number(percent[1]) };
  return {};
}

function parseOfferDiscount(discount: string): Pick<RewardInput, 'discountType' | 'value'> {
  const percent = discount.match(/(\d+)%/);
  if (percent) return { discountType: 'percent', value: Number(percent[1]) };
  const amount = discount.match(/₹\s*([\d,]+)/);
  if (amount) return { discountType: 'flat', value: Number(amount[1].replace(/,/g, '')) };
  return {};
}

export function RewardsProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [rewards, setRewards] = useState<SavedReward[]>([]);

  useEffect(() => {
    let cancelled = false;
    const loadRewards = async () => {
      if (!user) {
        setRewards([]);
        return;
      }

      const cloudRewards = await firestoreWrapper.getCollection('rewards', user.id);
      if (cancelled) return;
      if (cloudRewards && cloudRewards.length > 0) {
        const parsed = cloudRewards as SavedReward[];
        setRewards(parsed);
        localStorage.setItem(rewardStorageKey(user.id), JSON.stringify(parsed));
        return;
      }

      const stored = localStorage.getItem(rewardStorageKey(user.id));
      if (stored) {
        try {
          setRewards(JSON.parse(stored) as SavedReward[]);
        } catch {
          setRewards([]);
        }
      } else {
        setRewards([]);
      }
    };
    loadRewards();
    return () => { cancelled = true; };
  }, [user?.id]);

  const persistRewards = async (next: SavedReward[]) => {
    setRewards(next);
    if (!user) return;
    localStorage.setItem(rewardStorageKey(user.id), JSON.stringify(next));
  };

  const saveReward = async (input: RewardInput) => {
    if (!user) return null;
    const duplicate = rewards.find(reward =>
      !reward.usedAt &&
      ((input.sourceId && reward.sourceId === input.sourceId) ||
        (input.code && reward.code === input.code)),
    );
    if (duplicate) return duplicate;

    const reward: SavedReward = {
      ...input,
      id: `reward_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      userId: user.id,
      savedAt: new Date().toISOString(),
    };
    await firestoreWrapper.add('rewards', reward, reward.id);
    await persistRewards([reward, ...rewards]);
    return reward;
  };

  const saveSpinReward = (title: string) => {
    const normalized = title.trim().toUpperCase();
    if (!normalized || normalized === 'NO LUCK' || normalized === 'TRY AGAIN') return Promise.resolve(null);
    return saveReward({
      type: 'spin',
      title,
      description: 'Reward unlocked from Lucky Spin',
      ...parseSpinReward(title),
    });
  };

  const saveCouponReward = (coupon: {
    id: string;
    code: string;
    discountType: 'percent' | 'flat';
    value: number;
    minOrder: number;
    expiryDate?: string;
  }) => saveReward({
    type: 'coupon',
    title: coupon.code,
    description: coupon.minOrder > 0 ? `Valid on orders above ₹${coupon.minOrder.toLocaleString()}` : 'Available on your next order',
    code: coupon.code,
    discountType: coupon.discountType,
    value: coupon.value,
    minOrder: coupon.minOrder,
    sourceId: coupon.id,
    expiresAt: coupon.expiryDate,
  });

  const saveGiftCardReward = (code: string, balance: number) => saveReward({
    type: 'giftCard',
    title: 'Gift Card',
    description: 'Saved gift card balance',
    code: code.trim().toUpperCase(),
    balance,
    sourceId: `gift-card-${code.trim().toUpperCase()}`,
  });

  const saveOfferReward = (offer: {
    id: string;
    title: string;
    description: string;
    discount: string;
    expiryDate?: string;
  }) => saveReward({
    type: 'offer',
    title: offer.title,
    description: `${offer.description} · ${offer.discount}`,
    ...parseOfferDiscount(offer.discount),
    sourceId: offer.id,
    expiresAt: offer.expiryDate,
  });

  const markRewardUsed = async (rewardId: string) => {
    const usedAt = new Date().toISOString();
    const next = rewards.map(reward => reward.id === rewardId ? { ...reward, usedAt } : reward);
    await firestoreWrapper.update('rewards', rewardId, { usedAt });
    await persistRewards(next);
  };

  const availableRewards = useMemo(
    () => rewards.filter(reward => !reward.usedAt && !isExpired(reward.expiresAt)),
    [rewards],
  );

  return (
    <RewardsContext.Provider value={{
      rewards,
      availableRewards,
      saveReward,
      saveSpinReward,
      saveCouponReward,
      saveOfferReward,
      saveGiftCardReward,
      markRewardUsed,
    }}>
      {children}
    </RewardsContext.Provider>
  );
}

export function useRewards() {
  const context = useContext(RewardsContext);
  if (!context) throw new Error('useRewards must be used within a RewardsProvider');
  return context;
}