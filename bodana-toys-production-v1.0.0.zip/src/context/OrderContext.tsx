import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { CartItem } from './CartContext';
import { CheckoutAddress } from '../types';
import { firestoreWrapper } from '../lib/firestoreService';
import { isFirebaseConfigured } from '../lib/firebaseConfig';

export interface Order {
  id: string;
  userId?: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  date: string;
  paymentMethod?: 'online' | 'cod' | 'mock';
  paymentId?: string;
  razorpayOrderId?: string;
  paymentStatus?: 'pending' | 'paid';
  paidAt?: string;
  address?: CheckoutAddress;
  idempotencyKey?: string;
  cancellationRequestedAt?: string;
  returnRequestedAt?: string;
  invoiceGeneratedAt?: string;
}

interface OrderContextType {
  orders: Order[];
  createOrder: (
    items: CartItem[],
    total: number,
    paymentMethod?: Order['paymentMethod'],
    address?: CheckoutAddress,
    paymentId?: string,
    options?: { idempotencyKey?: string; orderId?: string; paymentStatus?: Order['paymentStatus'] },
  ) => Promise<Order | null>;
  updateOrderStatus: (orderId: string, status: Order['status']) => Promise<void>;
  requestCancellation: (orderId: string) => Promise<void>;
  requestReturn: (orderId: string) => Promise<void>;
  markInvoiceGenerated: (orderId: string) => Promise<void>;
  markOrderPaid: (orderId: string, paymentId: string) => Promise<void>;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export function OrderProvider({ children }: { children: React.ReactNode }) {
  const { user, claimFounderBadge } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    const loadOrders = async () => {
      if (user?.isAdmin) {
        const cloudOrders = await firestoreWrapper.getCollection('orders');
        if (cloudOrders && cloudOrders.length > 0) {
          setOrders(cloudOrders as Order[]);
          if (!isFirebaseConfigured) localStorage.setItem('bt_all_orders', JSON.stringify(cloudOrders));
        } else if (!isFirebaseConfigured) {
          const allOrders = localStorage.getItem('bt_all_orders');
          if (allOrders) setOrders(JSON.parse(allOrders));
        }
      } else if (user) {
        const cloudOrders = await firestoreWrapper.getCollection('orders', user.id);
        if (cloudOrders && cloudOrders.length > 0) {
          setOrders(cloudOrders as Order[]);
          if (!isFirebaseConfigured) localStorage.setItem(`bt_orders_${user.id}`, JSON.stringify(cloudOrders));
        } else if (!isFirebaseConfigured) {
          const stored = localStorage.getItem(`bt_orders_${user.id}`);
          if (stored) setOrders(JSON.parse(stored));
        }
      } else {
        setOrders([]);
      }
    };
    loadOrders();
  }, [user]);

  const createOrder = async (
    items: CartItem[],
    total: number,
    paymentMethod: Order['paymentMethod'] = 'mock',
    address?: CheckoutAddress,
    paymentId?: string,
    options?: { idempotencyKey?: string; orderId?: string; paymentStatus?: Order['paymentStatus'] },
  ) => {
    if (!user) return null;
    if (!isFirebaseConfigured) {
      throw new Error('Firebase is not configured. Orders cannot be created in demo mode.');
    }

    const idempotencyKey = options?.idempotencyKey;
    const storageKey = user.isAdmin ? 'bt_all_orders' : `bt_orders_${user.id}`;
    const storedOrders = localStorage.getItem(storageKey);
    let persistedOrders: Order[] = [];
    if (storedOrders) {
      try { persistedOrders = JSON.parse(storedOrders) as Order[]; } catch { persistedOrders = []; }
    }
    const duplicate = [...orders, ...persistedOrders].find(order =>
      idempotencyKey && order.userId === user.id && order.idempotencyKey === idempotencyKey,
    );
    if (duplicate) return duplicate;
    const isFirstOrder = orders.length === 0 && persistedOrders.length === 0;

    const newOrder: Order = {
      id: options?.orderId || `BT${Date.now()}`,
      userId: user.id,
      items,
      total,
      status: 'processing',
      date: new Date().toISOString(),
      paymentMethod,
      paymentId,
      paymentStatus: options?.paymentStatus,
      address,
      idempotencyKey,
    };

    // Attempt Firestore save
    await firestoreWrapper.add('orders', newOrder, newOrder.id);

    const newOrders = [newOrder, ...orders];
    setOrders(newOrders);

    // Firestore is authoritative in production. Keep local storage only for
    // explicit local/dev mode.
    if (!isFirebaseConfigured) {
      if (user.isAdmin) localStorage.setItem('bt_all_orders', JSON.stringify(newOrders));
      else localStorage.setItem(`bt_orders_${user.id}`, JSON.stringify(newOrders));
    }

    if (isFirstOrder && !user.isAdmin) {
      try {
        await claimFounderBadge();
      } catch (error) {
        console.warn('[Founder Customers] Badge assignment will retry on the next eligible order.', error);
      }
    }
    return newOrder;
  };

  const updateOrderStatus = async (orderId: string, status: Order['status']) => {
    await firestoreWrapper.update('orders', orderId, { status });
    const newOrders = orders.map(o => o.id === orderId ? { ...o, status } : o);
    setOrders(newOrders);
    if (user?.isAdmin) {
      localStorage.setItem('bt_all_orders', JSON.stringify(newOrders));
    } else if (user) {
      localStorage.setItem(`bt_orders_${user.id}`, JSON.stringify(newOrders));
    }
  };

  const updateOrderField = async (
    orderId: string,
    fields: Partial<Pick<Order, 'cancellationRequestedAt' | 'returnRequestedAt' | 'invoiceGeneratedAt'>>,
  ) => {
    await firestoreWrapper.update('orders', orderId, fields);
    const newOrders = orders.map(order => order.id === orderId ? { ...order, ...fields } : order);
    setOrders(newOrders);
    if (user?.isAdmin) {
      localStorage.setItem('bt_all_orders', JSON.stringify(newOrders));
    } else if (user) {
      localStorage.setItem(`bt_orders_${user.id}`, JSON.stringify(newOrders));
    }
  };

  const requestCancellation = async (orderId: string) => {
    const order = orders.find(item => item.id === orderId);
    if (!order || !['pending', 'processing'].includes(order.status)) {
      throw new Error('This order can no longer be cancelled.');
    }
    if (order.cancellationRequestedAt) return;
    await updateOrderField(orderId, { cancellationRequestedAt: new Date().toISOString() });
  };

  const requestReturn = async (orderId: string) => {
    const order = orders.find(item => item.id === orderId);
    if (!order || order.status !== 'delivered') {
      throw new Error('Returns can be requested after delivery only.');
    }
    if (order.returnRequestedAt) return;
    await updateOrderField(orderId, { returnRequestedAt: new Date().toISOString() });
  };

  const markInvoiceGenerated = async (orderId: string) => {
    await updateOrderField(orderId, { invoiceGeneratedAt: new Date().toISOString() });
  };

  const markOrderPaid = async (orderId: string, paymentId: string) => {
    const paidAt = new Date().toISOString();
    try {
      await firestoreWrapper.update('orders', orderId, { paymentId, paymentStatus: 'paid', paidAt });
    } catch (error) {
      console.warn('[Firebase Firestore] Could not sync paid order locally.', {
        code: (error as { code?: string })?.code,
        message: (error as { message?: string })?.message,
      });
    }
    setOrders(previous => previous.map(order =>
      order.id === orderId ? { ...order, paymentId, paymentStatus: 'paid', paidAt } : order,
    ));
    if (user) {
      const storageKey = user.isAdmin ? 'bt_all_orders' : `bt_orders_${user.id}`;
      const stored = localStorage.getItem(storageKey);
      if (stored) {
        try {
          const localOrders = JSON.parse(stored) as Order[];
          localStorage.setItem(storageKey, JSON.stringify(localOrders.map(order =>
            order.id === orderId ? { ...order, paymentId, paymentStatus: 'paid', paidAt } : order,
          )));
        } catch { /* keep in-memory state */ }
      }
    }
  };

  return (
    <OrderContext.Provider value={{
      orders,
      createOrder,
      updateOrderStatus,
      requestCancellation,
      requestReturn,
      markInvoiceGenerated,
      markOrderPaid,
    }}>
      {children}
    </OrderContext.Provider>
  );
}

export function useOrders() {
  const context = useContext(OrderContext);
  if (context === undefined) {
    throw new Error('useOrders must be used within an OrderProvider');
  }
  return context;
}
