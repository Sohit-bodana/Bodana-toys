/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useState, useEffect, useMemo } from 'react';
import LoadingScreen from './components/LoadingScreen';
import TopBar from './components/TopBar';
import BottomNav from './components/BottomNav';
import HeroBanner from './components/HeroBanner';
import CategoryList from './components/CategoryList';
import ProductSection from './components/ProductSection';
import SpinWheel from './components/SpinWheel';
import SearchOverlay from './components/SearchOverlay';
import AdminPanel from './components/AdminPanel';
import TopCustomers from './components/TopCustomers';
import OrderTracking from './components/OrderTracking';
import { useAppContext } from './context/AppContext';
import { useAuth } from './context/AuthContext';
import { useOrders } from './context/OrderContext';
import { useCart } from './context/CartContext';
import { useWishlist } from './context/WishlistContext';
import { useDeveloper } from './context/DeveloperContext';
import CustomerLogin from './components/CustomerLogin';
import ReviewOverlay from './components/ReviewOverlay';
import UserProfile from './components/UserProfile';
import OnboardingGuide from './components/OnboardingGuide';
import DeveloperPanel from './components/DeveloperPanel';
import CategoriesPage from './components/CategoriesPage';
import PremiumToysPage from './components/PremiumToysPage';
import ProductDetailOverlay from './components/ProductDetailOverlay';
import CheckoutOverlay from './components/CheckoutOverlay';
import { motion, AnimatePresence } from 'framer-motion';
import { Product } from './types';
import { Minus, Plus, Trash2 } from 'lucide-react';

import CustomCodeRenderer from './components/CustomCodeRenderer';
import AnnouncementPopup from './components/AnnouncementPopup';

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('home');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [reviewProduct, setReviewProduct] = useState<Product | null>(null);
  const [detailProduct, setDetailProduct] = useState<Product | null>(null);
  const [checkoutItems, setCheckoutItems] = useState<ReturnType<typeof useCart>['cart']>([]);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [showDeveloperPanel, setShowDeveloperPanel] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  
  const [spinsAvailable, setSpinsAvailable] = useState(1);
  const [purchaseCount, setPurchaseCount] = useState(0);
  const [recentViewedIds, setRecentViewedIds] = useState<string[]>([]);

  useEffect(() => {
    const handleOpenDevPanel = () => setShowDeveloperPanel(true);
    document.addEventListener('open-developer-panel', handleOpenDevPanel);
    return () => document.removeEventListener('open-developer-panel', handleOpenDevPanel);
  }, []);

  useEffect(() => {
    if (activeTab !== 'profile') {
      setShowAdminPanel(false);
    }
  }, [activeTab]);

  useEffect(() => {
    const stored = localStorage.getItem('bt_recently_viewed');
    if (!stored) return;
    try {
      setRecentViewedIds(JSON.parse(stored));
    } catch {
      setRecentViewedIds([]);
    }
  }, []);

  const { products, getProductsBySection, theme, customCode: appCustomCode } = useAppContext();
  const { settings: devSettings } = useDeveloper();
  const customCode = devSettings.customCode || appCustomCode;
  const { user, isLoading: isAuthLoading, isFirebaseEnabled } = useAuth();
  const { orders } = useOrders();
  const deliveredProduct = orders.find(order => order.status === 'delivered')?.items[0] || null;
  const { cart, addToCart, removeFromCart, updateQuantity, clearCart } = useCart();
  const { wishlist, addToWishlist, removeFromWishlist } = useWishlist();
  const isAdmin = user?.isAdmin || false;
  
  const trendingProducts = getProductsBySection('trending');
  const bestSellers = getProductsBySection('bestSellers');
  const newArrivals = getProductsBySection('newArrivals');
  const todayDeals = getProductsBySection('todayDeals');
  const recentlyViewedProducts = useMemo(
    () => recentViewedIds
      .map(id => products.find(product => product.id === id))
      .filter((product): product is Product => Boolean(product)),
    [products, recentViewedIds],
  );

  const handleBuyNow = (product: Product) => {
    setRecentViewedIds(previous => {
      const next = [product.id, ...previous.filter(id => id !== product.id)].slice(0, 10);
      localStorage.setItem('bt_recently_viewed', JSON.stringify(next));
      return next;
    });
    setDetailProduct(product);
  };

  const handleDetailBuyNow = (product: Product, quantity: number) => {
    setDetailProduct(null);
    addToCart(product, quantity);
    setActiveTab('cart');
  };

  const openCartCheckout = () => {
    if (cart.length === 0) return;
    setCheckoutItems(cart);
    setIsCheckoutOpen(true);
  };

  const [splashDone, setSplashDone] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setSplashDone(true), 2000);
    return () => clearTimeout(timer);
  }, []);
  useEffect(() => {
    if (splashDone && !isAuthLoading) setIsLoading(false);
  }, [splashDone, isAuthLoading]);

  const themeClass = theme === 'white' ? 'theme-white' : theme === 'gold' ? 'theme-gold' : 'theme-black';
  const containerBg = theme === 'white' ? 'bg-[#f0f0f0]' : theme === 'gold' ? 'bg-[#f4ebd0]' : 'bg-[#0F0F0F]';

  const cartTotal = cart.reduce((sum, item) => sum + item.discountPrice * item.quantity, 0);

  return (
    <div className={`${containerBg} ${themeClass} min-h-screen md:h-screen font-sans selection:bg-red-500/30 flex items-center justify-center`}>
      <AnimatePresence mode="wait">
        {isLoading ? (
          <LoadingScreen key="loading" />
        ) : (
          <motion.div 
            key="app"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="w-full max-w-md mx-auto bg-[#050505] h-[100dvh] md:h-[720px] relative shadow-2xl md:rounded-[48px] md:border-[8px] md:border-[#1F1F1F] flex flex-col overflow-hidden"
          >
            <TopBar
              onSearchClick={() => setIsSearchOpen(true)}
              onCartClick={() => setActiveTab('cart')}
            />
            <AnnouncementPopup />
            <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
            
            <main className="flex-1 overflow-y-auto overflow-x-hidden pt-16 pb-24">
              {activeTab === 'home' && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                >
                  <HeroBanner
                    onShopNow={() => setActiveTab('categories')}
                    onExplorePremium={() => setActiveTab('premium')}
                  />
                  <CategoryList
                    onViewAll={() => {
                      setSelectedCategory('all');
                      setActiveTab('categories');
                    }}
                    onCategoryClick={(categoryId) => {
                      setSelectedCategory(categoryId);
                      setActiveTab('categories');
                    }}
                  />

                  {recentlyViewedProducts.length > 0 && (
                    <ProductSection
                      title="Recently Viewed"
                      products={recentlyViewedProducts}
                      onBuyNow={handleBuyNow}
                      onProductClick={handleBuyNow}
                    />
                  )}
                  
                  <SpinWheel 
                    available={spinsAvailable > 0} 
                    onSpinEnd={() => setSpinsAvailable(prev => Math.max(0, prev - 1))} 
                  />
                  
                  <div className="w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent my-2" />
                  
                   <ProductSection title="Trending Now" products={trendingProducts} onBuyNow={handleBuyNow} onProductClick={handleBuyNow} />
                  
                  <div className="mx-4 my-2 p-4 rounded-2xl bg-gradient-to-br from-red-900/40 to-black border border-red-500/20 relative overflow-hidden flex items-center justify-between">
                    <div className="absolute -right-4 -top-4 w-24 h-24 bg-yellow-500/20 rounded-full blur-2xl" />
                    <div>
                      <h3 className="text-red-400 text-xs font-bold uppercase tracking-wider mb-1">Limited Time</h3>
                      <p className="text-white font-bold text-lg leading-tight">Flat 20% Off<br/>on RC Toys</p>
                    </div>
                    <button
                      onClick={() => setActiveTab('categories')}
                      className="bg-red-600 text-white text-xs font-bold px-4 py-2 rounded-full relative z-10 shadow-[0_0_15px_rgba(220,38,38,0.4)]"
                    >
                      Explore
                    </button>
                  </div>

                  <TopCustomers />

                   <ProductSection title="Top 10 Best Selling Toys" products={bestSellers} onBuyNow={handleBuyNow} onProductClick={handleBuyNow} />
                   <ProductSection title="Today's Deals" products={todayDeals} onBuyNow={handleBuyNow} onProductClick={handleBuyNow} />
                   <ProductSection title="New Arrivals" products={newArrivals} onBuyNow={handleBuyNow} onProductClick={handleBuyNow} />
                </motion.div>
              )}

              {activeTab === 'categories' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="h-full"
                >
                  <CategoriesPage
                    initialCategory={selectedCategory}
                    onBuyNow={handleBuyNow}
                    onProductClick={handleBuyNow}
                  />
                </motion.div>
              )}

              {activeTab === 'premium' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="h-full"
                >
                  <PremiumToysPage
                    onBuyNow={handleBuyNow}
                    onProductClick={handleBuyNow}
                  />
                </motion.div>
              )}

              {activeTab === 'cart' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex flex-col h-full"
                >
                  <div className="px-6 pt-2 pb-4 flex items-center justify-between gap-3">
                    <h2 className="text-2xl font-bold text-white">Your Cart & Orders</h2>
                    <button
                      onClick={() => setActiveTab('home')}
                      className="shrink-0 text-red-400 text-[10px] font-bold uppercase tracking-wider"
                    >
                      Continue Shopping
                    </button>
                  </div>
                  
                   <OrderTracking onReview={product => setReviewProduct(product)} />

                  {cart.length > 0 ? (
                    <div className="px-4 mt-2 space-y-3 pb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-white font-bold text-sm uppercase tracking-wide">Cart ({cart.length})</h3>
                        <button
                          onClick={clearCart}
                          className="text-red-400/70 hover:text-red-400 text-[10px] font-bold uppercase tracking-wider transition-colors"
                        >
                          Clear All
                        </button>
                      </div>
                      {cart.map(item => (
                        <div key={item.id} className="bg-white/5 border border-white/10 rounded-2xl p-3 flex gap-3 items-center">
                          <img src={item.image} alt={item.name} className="w-16 h-16 rounded-xl object-cover shrink-0" loading="lazy" />
                          <div className="flex-1 min-w-0">
                            <h4 className="text-white font-bold text-xs truncate">{item.name}</h4>
                            <p className="text-red-500 font-bold text-sm">₹{item.discountPrice.toLocaleString()}</p>
                            <div className="flex items-center gap-2 mt-1.5">
                              <button
                                onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                className="w-6 h-6 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
                              >
                                <Minus className="w-3 h-3 text-white" />
                              </button>
                              <span className="text-white font-bold text-sm w-4 text-center">{item.quantity}</span>
                              <button
                                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                className="w-6 h-6 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
                              >
                                <Plus className="w-3 h-3 text-white" />
                              </button>
                            </div>
                          </div>
                          <div className="flex flex-col items-end gap-2 shrink-0">
                            <span className="text-white/60 text-xs font-bold">₹{(item.discountPrice * item.quantity).toLocaleString()}</span>
                            <button
                              onClick={() => removeFromCart(item.id)}
                              className="text-red-400/50 hover:text-red-400 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                      <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex items-center justify-between">
                        <span className="text-white/50 text-sm font-bold uppercase tracking-wider">Total</span>
                        <span className="text-white font-black text-lg">₹{cartTotal.toLocaleString()}</span>
                      </div>
                      <button
                        onClick={openCartCheckout}
                        className="w-full bg-red-600 text-white font-bold py-3.5 rounded-xl hover:bg-red-700 transition-colors shadow-[0_4px_14px_rgba(220,38,38,0.4)]"
                      >
                        Proceed to Checkout
                      </button>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center flex-1 text-white/50 min-h-[200px]">
                      <h2 className="text-lg font-bold text-white mb-2">Cart is empty</h2>
                      <p className="text-sm mb-4">Explore more toys to add!</p>
                      <button
                        onClick={() => setActiveTab('home')}
                        className="bg-red-600 text-white text-xs font-bold px-6 py-2.5 rounded-full hover:bg-red-700 transition-colors"
                      >
                        Shop Now
                      </button>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'wishlist' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex flex-col h-full"
                >
                  <div className="px-6 pt-2 pb-4">
                    <h2 className="text-2xl font-bold text-white">Wishlist</h2>
                  </div>

                  {wishlist.length > 0 ? (
                    <div className="px-4 space-y-3 pb-4">
                      <p className="text-white/50 text-xs font-bold uppercase tracking-wider">{wishlist.length} saved item{wishlist.length !== 1 ? 's' : ''}</p>
                      {wishlist.map(item => (
                        <div key={item.id} className="bg-white/5 border border-white/10 rounded-2xl p-3 flex gap-3 items-center">
                          <img src={item.image} alt={item.name} className={`w-16 h-16 rounded-xl object-cover shrink-0 ${item.isOutOfStock ? 'opacity-50 grayscale' : ''}`} loading="lazy" />
                          <div className="flex-1 min-w-0">
                            <h4 className="text-white font-bold text-xs truncate">{item.name}</h4>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="text-red-500 font-bold text-sm">₹{item.discountPrice.toLocaleString()}</span>
                              <span className="text-white/30 line-through text-[10px]">₹{item.originalPrice.toLocaleString()}</span>
                            </div>
                            <div className="flex gap-2 mt-2">
                              <button
                                disabled={item.isOutOfStock}
                                onClick={() => !item.isOutOfStock && addToCart(item)}
                                className={`text-[10px] font-bold px-3 py-1 rounded-full transition-colors ${item.isOutOfStock ? 'bg-white/5 text-white/20 cursor-not-allowed' : 'bg-red-600 text-white hover:bg-red-700'}`}
                              >
                                {item.isOutOfStock ? 'Out of Stock' : 'Add to Cart'}
                              </button>
                            </div>
                          </div>
                          <button
                            onClick={() => removeFromWishlist(item.id)}
                            className="text-red-400/50 hover:text-red-400 transition-colors shrink-0"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center flex-1 text-white/50 min-h-[400px]">
                      <h2 className="text-lg font-bold text-white mb-2">Wishlist is empty</h2>
                      <p className="text-sm mb-4">Tap the ♡ on any product to save it</p>
                      <button
                        onClick={() => setActiveTab('home')}
                        className="bg-red-600 text-white text-xs font-bold px-6 py-2.5 rounded-full hover:bg-red-700 transition-colors"
                      >
                        Browse Products
                      </button>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'profile' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex flex-col h-full"
                >
                  {isAdmin && showAdminPanel ? (
                    <div className="flex flex-col h-full relative">
                      <AdminPanel />
                    </div>
                  ) : (
                    <UserProfile
                      onAdminClick={() => setShowAdminPanel(true)}
                      onOrderHistoryClick={() => setActiveTab('cart')}
                    />
                  )}
                </motion.div>
              )}
              
              <div className="h-6 flex items-center justify-center mt-8">
                <div className="w-1/3 h-1 bg-neutral-800 rounded-full" />
              </div>
            </main>

            <BottomNav activeTab={activeTab} onChange={setActiveTab} />
            
            <CustomerLogin
              isOpen={!user}
            />
            
            {user && <OnboardingGuide />}

            <ProductDetailOverlay
              product={detailProduct}
              onClose={() => setDetailProduct(null)}
              onBuyNow={handleDetailBuyNow}
              onProductClick={handleBuyNow}
            />

            <CheckoutOverlay
              isOpen={isCheckoutOpen}
              onClose={() => {
                setIsCheckoutOpen(false);
                setCheckoutItems([]);
              }}
              items={checkoutItems}
              onOrderComplete={() => {
                setPurchaseCount(prev => {
                  const next = prev + 1;
                  if (next % 5 === 0) setSpinsAvailable(s => s + 1);
                  return next;
                });
              }}
            />

            <ReviewOverlay
              isOpen={!!reviewProduct && !!deliveredProduct}
              onClose={() => setReviewProduct(null)}
              productName={reviewProduct?.name}
            />
            
            {showDeveloperPanel && (
              <DeveloperPanel onClose={() => setShowDeveloperPanel(false)} />
            )}

            {customCode && (
              <CustomCodeRenderer code={customCode} />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
