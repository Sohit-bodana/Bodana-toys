export interface Product {
  id: string;
  name: string;
  image: string;
  images?: string[];           // multiple images for detail view
  originalPrice: number;
  discountPrice: number;
  discountPercent: number;
  rating: number;
  reviews: number;
  category?: string;           // category id from categories list
  description?: string;        // full product description
  features?: string[];         // bullet-point features
  ageGroup?: string;           // e.g. "3-8 years"
  brand?: string;
  isWishlisted?: boolean;
  isOutOfStock?: boolean;
  stock?: number;
  lowStockThreshold?: number;
  section?: string;            // 'trending' | 'bestSellers' | 'newArrivals' | 'todayDeals'
  isPremiumLargeToy?: boolean; // large-item handling and Bodana Toys delivery
  homeDeliveryAvailable?: boolean;
  warranty?: string;
  installationSupport?: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color?: string;              // accent color for the category card
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percent' | 'flat';
  value: number;
  minOrder: number;
  active: boolean;
  expiryDate?: string;
}

export interface Offer {
  id: string;
  title: string;
  description: string;
  discount: string;
  active: boolean;
  expiryDate?: string;
}

export type RewardType = 'spin' | 'coupon' | 'giftCard' | 'offer';

export interface SavedReward {
  id: string;
  userId: string;
  type: RewardType;
  title: string;
  description?: string;
  code?: string;
  discountType?: 'percent' | 'flat';
  value?: number;
  minOrder?: number;
  balance?: number;
  sourceId?: string;
  expiresAt?: string;
  savedAt: string;
  usedAt?: string;
}

export interface DeliveryChargeSettings {
  standard: number;
  premium: number;
  freeAbove: number;
}

export interface AdminNotification {
  id: string;
  title: string;
  message: string;
  active: boolean;
  createdAt: string;
}

export interface AdminSettings {
  coupons: Coupon[];
  offers: Offer[];
  deliveryCharges: DeliveryChargeSettings;
  notifications: AdminNotification[];
}

export interface ProductReview {
  id: string;
  productId?: string;
  productName: string;
  userId?: string;
  rating: number;
  comment: string;
  status: 'pending' | 'approved' | 'rejected';
  date: string;
}

export interface Banner {
  id: string;
  image: string;
  title: string;
  subtitle: string;
}

// ─── Checkout / Razorpay ──────────────────────────────────────────────────────

export interface CheckoutAddress {
  fullName: string;
  phone: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
}

export interface OrderRequestResult {
  success: boolean;
  message?: string;
}

export interface RazorpayOrderPayload {
  amount: number;            // paise
  currency: string;
  receipt: string;
  notes?: Record<string, string>;
}

export interface PaymentResult {
  success: boolean;
  orderId: string;
  paymentId?: string;
  signature?: string;
  mode: 'razorpay' | 'cod' | 'mock';
}
