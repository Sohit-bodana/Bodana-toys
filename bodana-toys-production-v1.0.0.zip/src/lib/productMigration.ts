import { doc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { db, isFirebaseConfigured } from './firebaseConfig';

export interface ProductImportRecord {
  id: string;
  name: string;
  description: string;
  price: number;
  discountPrice: number;
  category: string;
  brand: string;
  ageGroup: string;
  stock: number;
  rating: number;
  images: string[];
  video: string | null;
  features: string[];
  deliveryTime: string;
  warranty: string;
  premium: boolean;
  topSeller: boolean;
}

export interface ProductMigrationResult {
  imported: number;
  ids: string[];
}

function assertValidProduct(product: ProductImportRecord, index: number) {
  if (!product || typeof product !== 'object') {
    throw new Error(`Product at index ${index} must be an object.`);
  }
  if (!product.id.trim() || !product.name.trim()) {
    throw new Error(`Product at index ${index} must include id and name.`);
  }
  if (!Number.isFinite(product.price) || product.price < 0) {
    throw new Error(`Product ${product.id} has an invalid price.`);
  }
  if (!Number.isFinite(product.discountPrice) || product.discountPrice < 0) {
    throw new Error(`Product ${product.id} has an invalid discountPrice.`);
  }
  if (!Number.isInteger(product.stock) || product.stock < 0) {
    throw new Error(`Product ${product.id} has an invalid stock value.`);
  }
  if (!Number.isFinite(product.rating) || product.rating < 0 || product.rating > 5) {
    throw new Error(`Product ${product.id} has an invalid rating.`);
  }
  if (!Array.isArray(product.images) || product.images.length === 0) {
    throw new Error(`Product ${product.id} must include at least one image.`);
  }
  if (!Array.isArray(product.features)) {
    throw new Error(`Product ${product.id} must include a features array.`);
  }
}

/**
 * Imports a validated future-product JSON payload into products/{id}.
 *
 * This helper is intentionally not called by the app startup path. Invoke it
 * from a controlled admin migration script after authenticating with an admin
 * Firebase custom claim.
 */
export async function importProductsToFirestore(
  products: ProductImportRecord[],
): Promise<ProductMigrationResult> {
  const firestore = db;
  if (!isFirebaseConfigured || !firestore) {
    throw new Error('Firebase Firestore is not configured.');
  }
  if (!Array.isArray(products) || products.length === 0) {
    throw new Error('Provide at least one product to import.');
  }

  const ids = new Set<string>();
  products.forEach((product, index) => {
    assertValidProduct(product, index);
    if (ids.has(product.id)) {
      throw new Error(`Duplicate product id: ${product.id}`);
    }
    ids.add(product.id);
  });

  // Firestore batches support up to 500 writes. Chunking keeps this helper
  // usable for larger future catalog imports without changing its call site.
  for (let start = 0; start < products.length; start += 500) {
    const batch = writeBatch(firestore);
    products.slice(start, start + 500).forEach(product => {
      const discountPrice = Math.min(product.price, product.discountPrice);
      const discountPercent = product.price > 0
        ? Math.round(((product.price - discountPrice) / product.price) * 100)
        : 0;

      const productData = {
        ...product,
        image: product.images[0],
        originalPrice: product.price,
        discountPrice,
        discountPercent,
        reviews: 0,
        isOutOfStock: product.stock === 0,
        isPremiumLargeToy: product.premium,
        ...(product.topSeller ? { section: 'bestSellers' } : {}),
        importedAt: serverTimestamp(),
      };
      batch.set(doc(firestore, 'products', product.id), productData, { merge: true });
    });
    await batch.commit();
  }

  return { imported: products.length, ids: [...ids] };
}