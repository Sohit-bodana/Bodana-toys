import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import {
  getFirestore,
  initializeFirestore,
  persistentLocalCache,
} from "firebase/firestore";
import { getStorage } from "firebase/storage";

const readEnv = (key: keyof ImportMetaEnv) => {
  const rawValue = import.meta.env[key];
  if (typeof rawValue !== "string") return undefined;

  // Secrets are sometimes pasted into the environment with a UTF-8 BOM,
  // wrapping quotes, or a trailing line break. Normalize only those harmless
  // formatting artifacts; never hardcode or transform the credential itself.
  const withoutBom = rawValue.replace(/^\uFEFF/, '');
  const trimmed = withoutBom.trim();
  const withoutWrappingQuotes = trimmed.match(/^(['"])([\s\S]*)\1$/)?.[2] ?? trimmed;
  const normalized = withoutWrappingQuotes.replace(/[\r\n]/g, '').trim();
  return normalized || undefined;
};

const firebaseConfig = {
  apiKey: readEnv("VITE_FIREBASE_API_KEY"),
  authDomain: readEnv("VITE_FIREBASE_AUTH_DOMAIN"),
  projectId: readEnv("VITE_FIREBASE_PROJECT_ID"),
  storageBucket: readEnv("VITE_FIREBASE_STORAGE_BUCKET"),
  messagingSenderId: readEnv("VITE_FIREBASE_MESSAGING_SENDER_ID"),
  appId: readEnv("VITE_FIREBASE_APP_ID"),
  measurementId: readEnv("VITE_FIREBASE_MEASUREMENT_ID"),
};

const firebaseEnvStatus = {
  VITE_FIREBASE_API_KEY: Boolean(firebaseConfig.apiKey),
  VITE_FIREBASE_AUTH_DOMAIN: Boolean(firebaseConfig.authDomain),
  VITE_FIREBASE_PROJECT_ID: Boolean(firebaseConfig.projectId),
  VITE_FIREBASE_STORAGE_BUCKET: Boolean(firebaseConfig.storageBucket),
  VITE_FIREBASE_MESSAGING_SENDER_ID: Boolean(firebaseConfig.messagingSenderId),
  VITE_FIREBASE_APP_ID: Boolean(firebaseConfig.appId),
};
const missingFirebaseEnv = Object.entries(firebaseEnvStatus)
  .filter(([, loaded]) => !loaded)
  .map(([key]) => key);

if (missingFirebaseEnv.length > 0) {
  console.error('[Firebase Config] Missing or empty runtime variables:', missingFirebaseEnv);
} else {
  console.info('[Firebase Config] Required runtime variables loaded.', {
    apiKeyLoaded: firebaseEnvStatus.VITE_FIREBASE_API_KEY,
  });
}

/**
 * True only when the required Firebase web config values are present in env vars.
 * When false, the app falls back to a safe local-only dev mode.
 */
const requiredConfig = [
  firebaseConfig.apiKey,
  firebaseConfig.authDomain,
  firebaseConfig.projectId,
  firebaseConfig.appId,
];

export const isFirebaseConfigured = requiredConfig.every(value =>
  Boolean(value) && value !== "your_api_key_here",
);

const app = isFirebaseConfigured
  ? getApps().length > 0
    ? getApp()
    : initializeApp(firebaseConfig)
  : null;

export const auth = app ? getAuth(app) : null;
/**
 * Prefer Firestore's durable browser cache so brief network outages can use
 * previously loaded data. Some preview/browser environments do not support
 * IndexedDB, so initialization must fall back to the regular Firestore client
 * instead of preventing the app from loading.
 */
export const db = (() => {
  if (!app) return null;
  try {
    return initializeFirestore(app, {
      localCache: persistentLocalCache(),
    });
  } catch (error) {
    console.warn('[Firebase Firestore] Offline persistence unavailable; using the standard client.', {
      code: (error as { code?: string })?.code,
      message: (error as { message?: string })?.message,
    });
    return getFirestore(app);
  }
})();
export const storage = app ? getStorage(app) : null;

export const googleProvider = new GoogleAuthProvider();
googleProvider.addScope("email");
googleProvider.addScope("profile");
googleProvider.setCustomParameters({ prompt: "select_account" });
