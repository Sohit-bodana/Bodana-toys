import { twMerge } from 'tailwind-merge';

import { clsx, type ClassValue } from 'clsx';
import { Order } from '../context/OrderContext';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;',
  }[char] || char));
}

export function downloadInvoice(order: Order) {
  const rows = order.items.map(item => `
    <tr>
      <td>${escapeHtml(item.name)}</td>
      <td>${item.quantity}</td>
      <td>₹${item.discountPrice.toLocaleString()}</td>
      <td>₹${(item.discountPrice * item.quantity).toLocaleString()}</td>
    </tr>
  `).join('');
  const address = order.address
    ? `${escapeHtml(order.address.fullName)}<br>${escapeHtml(order.address.line1)}${order.address.line2 ? `<br>${escapeHtml(order.address.line2)}` : ''}<br>${escapeHtml(order.address.city)}, ${escapeHtml(order.address.state)} - ${escapeHtml(order.address.pincode)}<br>Phone: ${escapeHtml(order.address.phone)}`
    : 'Address not available';
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Invoice ${escapeHtml(order.id)}</title><style>
    body{font-family:Arial,sans-serif;color:#171717;max-width:760px;margin:40px auto;padding:0 24px}
    header{display:flex;justify-content:space-between;border-bottom:2px solid #dc2626;padding-bottom:18px;margin-bottom:24px}
    h1{margin:0;color:#dc2626}.muted{color:#666;font-size:13px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:28px}
    table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:10px 6px;border-bottom:1px solid #ddd}th{background:#f5f5f5}
    .total{text-align:right;font-size:20px;font-weight:700;margin-top:18px}
  </style></head><body>
    <header><div><h1>Bodana Toys</h1><div class="muted">Premium Play Experiences</div></div>
    <div><strong>INVOICE</strong><br><span class="muted">#${escapeHtml(order.id)}</span><br><span class="muted">${new Date(order.date).toLocaleDateString()}</span></div></header>
    <div class="grid"><div><strong>Bill To</strong><p>${address}</p></div>
    <div><strong>Payment</strong><p>${escapeHtml((order.paymentMethod || 'mock').toUpperCase())}<br><span class="muted">Status: ${escapeHtml(order.status)}</span></p></div></div>
    <table><thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>${rows}</tbody></table>
    <div class="total">Total: ₹${order.total.toLocaleString()}</div><p class="muted">Thank you for shopping with Bodana Toys.</p>
  </body></html>`;
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `bodana-invoice-${order.id}.html`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}
