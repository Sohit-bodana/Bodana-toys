import type { CheckoutAddress, PaymentResult } from '../types';
import { auth } from './firebaseConfig';

declare global {
  interface Window {
    Razorpay?: new (opts: RazorpayOptions) => RazorpayInstance;
  }
}

interface RazorpayOptions {
  key: string;
  amount: number;
  currency: string;
  name: string;
  description: string;
  order_id: string;
  prefill?: { name: string; email?: string; contact?: string };
  theme?: { color: string };
  handler?: (response: RazorpayResponse) => void;
  modal?: { ondismiss?: () => void };
}

interface RazorpayResponse {
  razorpay_payment_id: string;
  razorpay_order_id: string;
  razorpay_signature: string;
}

interface RazorpayInstance {
  open(): void;
}

async function getAuthHeaders(): Promise<HeadersInit> {
  if (!auth?.currentUser) throw new Error('Please sign in before paying online.');
  return { Authorization: `Bearer ${await auth.currentUser.getIdToken()}` };
}

/** Dynamically loads the Razorpay checkout.js script once. */
function loadRazorpayScript(): Promise<boolean> {
  if (window.Razorpay) return Promise.resolve(true);
  return new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.head.appendChild(script);
  });
}

/**
 * Opens the Razorpay TEST checkout. The public TEST key is returned by the
 * backend; the TEST secret never reaches this module.
 *
 * @param amount       Final order total in RUPEES (will convert to paise internally)
 * @param orderId      Local order ID (receipt)
 * @param razorpayOrderId  Server-side Razorpay order ID (pass empty '' in mock mode)
 * @param address      Shipping address for prefill
 * @param userEmail    Customer email for prefill
 */
export function openRazorpayCheckout(params: {
  amount: number;
  orderId: string;
  razorpayOrderId: string;
  razorpayKeyId: string;
  address: CheckoutAddress;
  userEmail?: string;
}): Promise<PaymentResult> {
  const { amount, orderId, razorpayOrderId, razorpayKeyId, address, userEmail } = params;

  return new Promise(async (resolve, reject) => {
    const loaded = await loadRazorpayScript();
    if (!loaded || !window.Razorpay) {
      reject(new Error('Razorpay failed to load. Check your connection.'));
      return;
    }

    const rzp = new window.Razorpay({
      key: razorpayKeyId,
      amount: amount * 100, // paise
      currency: 'INR',
      name: 'Bodana Toys',
      description: 'Order Payment',
      order_id: razorpayOrderId,
      prefill: {
        name: address.fullName,
        email: userEmail,
        contact: address.phone,
      },
      theme: { color: '#dc2626' },
      handler: (response) => {
        resolve({
          success: true,
          orderId,
          paymentId: response.razorpay_payment_id,
          signature: response.razorpay_signature,
          mode: 'razorpay',
        });
      },
      modal: {
        ondismiss: () =>
          reject(new Error('Payment cancelled by user.')),
      },
    });

    rzp.open();
  });
}

/**
 * Creates a Razorpay order via your backend.
 * Creates a Razorpay TEST order through the backend and returns its public
 * checkout key. The TEST secret remains server-side.
 */
export async function createRazorpayOrder(
  amount: number,
  receipt: string,
): Promise<{ id: string; amount: number; currency: string; keyId: string }> {
  const res = await fetch('/api/orders/create-razorpay-order', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(await getAuthHeaders()) },
    body: JSON.stringify({ amount: Math.round(amount * 100), currency: 'INR', receipt }),
  });
  const body = await res.json().catch(() => null) as { message?: string } | null;
  if (!res.ok) throw new Error(body?.message || 'Could not create Razorpay TEST order.');
  return body as { id: string; amount: number; currency: string; keyId: string };
}

export async function verifyRazorpayPayment(params: {
  localOrderId: string;
  razorpayOrderId: string;
  paymentId: string;
  signature: string;
}): Promise<{ paymentId: string; orderId: string }> {
  const res = await fetch('/api/orders/verify-razorpay-payment', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(await getAuthHeaders()) },
    body: JSON.stringify(params),
  });
  const body = await res.json().catch(() => null) as {
    message?: string;
    paymentId?: string;
    orderId?: string;
  } | null;
  if (!res.ok || !body?.paymentId || !body.orderId) {
    throw new Error(body?.message || 'Payment verification failed.');
  }
  return { paymentId: body.paymentId, orderId: body.orderId };
}
