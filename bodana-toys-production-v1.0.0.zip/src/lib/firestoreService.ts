import { db, isFirebaseConfigured } from './firebaseConfig';
import { collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc, query, where, serverTimestamp } from 'firebase/firestore';

function logReadFailure(operation: string, collectionName: string, error: unknown) {
  console.warn(`[Firebase Firestore] ${operation} unavailable; using local fallback.`, {
    collection: collectionName,
    code: (error as { code?: string })?.code,
    message: (error as { message?: string })?.message,
  });
}

// Firestore reads are optional enhancements. They must never prevent the local
// catalog/app shell from loading when the client is offline or rules reject a
// document.
export const firestoreWrapper = {
  async get(collectionName: string, docId: string) {
    if (!isFirebaseConfigured || !db) return null;
    try {
      const docRef = doc(db, collectionName, docId);
      const snap = await getDoc(docRef);
      return snap.exists() ? snap.data() : null;
    } catch (error) {
      logReadFailure('Document read', collectionName, error);
      return null;
    }
  },

  async set(collectionName: string, docId: string, data: any) {
    if (!isFirebaseConfigured || !db) return;
    const docRef = doc(db, collectionName, docId);
    await setDoc(docRef, { ...data, updatedAt: serverTimestamp() }, { merge: true });
  },

  async getCollection(collectionName: string, filterByUserId?: string) {
    if (!isFirebaseConfigured || !db) return [];
    try {
      let q = collection(db, collectionName);
      if (filterByUserId) {
        q = query(q, where('userId', '==', filterByUserId)) as any;
      }
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      logReadFailure('Collection read', collectionName, error);
      return [];
    }
  },
  
  async add(collectionName: string, data: any, docId?: string) {
    if (!isFirebaseConfigured || !db) return;
    if (docId) {
       await setDoc(doc(db, collectionName, docId), { ...data, createdAt: serverTimestamp() });
    } else {
       const newRef = doc(collection(db, collectionName));
       await setDoc(newRef, { ...data, id: newRef.id, createdAt: serverTimestamp() });
       return newRef.id;
    }
    return undefined;
  },

  async update(collectionName: string, docId: string, data: any) {
    if (!isFirebaseConfigured || !db) return;
    const docRef = doc(db, collectionName, docId);
    await updateDoc(docRef, { ...data, updatedAt: serverTimestamp() });
  },

  async delete(collectionName: string, docId: string) {
    if (!isFirebaseConfigured || !db) return;
    const docRef = doc(db, collectionName, docId);
    await deleteDoc(docRef);
  }
};
