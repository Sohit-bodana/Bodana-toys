import path from 'path';
import { createHmac, timingSafeEqual } from 'node:crypto';
import type { IncomingMessage, ServerResponse } from 'node:http';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig, type Plugin } from 'vite';

/** Reads the full request body as a parsed JSON object. */
function readBody(req: IncomingMessage): Promise<any> {
  return new Promise((resolve) => {
    let raw = '';
    req.on('data', (chunk: Buffer | string) => { raw += chunk.toString(); });
    req.on('end', () => { try { resolve(JSON.parse(raw)); } catch { resolve({}); } });
  });
}

function jsonReply(res: ServerResponse, status: number, data: unknown) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

/**
 * Vite dev-server plugin that mirrors the two Vercel API functions so the
 * full Razorpay payment flow works in local preview without a second process.
 * Reads RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET from process.env (server-side
 * only — never bundled into the client).
 */
function razorpayDevApiPlugin(): Plugin {
  return {
    name: 'razorpay-dev-api',
    configureServer(server) {
      server.middlewares.use(async (req: IncomingMessage, res: ServerResponse, next) => {
        const url = req.url?.split('?')[0];

        // ── POST /api/orders/create-razorpay-order ────────────────────────────
        if (url === '/api/orders/create-razorpay-order' && req.method === 'POST') {
          const keyId = process.env.RAZORPAY_KEY_ID;
          const keySecret = process.env.RAZORPAY_KEY_SECRET;

          if (!keyId || !keySecret) {
            return jsonReply(res, 503, {
              message:
                'Razorpay is not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET to environment variables.',
            });
          }

          const body = await readBody(req);
          const amount = Number(body?.amount);
          const currency = String(body?.currency || 'INR');
          const receipt = String(body?.receipt || '');

          if (!Number.isFinite(amount) || amount <= 0)
            return jsonReply(res, 400, { message: 'Invalid amount.' });
          if (amount > 50_000_000)
            return jsonReply(res, 400, { message: 'Amount exceeds the maximum allowed order value.' });

          const basicAuth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
          let rzpData: any;
          try {
            const rzpRes = await fetch('https://api.razorpay.com/v1/orders', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', Authorization: `Basic ${basicAuth}` },
              body: JSON.stringify({ amount: Math.round(amount), currency, receipt }),
            });
            rzpData = await rzpRes.json();
            if (!rzpRes.ok)
              return jsonReply(res, rzpRes.status, {
                message: rzpData?.error?.description || 'Razorpay order creation failed.',
              });
          } catch (err: any) {
            return jsonReply(res, 502, { message: `Could not reach Razorpay: ${err?.message}` });
          }

          return jsonReply(res, 200, {
            id: rzpData.id,
            amount: rzpData.amount,
            currency: rzpData.currency,
            keyId,
          });
        }

        // ── POST /api/orders/verify-razorpay-payment ─────────────────────────
        if (url === '/api/orders/verify-razorpay-payment' && req.method === 'POST') {
          const keySecret = process.env.RAZORPAY_KEY_SECRET;
          if (!keySecret)
            return jsonReply(res, 503, { message: 'Razorpay is not configured.' });

          const body = await readBody(req);
          const { razorpayOrderId, paymentId, signature, localOrderId } = body || {};

          if (!razorpayOrderId || !paymentId || !signature)
            return jsonReply(res, 400, { message: 'Missing required payment fields.' });

          const payload = `${razorpayOrderId}|${paymentId}`;
          const expected = createHmac('sha256', keySecret).update(payload).digest('hex');

          let match = false;
          try {
            match = timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(signature, 'hex'));
          } catch { match = false; }

          if (!match)
            return jsonReply(res, 400, {
              message: 'Payment verification failed. Signature does not match.',
            });

          return jsonReply(res, 200, { paymentId, orderId: localOrderId });
        }

        next();
      });
    },
  };
}

export default defineConfig({
  plugins: [react(), tailwindcss(), razorpayDevApiPlugin()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
    },
  },
  server: {
    host: '0.0.0.0',
    port: 3000,
  },
  preview: {
    host: '0.0.0.0',
    port: 3000,
  },
});
